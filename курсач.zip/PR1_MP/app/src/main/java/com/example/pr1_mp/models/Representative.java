package com.example.pr1_mp.models;

import androidx.annotation.Size;

public class Representative {

    private long id;
    private String lastname;
    private String firstname;
    private String patronymic;
    private String email;
    @Size(11)
    private String phoneNum;
    private char jobTitle;

    public Representative(long id, String lastname, String firstname,
                          String patronymic, String email, String phoneNum,
                          char jobTitle){
        this.id = id;
        this.lastname = lastname;
        this.firstname = firstname;
        this.patronymic = patronymic;
        this.email = email;
        this.phoneNum = phoneNum;
        this.jobTitle = jobTitle;
    }
    public Representative() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFIO() {
        if (patronymic.equals(""))
            return lastname + " " + firstname.charAt(0) + "." ;
        else
            return lastname + " " + firstname.charAt(0) + "." + patronymic.charAt(0) + ".";
    }

    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public char getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(char jobTitle) {
        this.jobTitle = jobTitle;
    }
}
