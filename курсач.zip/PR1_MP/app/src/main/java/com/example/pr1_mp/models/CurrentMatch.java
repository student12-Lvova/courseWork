package com.example.pr1_mp.models;

import org.jetbrains.annotations.NotNull;

public class CurrentMatch {
    @NotNull
    int id;
    @NotNull
    boolean placement;
    @NotNull
    boolean protocol;

    public CurrentMatch(@NotNull int id, @NotNull boolean placement, @NotNull boolean protocol) {
        this.id = id;
        this.placement = placement;
        this.protocol = protocol;
    }

    public int getId() {
        return id;
    }
    public void setId(@NotNull int id) {
        this.id = id;
    }

    public boolean isPlacement() {
        return placement;
    }

    public boolean isProtocol() {
        return protocol;
    }
}
