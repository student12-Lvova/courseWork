package com.example.pr1_mp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.pr1_mp.connectdb.WorkMyDB

class ForUserMainActivity : AppCompatActivity() {

    private lateinit var StartTren : Button
    private lateinit var StartMatch : Button

    lateinit var settings: SharedPreferences
    private val PREFS_FILE = "Account"
    private var flag:Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_for_user_main)



        StartTren = findViewById(R.id.bStartTren)
        StartMatch = findViewById(R.id.bAddNewTeam)

        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE);
        flag = settings.contains("Id")
        if (!settings.contains("Id")){
            StartMatch.isEnabled = flag
        }else{
            StartMatch.setOnClickListener{
                // Выполняем переход на другой экран:
                val intent = Intent(this@ForUserMainActivity, CreateMatchActivity::class.java)
                startActivity(intent)
            }
        }

        StartTren.setOnClickListener{
            // Выполняем переход на другой экран:
            val intent = Intent(this@ForUserMainActivity, MainActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val  intent : Intent
        when (item.itemId) {
            R.id.EnterExit -> {
                intent = Intent(this@ForUserMainActivity, AuthActivity::class.java)
                startActivity(intent)
            }
            R.id.Profile -> {
                if (flag){
                    intent = Intent(this@ForUserMainActivity, UserProfileActivity::class.java)
                    startActivity(intent)
                }else
                    Toast.makeText(this, "Данный пользователь не зарегистрирован!",
                        Toast.LENGTH_SHORT
                    ).show()

            }
            R.id.Matches -> {
                if (flag){
                    intent = Intent(this@ForUserMainActivity, MatcherUserActivity::class.java)
                    startActivity(intent)
                }else
                    Toast.makeText(this, "Данный пользователь не зарегистрирован!",
                        Toast.LENGTH_SHORT
                    ).show()
            }
            R.id.Teams -> {
                if (flag){
                    intent = Intent(this@ForUserMainActivity, TeamsUserActivity::class.java)
                    startActivity(intent)
                }else
                    Toast.makeText(this, "Данный пользователь не зарегистрирован!",
                        Toast.LENGTH_SHORT
                    ).show()
            }
        }
        return super.onOptionsItemSelected(item)
    }


}