package com.example.pr1_mp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.models.User

//
class AuthActivity : AppCompatActivity() {

    lateinit var workDb: WorkMyDB

    private lateinit var login: EditText
    private lateinit var password: EditText
    private lateinit var btnAuthorization: Button
    lateinit var tvRegistration: TextView

    lateinit var settings: SharedPreferences
    private val PREFS_FILE = "Account"
    private val PREF_ID = "Id"
    private val PREF_LOGIN = "Login"
    private val PREF_PASSWORD = "Password"
    private val PREF_EMAIL = "Email"
    private val PREF_PHONE = "Phone"


    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth)

        workDb = WorkMyDB(this@AuthActivity)
        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE);

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            // showing the back button in action bar
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        login = findViewById(R.id.etLogin)
        password = findViewById(R.id.editPassword)
        btnAuthorization = findViewById(R.id.button_login)
        btnAuthorization.setOnClickListener {

            if (workDb.auth(login.text.toString(), password.text.toString())){
                Toast.makeText(getApplicationContext(), ("Вход выполнен!"), Toast.LENGTH_SHORT).show()
                var user: User = workDb.selectUserId(workDb.idUser)

                val prefEditor = settings.edit()
                prefEditor.clear()
                prefEditor.putString(PREF_ID, user.id.toString())
                prefEditor.putString(PREF_LOGIN, user.login)
                prefEditor.putString(PREF_PASSWORD, user.password)
                prefEditor.putString(PREF_EMAIL, user.email)
                prefEditor.putString(PREF_PHONE, user.phoneNum)
                prefEditor.apply()
                // Выполняем переход на другой экран:
                val intent = Intent(this@AuthActivity, ForUserMainActivity::class.java)
                startActivity(intent)

            }
            // В другом случае выдаем сообщение с ошибкой:
            else {
                Toast.makeText(getApplicationContext(), "Неправильные данные!", Toast.LENGTH_SHORT).show();
            }
        }
        tvRegistration = findViewById(R.id.tvRegistration)
        tvRegistration.setOnClickListener(){
            // Выполняем переход на другой экран:
            val intent = Intent(this@AuthActivity, RegistrationActivity::class.java)
            startActivity(intent)
        }

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }


}