package com.example.pr1_mp.models;

import org.jetbrains.annotations.Nullable;

public class CurrentPlayer {
    private long id;
    private Player player;
    private String position;

    public CurrentPlayer(Player player) {
        this.player = player;
    }

    public CurrentPlayer(@Nullable Player player, String position) {
        this.player = player;
        this.position = position;
    }

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    public Player getPlayer() {
        return player;
    }

    public String getPosition() {
        return position;
    }
    public void setPosition(String position) {
        this.position = position;
    }
}
