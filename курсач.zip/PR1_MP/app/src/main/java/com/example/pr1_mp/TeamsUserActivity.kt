package com.example.pr1_mp

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.get
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.models.Team
import com.example.pr1_mp.team.AddTeamActivity
import com.example.pr1_mp.team.EditTeamActivity

class TeamsUserActivity : AppCompatActivity() {
    lateinit var workDb: WorkMyDB
    lateinit var settings: SharedPreferences
    private val PREFS_FILE = "Account"
    private val PREF_ID = "Id"

    lateinit var bAddNewTeam:AppCompatButton
    lateinit var tableTeams:TableLayout
    lateinit var listTeams:MutableList<Team>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_teams_user)
        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            // showing the back button in action bar
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        workDb = WorkMyDB(this)
        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE)
        workDb.idUser = settings.getString(PREF_ID,"id")!!.toLong()

        listTeams = listOf<Team>().toMutableList()
        listTeams = workDb.selectAllTeamByIdUser()

        initField()
    }

    private fun initField() {
        bAddNewTeam = findViewById(R.id.bAddNewTeam)
        bAddNewTeam.setOnClickListener {
            val intent = Intent(this@TeamsUserActivity, AddTeamActivity::class.java)
            intent.putExtra("idUser", workDb.idUser)
            startActivity(intent)
        }
        tableTeams = findViewById(R.id.tableTeams)
        for (team in listTeams){
            tableTeams.addView(createRow(team))
        }

    }

    private fun createRow(team: Team): TableRow {
        var row=TableRow(this)

        var tvName= TextView(this)
        tvName.text = team.name
        row.addView(tvName)


        var btnDetails = AppCompatButton(this)
        btnDetails.text = "Подробнее"
        btnDetails.setOnClickListener {
            val intent = Intent(this@TeamsUserActivity, EditTeamActivity::class.java)
            intent.putExtra("idTeam", team.id)
            startActivity(intent)

        }
        row.addView(btnDetails)

        row.layoutParams = marginRow()
        row[0].layoutParams = marginView()
        row[1].layoutParams = marginButton()

        return row

    }
    private fun marginView(): TableRow.LayoutParams {
        val params = TableRow.LayoutParams(
            TableRow.LayoutParams.WRAP_CONTENT,
            TableRow.LayoutParams.WRAP_CONTENT, 1F
        )
        return params;
    }
    private fun marginButton(): TableRow.LayoutParams {
        val params = TableRow.LayoutParams(70,
            70, 1F
        )
        return params;
    }
    private fun marginRow(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
            TableLayout.LayoutParams.WRAP_CONTENT,
            TableLayout.LayoutParams.WRAP_CONTENT
        );
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }
}