package com.example.pr1_mp

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.view.MenuItem
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.core.view.get
import androidx.core.view.setMargins
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.models.Match

class MatcherUserActivity : AppCompatActivity() {
    lateinit var workDb: WorkMyDB
    lateinit var settings: SharedPreferences
    private val PREFS_FILE = "Account"
    private val PREF_ID = "Id"
    lateinit var tableMatches: TableLayout
    lateinit var listMatches:MutableList<Match>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_matcher_user)
        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            // showing the back button in action bar
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        workDb = WorkMyDB(this)
        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE)
        workDb.idUser = settings.getString(PREF_ID,"id")!!.toLong()

        listMatches = listOf<Match>().toMutableList()
        listMatches = workDb.selectMatchesByIdUser()

        initField()
    }

    private fun initField() {
        tableMatches = findViewById(R.id.tableMatches)
        for (match in listMatches){
            tableMatches.addView(createRow(match))
        }

    }

    private fun createRow(match: Match): TableRow {
        var row= TableRow(this)

        var tvDate= TextView(this)
        tvDate.inputType = InputType.TYPE_DATETIME_VARIATION_DATE
        tvDate.text = match.date.toString()
        row.addView(tvDate)

        var tvDesc= TextView(this)
        tvDesc.text = match.description
        row.addView(tvDesc)

        row.layoutParams = marginRow()
        row[0].layoutParams = marginView()
        row[1].layoutParams = marginView()

        return row

    }
    private fun marginView(): TableRow.LayoutParams {
        val params = TableRow.LayoutParams(
            TableRow.LayoutParams.MATCH_PARENT,
            TableRow.LayoutParams.WRAP_CONTENT, 1F
        )
        params.setMargins(10)
        return params;
    }
    private fun marginRow(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
            TableLayout.LayoutParams.WRAP_CONTENT,
            TableLayout.LayoutParams.WRAP_CONTENT
        );
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }

}