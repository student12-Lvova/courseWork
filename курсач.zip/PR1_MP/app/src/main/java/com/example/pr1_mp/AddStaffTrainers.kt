package com.example.pr1_mp

import android.content.ContentValues
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.models.CurrentTeam
import com.example.pr1_mp.models.Representative
import com.example.pr1_mp.models.Team
import java.util.regex.Pattern


class AddStaffTrainers : AppCompatActivity() {

    private lateinit var rbManager:RadioButton
    private lateinit var llManager:LinearLayout
    private lateinit var bEditInfM:AppCompatButton
    private lateinit var editLastnameM:EditText
    private lateinit var editFirstnameM:EditText
    private lateinit var editPatronymicM:EditText
    private lateinit var editPhoneM:EditText
    private lateinit var editEmailM:EditText
    private lateinit var rbTrainer:RadioButton
    private lateinit var llTrainer:LinearLayout
    private lateinit var bEditInfT:AppCompatButton
    private lateinit var editLastnameT:EditText
    private lateinit var editFirstnameT:EditText
    private lateinit var editPatronymicT:EditText
    private lateinit var editPhoneT:EditText
    private lateinit var editEmailT:EditText
    private lateinit var bEditStaffTrain:AppCompatButton
    private lateinit var bAddStaffTrain:AppCompatButton

    private lateinit var manager:Representative
    private lateinit var trainer:Representative
    private lateinit var curTeam:CurrentTeam
    private lateinit var team: Team
    private var idManager = 0
    private lateinit var typeWork:String
    private lateinit var cvManager:ContentValues
    private lateinit var cvTrainer:ContentValues
    private lateinit var cvCurTeam:ContentValues

    lateinit var workMyDB: WorkMyDB
    var idUser: Long = 0
    var idTeam: Int = 0
    lateinit var settings: SharedPreferences
    private val PREFS_FILE = "Account"
    private val PREF_ID = "Id"
    private val PREF_IDM = "idM"
    private val PREF_IDT = "idT"
    private val PREF_IDMCurTeam = "idCT"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_staff_trainers)

        workMyDB = WorkMyDB(this)
        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE);
        idUser= settings.getString(PREF_ID,"id")!!.toLong();
        workMyDB.idUser=idUser

        manager= Representative()
        trainer=Representative()
        typeWork=""

        curTeam = CurrentTeam()
        team = Team()

        val extras = intent.extras
        if (extras != null && extras.getInt("idTeam")>0) {
            idTeam = extras.getInt("idTeam")
            if (extras != null && extras.getString("type").toString()!="")
                typeWork = extras.getString("type").toString()
            if (typeWork!="edit") {
                curTeam = workMyDB.selectCurTeamById(idTeam)

                manager = workMyDB.selectRepresentativeByIdTeam(curTeam.team.id.toInt(), 'M')
                trainer = workMyDB.selectRepresentativeByIdTeam(curTeam.team.id.toInt(), 'T')
            }
            else{
                team = workMyDB.selectTeambyId(idTeam)
                manager = workMyDB.selectRepresentativeByIdTeam(team.id.toInt(), 'M')
                trainer = workMyDB.selectRepresentativeByIdTeam(team.id.toInt(), 'T')
            }

        }


        initFields()
        lisener()
    }
    private fun initFields() {

        rbManager = findViewById(R.id.rbManager)
        llManager = findViewById(R.id.llManager)
        llManager.visibility = View.GONE
        bEditInfM = findViewById(R.id.bEditInfM)
        editLastnameM = findViewById(R.id.editLastnameM)
        editFirstnameM = findViewById(R.id.editFirstnameM)
        editPatronymicM = findViewById(R.id.editPatronymicM)
        editPhoneM = findViewById(R.id.editPhoneM)
        editEmailM = findViewById(R.id.editEmailM)

        rbTrainer = findViewById(R.id.rbTrainer)
        llTrainer = findViewById(R.id.llTrainer)
        llTrainer.visibility = View.GONE
        bEditInfT = findViewById(R.id.bEditInfT)
        editLastnameT = findViewById(R.id.editLastnameT)
        editLastnameT.setText(trainer.lastname)
        editFirstnameT = findViewById(R.id.editFirstnameT)
        editFirstnameT.setText(trainer.firstname)
        editPatronymicT = findViewById(R.id.editPatronymicT)
        editPatronymicT.setText(trainer.patronymic)
        editPhoneT = findViewById(R.id.editPhoneT)
        editPhoneT.setText(trainer.phoneNum)
        editEmailT = findViewById(R.id.editEmailT)
        editEmailT.setText(trainer.email)
        bEditStaffTrain = findViewById(R.id.bEditStaffTrain)
        bAddStaffTrain = findViewById(R.id.bAddStaffTrain)

        if (typeWork=="edit" || typeWork=="editCur"){
            bEditStaffTrain.visibility = View.VISIBLE
            bAddStaffTrain.visibility = View.GONE
        }
        else{
            bEditStaffTrain.visibility = View.GONE
            bAddStaffTrain.visibility = View.VISIBLE
        }

        if (manager!=null && manager.lastname!=null){
            editLastnameM.setText(manager.lastname)
            editFirstnameM.setText(manager.firstname)
            editPatronymicM.setText(manager.patronymic)
            editPhoneM.setText(manager.phoneNum)
            editEmailM.setText(manager.email)
        }
        if (trainer!=null && trainer.lastname!=null){
            editLastnameT.setText(trainer.lastname)
            editFirstnameT.setText(trainer.firstname)
            editPatronymicT.setText(trainer.patronymic)
            editPhoneT.setText(trainer.phoneNum)
            editEmailT.setText(trainer.email)
        }
    }
    private fun lisener() {

        rbManager.setOnClickListener{
            rbTrainer.isChecked = false
            if (manager.lastname!="")
                idManager = manager.id.toInt()

        }
        rbTrainer.setOnClickListener{
            rbManager.isChecked = false
            if (trainer.lastname!="")
                idManager = trainer.id.toInt()
        }
        bEditInfM.setOnClickListener {
            llTrainer.visibility = View.GONE
            llManager.visibility = View.VISIBLE
        }
        bEditInfT.setOnClickListener {
            llTrainer.visibility = View.VISIBLE
            llManager.visibility = View.GONE
        }


        bEditStaffTrain.setOnClickListener {
            if (idManager!=0){
                fillCV()

                if (cvManager.size()!=0)
                    workMyDB.updateRepresentative(cvManager)
                if (cvTrainer.size()!=0)
                    workMyDB.updateRepresentative(cvTrainer)
                if (curTeam.idManage>0)
                    workMyDB.updateManagerCurTeam(curTeam.id, cvCurTeam)

                finish()
            }else
                Toast.makeText(this,
                    "Выберите представителя команды!", Toast.LENGTH_SHORT)
                    .show()



        }
        bAddStaffTrain.setOnClickListener {
            cvManager = ContentValues()
                if (rbManager.isChecked && checkManadger()){


                    cvManager.put("lastname", editLastnameM.text.toString())
                    cvManager.put("firstname", editFirstnameM.text.toString())
                    cvManager.put("patronymic", editPatronymicM.text.toString())
                    cvManager.put("email", editEmailM.text.toString())
                    cvManager.put("phoneNum", editPhoneM.text.toString())
                    cvManager.put("jobTitle", "M")

                    workMyDB.addRepresentative(cvManager)

                    var id = workMyDB.selectRepresentativeLastId()
                    if (id>0){
                        var editor = settings.edit()
                        editor.putInt(PREF_IDM,workMyDB.selectRepresentativeLastId())
                        editor.putInt(PREF_IDMCurTeam, idManager)
                        editor.apply()
                        finish()
                    }



                }
            cvTrainer = ContentValues()
                if (rbTrainer.isChecked && checkTrainer()){


                    cvTrainer.put("jobTitle", "T");
                    cvTrainer.put("lastname", editLastnameT.text.toString())
                    cvTrainer.put("firstname", editFirstnameT.text.toString())
                    cvTrainer.put("patronymic", editPatronymicT.text.toString())
                    cvTrainer.put("email", editEmailT.text.toString())
                    cvTrainer.put("phoneNum", editPhoneT.text.toString())
                    workMyDB.addRepresentative(cvTrainer)

                    var id = workMyDB.selectRepresentativeLastId()
                    if (id>0){
                        var editor = settings.edit()
                        editor.putInt(PREF_IDT, workMyDB.selectRepresentativeLastId())
                        if (typeWork!="edit")
                            editor.putInt(PREF_IDMCurTeam, idManager)
                        editor.apply()
                        finish()
                    }

                }
            }

    }

    private fun fillCV() {
        cvManager = ContentValues()
        if (manager!=null && manager.lastname!=null) {

            cvManager.put("id", manager.id);
            cvManager.put("lastname", editLastnameM.text.toString())
            cvManager.put("firstname", editFirstnameM.text.toString())
            cvManager.put("patronymic", editPatronymicM.text.toString())
            cvManager.put("email", editEmailM.text.toString())
            cvManager.put("phoneNum", editPhoneM.text.toString())
        }
        cvTrainer = ContentValues()
        if (trainer!=null&& trainer.lastname!=null){

            cvTrainer.put("id", trainer.id);
            cvTrainer.put("lastname", editLastnameT.text.toString())
            cvTrainer.put("firstname", editFirstnameT.text.toString())
            cvTrainer.put("patronymic", editPatronymicT.text.toString())
            cvTrainer.put("email", editEmailT.text.toString())
            cvTrainer.put("phoneNum", editPhoneT.text.toString())
        }


            cvCurTeam = ContentValues()
            cvCurTeam.put("idManager", idManager);
    }

    private fun checkManadger(): Boolean {

        if (editLastnameM.text.isEmpty() || !isCyrillic(editLastnameM.text.toString())){
            Toast.makeText(this@AddStaffTrainers,
                "Ошибка ввода фамилии менеджера!", Toast.LENGTH_SHORT).show()
            return false
        }
        if (editFirstnameM.text.isEmpty() || !isCyrillic(editFirstnameM.text.toString())){
            Toast.makeText(this@AddStaffTrainers,
                "Ошибка ввода имени менеджера!", Toast.LENGTH_SHORT).show()
            return false
        }

        var emailPattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
        val phonePattern: Pattern = Pattern.compile("\\d{11}")

        if ((editEmailM.text.isNotEmpty() && !emailPattern.matcher(editEmailM.text.toString()).find())){
            Toast.makeText(this@AddStaffTrainers,
                "Ошибка ввода email менеджера!", Toast.LENGTH_SHORT).show()
            return false
        }
        if (editPhoneM.text.isNotEmpty() && !phonePattern.matcher(editPhoneM.text.toString()).find()){
            Toast.makeText(this@AddStaffTrainers,
                "Ошибка ввода контактного номера менеджера!", Toast.LENGTH_SHORT).show()
            return false
        }

        return true

    }
    private fun checkTrainer(): Boolean {

        if (editLastnameT.text.isEmpty() || !isCyrillic(editLastnameT.text.toString())){
            Toast.makeText(this@AddStaffTrainers,
                "Ошибка ввода фамилии тренера!", Toast.LENGTH_SHORT).show()
            return false
        }
        if (editFirstnameT.text.isEmpty() || !isCyrillic(editFirstnameT.text.toString())){
            Toast.makeText(this@AddStaffTrainers,
                "Ошибка ввода имени тренера!", Toast.LENGTH_SHORT).show()
            return false
        }

        var emailPattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
        val phonePattern: Pattern = Pattern.compile("\\d{11}")

        if ((editEmailT.text.isNotEmpty() && !emailPattern.matcher(editEmailT.text.toString()).find())){
            Toast.makeText(this@AddStaffTrainers,
                "Ошибка ввода email тренера!", Toast.LENGTH_SHORT).show()
            return false
        }
        if (editPhoneT.text.isNotEmpty() && !phonePattern.matcher(editPhoneT.text.toString()).find()){
            Toast.makeText(this@AddStaffTrainers,
                "Ошибка ввода контактного номера тренера!", Toast.LENGTH_SHORT).show()
            return false
        }

        return true

    }
    fun isCyrillic(s: String): Boolean {
        for (a in s.toCharArray()) {
            if (Character.UnicodeBlock.of(a) != Character.UnicodeBlock.CYRILLIC)
                return false
        }
        return true
    }




}