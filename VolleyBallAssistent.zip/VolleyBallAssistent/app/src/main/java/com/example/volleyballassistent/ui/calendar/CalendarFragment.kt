package com.example.volleyballassistent.ui.calendar

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.volleyballassistent.R
import com.example.volleyballassistent.adapters.MatchForCalendarAdapter
import com.example.volleyballassistent.databinding.ActivityCalendarBinding
import com.example.volleyballassistent.databinding.FragmentCalendarBinding
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewTeam
import com.example.volleyballassistent.workServer.MyApi
import com.example.volleyballassistent.workServer.RetrofitService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [CalendarFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class CalendarFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }
    lateinit var binding: FragmentCalendarBinding
    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewTeam : ViewTeam

    lateinit var matchAdapter: MatchForCalendarAdapter
    lateinit var recyclerView: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentCalendarBinding.inflate(layoutInflater)
        db= MainDB.getDatabase(this.requireContext(), CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewTeam = ViewTeam(repository, db.wordDao())
        observer()
        // Inflate the layout for this fragment
        return binding.root
    }
    private fun observer(){
        viewTeam.getMatchesForCalendar(RetrofitService().retrofit.create(MyApi::class.java))
        viewTeam.allMatches.observe(this.viewLifecycleOwner) {
            recyclerView = binding.recyclerView1
            matchAdapter = MatchForCalendarAdapter()
            var llm = LinearLayoutManager(this.requireContext(), LinearLayoutManager.VERTICAL, false)
            recyclerView.layoutManager = llm
            recyclerView.setHasFixedSize(true)
            recyclerView.adapter = matchAdapter
            matchAdapter.setList(it, context = this.requireContext())

        }

    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment CalendarFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            CalendarFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}