package com.example.volleyballassistent.workServer.models

import com.example.volleyballassistent.models.TeamForTrainMatch
import com.example.volleyballassistent.workDB.models.Team




class PlayerToServer {
    val id = 0
    val namePlayer: String? = null
    val position: String? = null
    val number = 0
    val captain = false
    val team: TeamToServer? = null
}