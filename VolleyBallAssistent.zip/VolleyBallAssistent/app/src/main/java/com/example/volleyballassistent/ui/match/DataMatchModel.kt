package com.example.volleyballassistent.ui.match

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.volleyballassistent.controllers.OfficialMatch
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workDB.models.TeamWithPlayers
import com.example.volleyballassistent.workServer.models.UserToServer

class DataMatchModel: ViewModel() {
    val team1:MutableLiveData<TeamWithPlayers> by lazy {
        MutableLiveData<TeamWithPlayers>()
    }
    val team2:MutableLiveData<TeamWithPlayers> by lazy {
        MutableLiveData<TeamWithPlayers>()
    }
    val match:MutableLiveData<Match> by lazy {
        MutableLiveData<Match>()
    }

    val dataMatch:MutableLiveData<OfficialMatch> by lazy {
        MutableLiveData<OfficialMatch>()
    }
    val countSets:MutableLiveData<Int> by lazy {
        MutableLiveData<Int>()
    }
    val user: MutableLiveData<UserToServer> by lazy {
        MutableLiveData<UserToServer>()
    }
    val transition: MutableLiveData<Boolean> by lazy {
        MutableLiveData<Boolean>()
    }
}