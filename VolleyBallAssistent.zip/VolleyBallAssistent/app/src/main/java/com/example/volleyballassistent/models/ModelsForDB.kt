package com.example.volleyballassistent.models

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workDB.models.Player
import com.example.volleyballassistent.workDB.models.Team
import com.example.volleyballassistent.workDB.models.TeamWithPlayers

class ModelsForDB : ViewModel() {
    val listTeamWithPlayersDB: MutableLiveData<MutableList<TeamWithPlayers>> by lazy {
        MutableLiveData<MutableList<TeamWithPlayers>>()
    }
    val match: MutableLiveData<Match> by lazy {
        MutableLiveData<Match>()
    }
    val teams: MutableLiveData<MutableList<Team>> by lazy {
        MutableLiveData<MutableList<Team>>()
    }
}