package com.example.volleyballassistent.controllers;

import com.example.volleyballassistent.models.ChronologyPoints;
import com.example.volleyballassistent.models.TeamForTrainMatch;

import java.util.ArrayList;
import java.util.List;


//логика проведения тренировочного матча без таймеров
public class TrainMatch {
    //settings
    int pointsToWin;//максимальное количество очков в партии (не учитывая разрыв в 2 очка)
    int setsToWin;//максимальное количество партий
    boolean setsAccounting;
    boolean timeBrakeAccounting;
    int pointsForTimeBrake;


    //teams
    TeamForTrainMatch teamA;
    TeamForTrainMatch teamB;
    //data match
    List<ChronologyPoints> chronologyPoints;
    ChronologyPoints currentSetsChronPoint;
    int numSet;


    public TrainMatch(int pointsToWin, boolean setsAccounting, int setsToWin, boolean timeBrakeAccounting,int pointsForTimeBrake, TeamForTrainMatch teamA, TeamForTrainMatch teamB) {
        this.pointsToWin = pointsToWin;
        this.setsAccounting=setsAccounting;
        this.setsToWin = setsAccounting?setsToWin:0;
        this.pointsForTimeBrake = pointsForTimeBrake;
        this.timeBrakeAccounting = timeBrakeAccounting;
        this.teamA = teamA;
        this.teamB = teamB;

        chronologyPoints = new ArrayList<>();
        numSet=1;
        currentSetsChronPoint = new ChronologyPoints();
        currentSetsChronPoint.setNumSet(numSet);
    }

    public boolean addPointTA(){

        teamA.addCurScore();
        currentSetsChronPoint.getChronologyPoint().add("A");
        return checkEndPart();
    }
    public boolean addPointTB(){
        teamB.addCurScore();
        currentSetsChronPoint.getChronologyPoint().add("B");
        return checkEndPart();
    }

        public boolean deletePointTA(){
        if(teamA.getCurScore()>0)
            teamA.deleteCurScore();
        //убираем очко из хронологии
        for (int i = currentSetsChronPoint.getChronologyPoint().size()-1; i>=0; i--) {
            if(currentSetsChronPoint.getChronologyPoint().get(i).equals("A")){
                currentSetsChronPoint.getChronologyPoint().remove(i);
                break;
            }
        }
        return checkEndPart();
    }

    public boolean deletePointTB(){
        if(teamB.getCurScore()>0)
            teamB.deleteCurScore();
        //убираем очко из хронологии
        for (int i = currentSetsChronPoint.getChronologyPoint().size()-1; i>=0; i--) {
            if(currentSetsChronPoint.getChronologyPoint().get(i).equals("B")){
                currentSetsChronPoint.getChronologyPoint().remove(i);
                break;
            }
        }
        return checkEndPart();
    }


    //возвращаем флаг на продолжение матча
    boolean checkEndPart(){
        if (timeBrakeAccounting && numSet==setsToWin){
            //проверка на окончание партии
            if (teamA.getCurScore()>=pointsForTimeBrake && teamA.getCurScore()-teamB.getCurScore()>=2) {
                //записываем в хронологию очков номер партии
                currentSetsChronPoint.setNumSet(numSet);
                //добавляем в общий список
                if(chronologyPoints.size()<numSet) chronologyPoints.add(currentSetsChronPoint);
                //обновляем хронологию
                numSet++;
                currentSetsChronPoint = new ChronologyPoints();
                currentSetsChronPoint.setNumSet(numSet);
                //добавляем выигравшей команде очко за партию
                teamA.addScorePart();
                //обнуляем текущий счет
                teamA.setCurScore(0);
                teamB.setCurScore(0);
                return true;

            }
            else {
                if (teamB.getCurScore() >= pointsForTimeBrake && teamB.getCurScore() - teamA.getCurScore() >= 2) {
                    //записываем в хронологию очков номер партии
                    currentSetsChronPoint.setNumSet(numSet);
                    //добавляем в общий список
                    if(chronologyPoints.size()<numSet) chronologyPoints.add(currentSetsChronPoint);
                    //обновляем хронологию
                    numSet++;
                    currentSetsChronPoint = new ChronologyPoints();
                    currentSetsChronPoint.setNumSet(numSet);


                    //добавляем выигравшей команде очко за партию
                    teamB.addScorePart();
                    //обнуляем текущий счет
                    teamA.setCurScore(0);
                    teamB.setCurScore(0);
                    return true;
                }
            }
            return false;
        }
        else{
            //проверка на окончание партии
            if (teamA.getCurScore()>=pointsToWin && teamA.getCurScore()-teamB.getCurScore()>=2) {
                //записываем в хронологию очков номер партии
                currentSetsChronPoint.setNumSet(numSet);
                //добавляем в общий список
                if(chronologyPoints.size()<numSet) chronologyPoints.add(currentSetsChronPoint);
                //обновляем хронологию
                numSet++;
                currentSetsChronPoint = new ChronologyPoints();
                currentSetsChronPoint.setNumSet(numSet);
                //добавляем выигравшей команде очко за партию
                teamA.addScorePart();
                //обнуляем текущий счет
                teamA.setCurScore(0);
                teamB.setCurScore(0);
                return true;

            }
            else {
                if (teamB.getCurScore() >= pointsToWin && teamB.getCurScore() - teamA.getCurScore() >= 2) {
                    //записываем в хронологию очков номер партии
                    currentSetsChronPoint.setNumSet(numSet);
                    //добавляем в общий список
                    if(chronologyPoints.size()<numSet) chronologyPoints.add(currentSetsChronPoint);
                    //обновляем хронологию
                    numSet++;
                    currentSetsChronPoint = new ChronologyPoints();
                    currentSetsChronPoint.setNumSet(numSet);


                    //добавляем выигравшей команде очко за партию
                    teamB.addScorePart();
                    //обнуляем текущий счет
                    teamA.setCurScore(0);
                    teamB.setCurScore(0);
                    return true;
                }
            }

            return false;
        }


    }

    //проверка на окончание матча
    public boolean checkEndMatch(){
        //проверка на конец матча
        if (!setsAccounting)
            return false;
        if (teamA.getScorePart()>(double)setsToWin/2 || teamB.getScorePart()>(double)setsToWin/2)
            return true;
        else
            return false;
    }

    public int getPointsToWin() {
        return pointsToWin;
    }

    public void setPointsToWin(int pointsToWin) {
        this.pointsToWin = pointsToWin;
    }

    public int getSetsToWin() {
        return setsToWin;
    }

    public void setSetsToWin(int setsToWin) {
        this.setsToWin = setsToWin;
    }

    public TeamForTrainMatch getTeamA() {
        return teamA;
    }

    public void setTeamA(TeamForTrainMatch teamA) {
        this.teamA = teamA;
    }

    public TeamForTrainMatch getTeamB() {
        return teamB;
    }

    public void setTeamB(TeamForTrainMatch teamB) {
        this.teamB = teamB;
    }

    public List<ChronologyPoints> getChronologyPoints() {
        if (chronologyPoints.size()<numSet) {
            List<ChronologyPoints> list = chronologyPoints;
            list.add(currentSetsChronPoint);
            return list;
        }


        return chronologyPoints;
    }

    public void setChronologyPoints(List<ChronologyPoints> chronologyPoints) {
        this.chronologyPoints = chronologyPoints;
    }

    public ChronologyPoints getCurrentSetsChronPoint() {
        return currentSetsChronPoint;
    }

    public void setCurrentSetsChronPoint(ChronologyPoints currentSetsChronPoint) {
        this.currentSetsChronPoint = currentSetsChronPoint;
    }

    public int getNumSet() {
        return numSet;
    }

    public void setNumSet(int numSet) {
        this.numSet = numSet;
    }

    public boolean isTimeBrakeAccounting() {
        return timeBrakeAccounting;
    }

    public void setTimeBrakeAccounting(boolean timeBrakeAccounting) {
        this.timeBrakeAccounting = timeBrakeAccounting;
    }
}
