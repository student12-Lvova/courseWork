package com.example.volleyballassistent.workServer.models

class TeamToServer{
    var id = 0
    var nameTeam: String? = null
    var address: String? = null
    var user: UserToServer? = null
    var fio: String? = null
    var email: String? = null
    val match: List<TeamToServer>? = null
}