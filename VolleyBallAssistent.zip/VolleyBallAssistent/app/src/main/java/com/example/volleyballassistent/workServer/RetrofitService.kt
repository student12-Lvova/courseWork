package com.example.volleyballassistent.workServer

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class RetrofitService {
    public lateinit var retrofit:Retrofit
    public constructor(){
        var gsonBuilder = GsonBuilder();
        gsonBuilder.setLenient();
        var gson = gsonBuilder.create();
// and in you adapter set this instance
        GsonConverterFactory.create(gson)
        retrofit = Retrofit.Builder()
            .baseUrl("http://192.168.100.14:8080")
            .addConverterFactory(GsonConverterFactory.create(Gson()))
            .build()
    }
}