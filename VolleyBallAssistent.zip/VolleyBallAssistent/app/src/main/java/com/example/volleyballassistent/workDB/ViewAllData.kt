package com.example.volleyballassistent.workDB

import androidx.lifecycle.*
import com.example.volleyballassistent.workDB.models.*
import com.example.volleyballassistent.workServer.models.PlayerToServer
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.util.*

class ViewAllData(repository:MyDBRepository, dao: Dao): ViewModel() {
    var dao = dao
    var repository = repository
    fun allDataDelete(){
        viewModelScope.launch {
            repository.deleteAllData()
        }
    }
    fun loadAllTeams(teams:ArrayList<Team>) {
        viewModelScope.launch {
            insertTeams(teams)
        }
    }
    fun loadAllMatches(matches:ArrayList<Match>) {
        viewModelScope.launch {
            insertMatches(matches)
        }
    }
    fun loadUser(user: User)= viewModelScope.launch {
        repository.insertUser(user)
    }
    fun updateUser(user: User)= viewModelScope.launch {
        repository.updateUser(user)
    }

    fun insertTeams(teams:ArrayList<Team>)= viewModelScope.launch {
        repository.insertTeams(teams)
    }
    fun insertPlayers(players: ArrayList<Player>)= viewModelScope.launch {
        repository.insertPlayers(players)
    }
    fun insertMatches(matches:ArrayList<Match>)= viewModelScope.launch {
        repository.insertMatches(matches)
    }

    fun loadAllPlayers(playerToServer: ArrayList<Player>) {
        viewModelScope.launch {
            insertPlayers(playerToServer)
        }
    }

}
class AllDataViewModelFactory(private val repository: MyDBRepository, private val dao: Dao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ViewTeam::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ViewAllData(repository, dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}