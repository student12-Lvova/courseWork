package com.example.volleyballassistent.workServer.auth

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.volleyballassistent.controllers.OfficialMatch
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workDB.models.TeamWithPlayers
import com.example.volleyballassistent.workServer.models.UserToServer

class DataModelAuth: ViewModel() {
    val status:MutableLiveData<String> by lazy {
        MutableLiveData<String>()
    }
}