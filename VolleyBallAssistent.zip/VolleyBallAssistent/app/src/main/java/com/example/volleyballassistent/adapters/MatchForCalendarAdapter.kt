package com.example.volleyballassistent.adapters

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.example.volleyballassistent.R
import com.example.volleyballassistent.StartMatchActivity
import com.example.volleyballassistent.models.TeamForTrainMatch
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewTeam
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workDB.models.Team
import kotlinx.android.synthetic.main.choosing_team_serve_ball.view.*
import kotlinx.android.synthetic.main.fragment_inf_about_match.view.*
import kotlinx.android.synthetic.main.item_for_list_matches.view.*
import kotlinx.android.synthetic.main.list_inf_matches.view.*
import kotlinx.android.synthetic.main.list_teams.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import java.util.ArrayList

class MatchForCalendarAdapter:RecyclerView.Adapter<MatchForCalendarAdapter.MatchForCalendarViewHolder>() {
    lateinit var mySharedPreferences: SharedPreferences
    private val section = "current_match"
    private val idTeam1 = "idTeam1"
    private val idTeam2 = "idTeam2"
    private val idMatch = "idMatch"
    private val setsToWin = "setsToWin"
    private val nameTeamServeBall = "nameTeamServeBall"
    lateinit var prefEditor: SharedPreferences.Editor

    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewTeam : ViewTeam

    var team1 = Team(null,"", "", "", "")
    var team2 = Team(null,"", "", "", "")

    private var matchesList = listOf<Match>().toMutableList()
    private lateinit var context:Context

    class MatchForCalendarViewHolder(view:View):RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MatchForCalendarViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_for_list_matches, parent, false)
        return MatchForCalendarViewHolder(view)
    }

    override fun getItemCount(): Int {
        return matchesList.size
    }

    override fun onBindViewHolder(holder: MatchForCalendarViewHolder, position: Int) {
        holder.itemView.tvDateMatchForCalendar.text = matchesList[position].dateMatch

        holder.itemView.tvNameMatchForCalendar.text = matchesList[position].name

        if (holder.itemView.tvIdMatchForCalendar!=null) {
            holder.itemView.tvIdMatchForCalendar.text = matchesList[position].id!!.toString()
            holder.itemView.tvIdMatchForCalendar.visibility = View.GONE
        }

        if (holder.itemView.btn_startMatch!=null)
            holder.itemView.btn_startMatch.setOnClickListener {
                var currentMatch = Match(null, "", "", "", true,false,
                    false, false,  null, null)
                for(match in matchesList){
                    if((it.parent as LinearLayout).tvIdMatchForCalendar.text.toString().toInt() == match.id){
                        currentMatch = match
                        break
                    }
                }


                prefEditor = mySharedPreferences.edit()
                prefEditor.putLong(idTeam1, currentMatch.team1Id!!.toLong())
                prefEditor.putLong(idTeam2, currentMatch.team2Id!!.toLong())
                prefEditor.putLong(idMatch, currentMatch.id!!.toLong())



                observer(currentMatch.team1Id!!, currentMatch.team2Id!!)

                detailCurmatch()


            }
    }

    private fun detailCurmatch() {
        var dialogView = LayoutInflater.from(context).inflate(R.layout.fragment_inf_about_match, null)
        var builder = AlertDialog.Builder(context)
            .setView(dialogView)
            .setCancelable(true)
        var title = LayoutInflater.from(context).inflate(R.layout.title_dialog, null) as TextView?
        title!!.text = "Детали матча"
        builder.setCustomTitle(title)
        var alert = builder.show()

        dialogView.ed_nameMatch.visibility = View.GONE
        dialogView.et_descMatch.visibility = View.GONE
        dialogView.btn_Save.visibility = View.VISIBLE

        var sets=3;
        var protocole=false
        var sendEmail=false
        var translation=false

        var arr = arrayOf("3","5")
        dialogView.numPiker_countSets1.minValue = 0
        dialogView.numPiker_countSets1.maxValue = arr.size-1
        dialogView.numPiker_countSets1.displayedValues = arr
        dialogView.numPiker_countSets1.value = 0

        dialogView.cb_sendEmails.visibility = View.GONE

        dialogView.btn_Save.setOnClickListener {
            prefEditor.putBoolean("protocole", protocole)
            prefEditor.putBoolean("sendEmail", sendEmail)
            prefEditor.putBoolean("translation", translation)
            prefEditor.putInt(setsToWin, sets)
            prefEditor.apply()
            choosingTeamServeBall()
        }
        dialogView.cb_protocol.setOnCheckedChangeListener { view, isChecked ->
            protocole = isChecked
        }
        dialogView.cb_sendEmails.setOnCheckedChangeListener { view, isChecked ->
            sendEmail = isChecked
        }
        dialogView.cb_transition.setOnCheckedChangeListener { view, isChecked ->
            translation = isChecked
        }
        dialogView.numPiker_countSets1.setOnValueChangedListener{ picker, oldVal, newVal ->
            sets = oldVal
        }
    }

    private fun observer(idTeam1: Int, idTeam2: Int) {
        viewTeam = ViewTeam(repository, db.wordDao())
        viewTeam.getTeamById(idTeam1.toLong(), 1)
        viewTeam.cur_team1.observe(context as androidx.lifecycle.LifecycleOwner) {
            team1 = it.team
            viewTeam.getTeamById(idTeam2.toLong(),2)
            viewTeam.cur_team2.observe(context as androidx.lifecycle.LifecycleOwner) { team ->
                team2 = team.team
            }
        }

    }


    fun setList(list: List<Match>, context: Context){



        this.context = context
        db= MainDB.getDatabase(context, CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewTeam = ViewTeam(repository, db.wordDao())
        notifyDataSetChanged()
        mySharedPreferences = context.getSharedPreferences(section, Context.MODE_PRIVATE)
        matchesList=checkMatches(list)

    }

    private fun checkMatches(list: List<Match>): MutableList<Match> {
        var result = listOf<Match>().toMutableList()
        list.forEach { match ->
            var team1 = match.team1Id
            var team2 = match.team2Id

            viewTeam.getTeamById(team1!!.toLong(), 1)
            viewTeam.cur_team1.observe(context as androidx.lifecycle.LifecycleOwner) {
                if (it.players.size>=6){
                    viewTeam.getTeamById(team2!!.toLong(),2)
                    viewTeam.cur_team2.observe(context as androidx.lifecycle.LifecycleOwner) { team ->
                        if (it.players.size>=6)
                            result.add(match)
                        matchesList = result
                        notifyDataSetChanged()
                    }
                }

            }


        }
        return result

    }

    fun getList():MutableList<Match>{
        return matchesList
    }

    private fun choosingTeamServeBall() {

        var dialogView = LayoutInflater.from(context).inflate(R.layout.choosing_team_serve_ball, null)
        var builder = AlertDialog.Builder(context)
            .setView(dialogView)
            .setCancelable(false)
        var title = LayoutInflater.from(context).inflate(R.layout.title_dialog, null) as TextView?
        title!!.text = "Назначение команды, начинающей подавать!"
        builder.setCustomTitle(title)
        var alert = builder.show()

        var teamServeBall = ""

        dialogView.btnTeam1.text = team1.name
        dialogView.btnTeam1.setOnClickListener{
            teamServeBall = team1.name
            startMatch(teamServeBall)
            alert.dismiss()
        }
        dialogView.btnTeam2.text = team2.name
        dialogView.btnTeam2.setOnClickListener{
            teamServeBall = team2.name
            startMatch(teamServeBall)
            alert.dismiss()
        }
        dialogView.btnRandChoose.setOnClickListener{
            val rnds = (0..1).random()
            teamServeBall = if(rnds==0) team1.name else team2.name
            Toast.makeText(
                context,
                "Начинает команда $teamServeBall", Toast.LENGTH_SHORT).show()
            startMatch(teamServeBall)
            alert.dismiss()

        }

    }

    private fun startMatch(team:String) {
        prefEditor.putString(nameTeamServeBall, team)
        prefEditor.apply()
        val intent = Intent(context, StartMatchActivity::class.java)
        context.startActivity(intent)
    }
}