package com.example.volleyballassistent.workDB

import android.app.Activity
import android.widget.GridLayout
import androidx.annotation.WorkerThread
import androidx.lifecycle.*
import com.example.volleyballassistent.workDB.models.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*

class MyDBRepository (private val  dao:Dao){
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun insertMatch(match: Match):Long {
        return dao.insertMatch(match)
    }
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun insertMatches(matches: ArrayList<Match>) {
        return dao.insertListMatch(matches)
    }
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun insertTeam(team: Team):Long {
        return dao.insertTeam(team)
    }
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun insertTeams(teams: ArrayList<Team>) {
        return dao.insertListTeam(teams)
    }
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun updateTeam(team: Team) {
        dao.updateTeam(team)
    }
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun insertPlayer(player: Player):Long {
        return dao.insertPlayer(player)
    }
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun insertPlayers(players: ArrayList<Player>) {
        return dao.insertListPlayer(players)
    }
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun updatePlayer(player: Player) {
        dao.updatePlayer(player)
    }
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun deleteAllPlayers(idTeam:Long) {
        dao.deleteAllPlayers(idTeam)
    }
//    fun getPlayers(idTeam:Long):LiveData<List<Player>>{
//        return dao.getAllPlayer(idTeam).asLiveData()
//    }

    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun insertUser(user: User) {
        return dao.insertUser(user)
    }
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun updateUser(user: User) {
        return dao.updateUser(user)
    }
    @Suppress("RedundantSuspendModifier")
    @WorkerThread
    suspend fun deleteAllData() {
        dao.deleteAllMatches()
        dao.deleteAllPlayers()
        dao.deleteAllTeams()
    }


    fun createNewMatch(match:Match, team1WithPlayers:TeamWithPlayers, team2WithPlayers:TeamWithPlayers){
        if (team1WithPlayers.team.id!=null){

        }
    }

}