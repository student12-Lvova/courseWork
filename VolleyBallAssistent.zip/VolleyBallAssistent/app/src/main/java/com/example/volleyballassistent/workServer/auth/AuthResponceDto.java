package com.example.volleyballassistent.workServer.auth;

import java.util.Date;

public class AuthResponceDto {
    public Long userId;
    public String token;
    public Date issuedAt;
    public Date expiresAt;
}
