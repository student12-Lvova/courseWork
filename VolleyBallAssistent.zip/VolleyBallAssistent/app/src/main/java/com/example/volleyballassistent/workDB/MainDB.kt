@file:OptIn(InternalCoroutinesApi::class)

package com.example.volleyballassistent.workDB

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workDB.models.Player
import com.example.volleyballassistent.workDB.models.Team
import com.example.volleyballassistent.workDB.models.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.InternalCoroutinesApi
import kotlinx.coroutines.internal.synchronized
import kotlinx.coroutines.launch

@Database(entities = [Team::class, Player::class, Match::class, User::class], version = 4)
abstract class MainDB: RoomDatabase() {
        abstract fun wordDao(): Dao

        companion object {
            @Volatile
            private var INSTANCE: MainDB? = null

            fun getDatabase(
                context: Context,
                scope: CoroutineScope
            ): MainDB {
                // if the INSTANCE is not null, then return it,
                // if it is, then create the database
                return INSTANCE ?:  synchronized(this) {
                    val instance = Room.databaseBuilder(
                        context.applicationContext,
                        MainDB::class.java,
                        "volleyballAssistent"
                    )
                        // Wipes and rebuilds instead of migrating if no Migration object.
                        // Migration is not part of this codelab.
                        .fallbackToDestructiveMigration()
                        .addCallback(DBCallback(scope))
                        .build()
                    INSTANCE = instance
                    // return instance
                    instance
                }
            }

            private class DBCallback(
                private val scope: CoroutineScope
            ) : RoomDatabase.Callback() {
                /**
                 * Override the onCreate method to populate the database.
                 */
                override fun onCreate(db: SupportSQLiteDatabase) {
                    super.onCreate(db)
                    // If you want to keep the data through app restarts,
                    // comment out the following line.
                    INSTANCE?.let { database ->
                            scope.launch(Dispatchers.IO) {
                            populateDatabase(database.wordDao())
                        }
                    }
                }
            }

            /**
             * Populate the database in a new coroutine.
             * If you want to start with more words, just add them.
             */
            suspend fun populateDatabase(dao: Dao) {
                dao.deleteAllPlayers()
                dao.deleteAllMatches()
                dao.deleteAllTeams()
                //получаем данные с сервера
            }
        }
}