package com.example.volleyballassistent.controllers;

import android.os.Build;

import com.example.volleyballassistent.models.ChronologyPoints;
import com.example.volleyballassistent.models.TeamForTrainMatch;
import com.example.volleyballassistent.workServer.MyApi;
import com.example.volleyballassistent.workServer.RetrofitService;
import com.example.volleyballassistent.workServer.models.Translation;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


//логика проведения тренировочного матча без таймеров
public class OfficialMatch {
    RetrofitService retrofitService;
    MyApi api;

    //settings
    int pointsToWin;//максимальное количество очков в партии (не учитывая разрыв в 2 очка)
    int setsToWin;//максимальное количество партий
    boolean setsAccounting;
    boolean timeBrakeAccounting;
    int pointsForTimeBrake;
    public boolean teamTransition=true;

    public boolean flagTranslation=false;
    public Translation liveTranslation;
    public List<String> storyScoreSets;
    int idTran=-3;

    //teams
    TeamForTrainMatch teamA;
    TeamForTrainMatch teamB;
    //data match
    List<ChronologyPoints> chronologyPoints;
    ChronologyPoints currentSetsChronPoint;
    int numSet;

    public OfficialMatch(int setsToWin) {
        this.setsToWin = setsToWin;
        chronologyPoints = new ArrayList<>();
        numSet=1;
        currentSetsChronPoint = new ChronologyPoints();
        currentSetsChronPoint.setNumSet(numSet);
        pointsToWin = 25;
        setsAccounting=true;
        timeBrakeAccounting=true;
        pointsForTimeBrake = 15;
        storyScoreSets = new ArrayList<>();
        liveTranslation = new Translation();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            liveTranslation.setDateUpdate(LocalDateTime.now().toString());
        }
        liveTranslation.setCurScoreTeam1("0");
        liveTranslation.setCurScoreTeam2("0");
        liveTranslation.setStoryScores("");

        retrofitService = new RetrofitService();
        api = retrofitService.retrofit.create(MyApi.class);
    }

    public void addPointTA(){
        teamTransition=true;
        teamA.addCurScore();
        currentSetsChronPoint.getChronologyPoint().add("A");
        if (flagTranslation){
            liveTranslation.setCurScoreTeam1(String.valueOf(teamA.getCurScore()));
            if (liveTranslation.getId()==null) insertLiveTranslation();
            else setLiveTranslation();
        }

    }
    public void addPointTB(){
        teamTransition=true;
        teamB.addCurScore();
        currentSetsChronPoint.getChronologyPoint().add("B");
        if (flagTranslation){
            liveTranslation.setCurScoreTeam2(String.valueOf(teamB.getCurScore()));
            if (liveTranslation.getId()==null) insertLiveTranslation();
            else setLiveTranslation();
        }

    }

    public void deletePointTA(){
        teamTransition=false;
        if(teamA.getCurScore()>0)
            teamA.deleteCurScore();

        //убираем очко из хронологии
        for (int i = currentSetsChronPoint.getChronologyPoint().size()-1; i>=0; i--) {
            if(currentSetsChronPoint.getChronologyPoint().get(i).equals("A")){
                currentSetsChronPoint.getChronologyPoint().remove(i);
                break;
            }
        }
        if (flagTranslation){
            liveTranslation.setCurScoreTeam1(String.valueOf(teamA.getCurScore()));
            if (liveTranslation.getId()==null) insertLiveTranslation();
            else setLiveTranslation();
        }
    }
    public void deletePointTB(){
        teamTransition=false;
        if(teamB.getCurScore()>0)
            teamB.deleteCurScore();

        //убираем очко из хронологии
        for (int i = currentSetsChronPoint.getChronologyPoint().size()-1; i>=0; i--) {
            if(currentSetsChronPoint.getChronologyPoint().get(i).equals("B")){
                currentSetsChronPoint.getChronologyPoint().remove(i);
                break;
            }
        }
        if (flagTranslation){
            liveTranslation.setCurScoreTeam2(String.valueOf(teamB.getCurScore()));
            if (liveTranslation.getId()==null) insertLiveTranslation();
            else setLiveTranslation();
        }
    }

    public String nameTeamForSides(String name){
        if (name=="A") {
            if (numSet == setsToWin) {
                if ((teamA.getCurScore() >= 8 && teamB.getCurScore() < teamA.getCurScore()) ||
                        (teamB.getCurScore() >= 8 && teamA.getCurScore() < teamB.getCurScore()))
                    return teamB.getName();
                else return teamA.getName();
            }
            if (numSet % 2 == 1) return teamA.getName();
            else return teamB.getName();
        }
        else{
            if (numSet == setsToWin) {
                if ((teamA.getCurScore() >= 8 && teamB.getCurScore() < teamA.getCurScore()) ||
                        (teamB.getCurScore() >= 8 && teamA.getCurScore() < teamB.getCurScore()))
                    return teamA.getName();
                else return teamB.getName();
            }
            if (numSet % 2 == 1) return teamB.getName();
            else return teamA.getName();
        }
    }
    //возвращаем флаг на продолжение матча
    public boolean checkEndPart(){
        if(numSet==setsToWin){
            //проверка на окончание партии
            if (teamA.getCurScore()>=15 && teamA.getCurScore()-teamB.getCurScore()>=2) {
                //записываем в хронологию очков номер партии
                currentSetsChronPoint.setNumSet(numSet);
                //добавляем в общий список
                if(chronologyPoints.size()<numSet) chronologyPoints.add(currentSetsChronPoint);
                //обновляем хронологию
                //добавляем выигравшей команде очко за партию
                teamA.addScorePart();
                storyScoreSets.add("Партия " + numSet + " "+teamA.getCurScore() + ":" + teamB.getCurScore() + " выиграла команда " + teamA.getName());
                liveTranslation.setStoryScores(liveTranslation.getStoryScores() + " " + teamA.getCurScore() + ":" + teamB.getCurScore());
                numSet++;
                currentSetsChronPoint = new ChronologyPoints();
                currentSetsChronPoint.setNumSet(numSet);

                return true;

            }
            else {
                if (teamB.getCurScore() >= 15 && teamB.getCurScore() - teamA.getCurScore() >= 2) {
                    //записываем в хронологию очков номер партии
                    currentSetsChronPoint.setNumSet(numSet);
                    //добавляем в общий список
                    if(chronologyPoints.size()<numSet) chronologyPoints.add(currentSetsChronPoint);


                    //добавляем выигравшей команде очко за партию
                    teamB.addScorePart();
                    storyScoreSets.add("Партия " + numSet + " "+teamA.getCurScore() + ":" + teamB.getCurScore() + " выиграла команда " + teamB.getName());
                    liveTranslation.setStoryScores(liveTranslation.getStoryScores() + " " + teamA.getCurScore() + ":" + teamB.getCurScore());
                    //обнуляем текущий счет
                    //обновляем хронологию
                    numSet++;
                    currentSetsChronPoint = new ChronologyPoints();
                    currentSetsChronPoint.setNumSet(numSet);
                    return true;
                }
            }
            return false;
        }
        else{
            //проверка на окончание партии
            if (teamA.getCurScore()>=pointsToWin && teamA.getCurScore()-teamB.getCurScore()>=2) {
                //записываем в хронологию очков номер партии
                currentSetsChronPoint.setNumSet(numSet);
                //добавляем в общий список
                if(chronologyPoints.size()<numSet) chronologyPoints.add(currentSetsChronPoint);
                //обновляем хронологию
                teamA.addScorePart();
                storyScoreSets.add("Партия " + numSet + " " + teamA.getCurScore() + ":" + teamB.getCurScore() + " выиграла команда " + teamA.getName());
                liveTranslation.setStoryScores(liveTranslation.getStoryScores() + " " + teamA.getCurScore() + ":" + teamB.getCurScore());
                liveTranslation.setCurScoreTeam1("");
                liveTranslation.setCurScoreTeam2("");
                numSet++;
                currentSetsChronPoint = new ChronologyPoints();
                currentSetsChronPoint.setNumSet(numSet);

                return true;

            }
            else {
                if (teamB.getCurScore() >= pointsToWin && teamB.getCurScore() - teamA.getCurScore() >= 2) {
                    //записываем в хронологию очков номер партии
                    currentSetsChronPoint.setNumSet(numSet);
                    //добавляем в общий список
                    if(chronologyPoints.size()<numSet) chronologyPoints.add(currentSetsChronPoint);
                    teamB.addScorePart();
                    storyScoreSets.add("Партия " + numSet + " " + teamA.getCurScore() + ":" + teamB.getCurScore() + " выиграла команда " + teamB.getName());
                    liveTranslation.setStoryScores(liveTranslation.getStoryScores() + " " + teamA.getCurScore() + ":" + teamB.getCurScore());
                    numSet++;
                    currentSetsChronPoint = new ChronologyPoints();
                    currentSetsChronPoint.setNumSet(numSet);
                    return true;
                }
            }

            return false;
        }


    }

    //проверка на окончание матча
    public boolean checkEndMatch(){
        //проверка на конец матча
        if (teamA.getScorePart()>(double)setsToWin/2 || teamB.getScorePart()>(double)setsToWin/2) {
            if(teamA.getScorePart()>(double)setsToWin/2)
                storyScoreSets.add("Матч окончен в пользу команды " + teamA.getName() + " со счетом "+ teamA.getScorePart() + ":" + teamB.getScorePart() );
            if(teamB.getScorePart()>(double)setsToWin/2)
                storyScoreSets.add("Матч окончен в пользу команды " + teamB.getName() + " со счетом "+ teamA.getScorePart() + ":" + teamB.getScorePart() );
            return true;
        }
        else
            return false;
    }

    public void insertLiveTranslation() {
        Call<Long> call = api.saveTransaction(liveTranslation);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            liveTranslation.setDateUpdate(LocalDateTime.now().toString());
        }
        call.enqueue(new Callback<Long>() {
            @Override
            public void onResponse(Call<Long> call, Response<Long> response) {
                if (response.body()!=null && response.body()!=-1L){
                    idTran = response.body().intValue();
                    flagTranslation = true;
                    liveTranslation.setId(response.body().intValue());
                }
                else
                    flagTranslation = false;

            }
            @Override
            public void onFailure(Call<Long> call, Throwable t) {
                flagTranslation = false;
            }
        });
    }
    public void setLiveTranslation() {
        Call<Long> call = api.updateTransaction(liveTranslation) ;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            liveTranslation.setDateUpdate(LocalDateTime.now().toString());
        }
        call.enqueue(new Callback<Long>() {
            @Override
            public void onResponse(Call<Long> call, Response<Long> response) {
                if (response.body()!=null && response.body()>-1L)
                    flagTranslation = true;
                else
                    flagTranslation = false;

            }
            @Override
            public void onFailure(Call<Long> call, Throwable t) {
                flagTranslation = false;
            }
        });
    }

    public int getPointsToWin() {
        return pointsToWin;
    }

    public void setPointsToWin(int pointsToWin) {
        this.pointsToWin = pointsToWin;
    }

    public int getSetsToWin() {
        return setsToWin;
    }

    public void setSetsToWin(int setsToWin) {
        this.setsToWin = setsToWin;
    }

    public TeamForTrainMatch getTeamA() {
        return teamA;
    }

    public void setTeamA(TeamForTrainMatch teamA) {
        this.teamA = teamA;
    }

    public TeamForTrainMatch getTeamB() {
        return teamB;
    }

    public void setTeamB(TeamForTrainMatch teamB) {
        this.teamB = teamB;
    }

    public List<ChronologyPoints> getChronologyPoints() {
        if (chronologyPoints.size()<numSet) {
            List<ChronologyPoints> list = chronologyPoints;
            list.add(currentSetsChronPoint);
            return list;
        }
        return chronologyPoints;
    }

    public void setChronologyPoints(List<ChronologyPoints> chronologyPoints) {
        this.chronologyPoints = chronologyPoints;
    }

    public ChronologyPoints getCurrentSetsChronPoint() {
        return currentSetsChronPoint;
    }

    public void setCurrentSetsChronPoint(ChronologyPoints currentSetsChronPoint) {
        this.currentSetsChronPoint = currentSetsChronPoint;
    }

    public int getNumSet() {
        return numSet;
    }

    public void setNumSet(int numSet) {
        this.numSet = numSet;
    }

    public boolean isTimeBrakeAccounting() {
        return timeBrakeAccounting;
    }

    public void setTimeBrakeAccounting(boolean timeBrakeAccounting) {
        this.timeBrakeAccounting = timeBrakeAccounting;
    }
}
