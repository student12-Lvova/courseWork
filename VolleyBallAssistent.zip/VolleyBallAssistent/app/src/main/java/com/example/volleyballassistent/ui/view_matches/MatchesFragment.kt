package com.example.volleyballassistent.ui.view_matches

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.volleyballassistent.adapters.MatchAdapter
import com.example.volleyballassistent.adapters.TeamsAdapter
import com.example.volleyballassistent.databinding.FragmentMatchesBinding
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewTeam
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class MatchesFragment : Fragment() {

    private var _binding: FragmentMatchesBinding? = null

    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewTeam : ViewTeam

    lateinit var matchAdapter: MatchAdapter
    lateinit var recyclerView: RecyclerView
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    lateinit var mySharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentMatchesBinding.inflate(inflater, container, false)
        val root: View = binding.root
        db= MainDB.getDatabase(this.requireContext(), CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewTeam = ViewTeam(repository, db.wordDao())
        mySharedPreferences = this.requireActivity().getSharedPreferences("work",
            AppCompatActivity.MODE_PRIVATE
        )
        if (mySharedPreferences.getString("statusWork", "1")!="1" &&
            mySharedPreferences.getString("statusWork", "1")!=""){
            binding.tvStatusMatches.text = "Матчи не загруженны"
        }else{
            binding.tvStatusMatches.visibility= View.GONE
        }


        observer()
        return root
    }

    private fun observer(){
        viewTeam.getMatches()
        viewTeam.allMatches.observe(viewLifecycleOwner) {
            recyclerView = binding.recyclerView
            matchAdapter = MatchAdapter()
            recyclerView.adapter = matchAdapter
            matchAdapter.setList(it, this.requireContext())
        }

    }



    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}