package com.example.volleyballassistent.workDB

import androidx.room.*
import androidx.room.Dao
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workDB.models.Player
import com.example.volleyballassistent.workDB.models.Team
import com.example.volleyballassistent.workDB.models.User


@Dao
interface Dao {
    @Transaction
    @Query("SELECT * FROM User where id=0")
    suspend fun getUser(): User
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertUser(user: User?)
    @Update(onConflict = OnConflictStrategy.IGNORE)
    suspend fun updateUser(user:User)

    @Transaction
    @Query("SELECT * FROM Team where id=:id")
    suspend fun getTeam(id:Long): Team
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTeam(team: Team?): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListTeam(teams: List<Team>)
    @Delete
    suspend fun deleteTeam(team:Team)
    @Update(onConflict = OnConflictStrategy.IGNORE)
    suspend fun updateTeam(team:Team)
    @Transaction
    @Query("SELECT * FROM Team")
    suspend fun getAllTeam(): List<Team>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: Player?): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListPlayer(players: List<Player>)
    @Delete
    suspend fun deletePlayer(player:Player)
    @Update(onConflict = OnConflictStrategy.IGNORE)
    suspend fun updatePlayer(player:Player)
    @Transaction
    @Query("SELECT * FROM Player where team_id=:idTeam")
    suspend fun getAllPlayer(idTeam:Long): List<Player>
    @Query("DELETE FROM Player where team_id=:idTeam")
    suspend fun deleteAllPlayers(idTeam:Long)

    @Transaction
    @Query("SELECT * FROM Match where id=:id")
    suspend fun getMatch(id:Long): Match
    @Query("Update Match set description = :description where id=:id")
    suspend fun updateDescMatch(id:Long, description:String)
    @Insert
    suspend fun insertMatch(match: Match):Long
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListMatch(matches: List<Match>)
    @Transaction
    @Query("SELECT * FROM Match")
    suspend fun getAllMatch(): List<Match>

    //удаление всех данных
    @Query("DELETE FROM Player where id>=0")
    suspend fun deleteAllPlayers()
    @Query("DELETE FROM Match where id>=0")
    suspend fun deleteAllMatches()
    @Query("DELETE FROM Team where id>=0")
    suspend fun deleteAllTeams()

}