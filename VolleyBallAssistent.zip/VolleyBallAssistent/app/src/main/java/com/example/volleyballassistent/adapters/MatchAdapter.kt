package com.example.volleyballassistent.adapters

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.example.volleyballassistent.R
import com.example.volleyballassistent.StartMatchActivity
import com.example.volleyballassistent.models.TeamForTrainMatch
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewTeam
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workDB.models.Team
import kotlinx.android.synthetic.main.choosing_team_serve_ball.view.*
import kotlinx.android.synthetic.main.item_for_list_matches.view.*
import kotlinx.android.synthetic.main.list_inf_matches.view.*
import kotlinx.android.synthetic.main.list_teams.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class MatchAdapter:RecyclerView.Adapter<MatchAdapter.MatchViewHolder>() {
    lateinit var mySharedPreferences: SharedPreferences
    private val section = "current_match"
    private val idTeam1 = "idTeam1"
    private val idTeam2 = "idTeam2"
    private val idMatch = "idMatch"
    private val setsToWin = "setsToWin"
    private val nameTeamServeBall = "nameTeamServeBall"
    lateinit var prefEditor: SharedPreferences.Editor

    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewTeam : ViewTeam

    var team1 = Team(null,"", "", "", "")
    var team2 = Team(null,"", "", "", "")

    private var matchesList = listOf<Match>()
    private lateinit var context:Context

    class MatchViewHolder(view:View):RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MatchViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.list_inf_matches, parent, false)
        return MatchViewHolder(view)
    }

    override fun getItemCount(): Int {
        return matchesList.size
    }

    override fun onBindViewHolder(holder: MatchViewHolder, position: Int) {
        holder.itemView.tvDateMatch.text = matchesList[position].dateMatch
        holder.itemView.tvNameMatch.text = matchesList[position].name
        holder.itemView.tvDespMatch.text = matchesList[position].description


    }


    fun setList(list: List<Match>, context: Context){
        matchesList = list
        this.context = context
        notifyDataSetChanged()
        mySharedPreferences = context.getSharedPreferences(section, Context.MODE_PRIVATE)
    }
    fun getList():List<Match>{
        return matchesList
    }

}