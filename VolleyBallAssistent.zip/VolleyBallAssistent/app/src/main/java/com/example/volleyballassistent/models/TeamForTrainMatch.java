package com.example.volleyballassistent.models;

import com.example.volleyballassistent.workDB.models.Team;

public class TeamForTrainMatch {

    String name;
    String nameRep;
    String emailRep;
    int curScore;
    int scorePart;

    public TeamForTrainMatch(Team team) {
        this.name = team.getName();
        this.nameRep = team.getNameRepresentative();
        this.emailRep = team.getEmailRepresentative();
        this.curScore = 0;
        this.scorePart = 0;
    }

    public void addCurScore(){
        curScore++;
    }
    public void addScorePart(){
        scorePart++;
    }
    public void deleteCurScore(){
        curScore--;
    }
    public void deleteScorePart(){
        scorePart--;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getCurScore() {
        return curScore;
    }
    public void setCurScore(int curScore) {
        this.curScore = curScore;
    }

    public int getScorePart() {
        return scorePart;
    }
    public void setScorePart(int scorePart) {
        this.scorePart = scorePart;
    }

    public String getNameRep() {
        return nameRep;
    }

    public void setNameRep(String nameRep) {
        this.nameRep = nameRep;
    }

    public String getEmailRep() {
        return emailRep;
    }

    public void setEmailRep(String emailRep) {
        this.emailRep = emailRep;
    }
}
