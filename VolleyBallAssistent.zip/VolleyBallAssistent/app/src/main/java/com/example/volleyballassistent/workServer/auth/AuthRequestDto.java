package com.example.volleyballassistent.workServer.auth;

public class AuthRequestDto {
    public String login;
    public String password;
}
