package com.example.volleyballassistent.workServer.models

import com.example.volleyballassistent.workDB.models.Team
import java.time.LocalDate


class MatchToServer{
    var id = 0
    var nameMatch: String? = null
    var description: String? = null
    var dateMatch: String? = null
    var user: UserToServer? = null
    var teams: List<TeamToServer>? = null
    var flagCalendar = false
}