package com.example.volleyballassistent.workDB.models

import androidx.room.Embedded
import androidx.room.Relation

class TeamWithPlayers() {
    constructor(team: Team, listPlayerTeam: MutableList<Player>) : this( ){
        this.team = team
        this.players = listPlayerTeam
    }

    lateinit var team : Team
    lateinit var players : MutableList<Player>

}