package com.example.volleyballassistent.workServer.models

class UserToServer {
    var id:Int? = null
    var login: String? = null
    var password: String? = null
    var email: String? = null
    val role_id: String? = null
}