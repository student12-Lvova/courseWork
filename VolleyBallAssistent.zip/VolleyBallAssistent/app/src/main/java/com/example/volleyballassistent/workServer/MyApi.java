package com.example.volleyballassistent.workServer;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.example.volleyballassistent.workDB.models.Match;
import com.example.volleyballassistent.workDB.models.Player;
import com.example.volleyballassistent.workDB.models.Team;
import com.example.volleyballassistent.workDB.models.User;
import com.example.volleyballassistent.workServer.auth.AuthRequestDto;
import com.example.volleyballassistent.workServer.auth.AuthResponceDto;
import com.example.volleyballassistent.workServer.models.MatchToServer;
import com.example.volleyballassistent.workServer.models.PlayerToServer;
import com.example.volleyballassistent.workServer.models.TeamToServer;
import com.example.volleyballassistent.workServer.models.Translation;
import com.example.volleyballassistent.workServer.models.UserToServer;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface MyApi {

    //-------------авторизация ---------------------------------------------------------------
    @POST("/api/registration")
    @Nullable
    Call<UserToServer> registration(@Body UserToServer user);
    @POST("/api/login")
    @Nullable
    Call<UserToServer> login(@Body UserToServer user);

    //--------------проверка подключения к серверу ---------------------------------------------------------------
    @GET("/api/connect")
    @Nullable
    Call<Long> connect();

    //--------------изменение пользователя ---------------------------------------------------------------
    @POST("/api/user/update")
    @Nullable
    Call<Boolean> updateUserToServer(@Body UserToServer user);

    //---------------получение данных пользователя ---------------------------------------------------------------
    @POST("/api/dataUser")
    @Nullable
    Call<UserToServer> getUserById(@Body long idUser);
    @POST("/api/dataUser/matches")
    @Nullable
    Call<List<MatchToServer>> getAllMatchesForUser(@Body long idUser);
    @POST("/api/dataUser/teams")
    @Nullable
    Call<List<TeamToServer>> getAllTeamsForUser(@Body long idUser);
    @POST("/api/dataUser/team")
    @Nullable
    Call<TeamToServer> getAllTeamsById(@Body long idTeam);
    @POST("/api/dataUser/players")
    @Nullable
    Call<List<PlayerToServer>> getAllPlayersForUser(@Body long idUser);

    //------------ трансляция матча ---------------------------------------------------------------
    @POST("/api/translation/save")
    @Nullable
    Call<Long> saveTransaction(@Body Translation translation);
    @POST("/api/translation/update")
    @Nullable
    Call<Long> updateTransaction(@Body Translation liveTranslation);

    //
    @POST("/api/dataUser/insertMatch")
    @Nullable
    Call<Long> insertMatchToServer(@Body MatchToServer match);
}
