package com.example.volleyballassistent.models;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.volleyballassistent.workDB.models.Player;
import com.example.volleyballassistent.workDB.models.Team;
import com.example.volleyballassistent.workDB.models.TeamWithPlayers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class TeamPlacementWithMatch {

    public TeamWithPlayers team;
    public String captainTeam;
    public int countPlacement =0;
    public List<PlayerForMatch> players;
    public List<PlayerForMatch> playersForPlayground;
    public List<PlayerForMatch> playersForPlacement;

    public TeamPlacementWithMatch() {
    }

    public TeamPlacementWithMatch(TeamWithPlayers team) {
        this.team = team;
        players = new ArrayList<PlayerForMatch>();
        for (Player player: team.getPlayers()) {
            if (player.getCaptain())
                captainTeam = player.getName();
            this.players.add(new PlayerForMatch(player.getGameNumber(), player.getName(), player.getPosition(), 0, -1));
        }
        this.countPlacement = 0;
        playersForPlayground = new ArrayList<PlayerForMatch>();
        playersForPlacement = new ArrayList<PlayerForMatch>();
        for(int i=0; i<6; i++)
            playersForPlayground.add(new PlayerForMatch(-1, "0", "0", 0, -1));
    }

    public void addPlayersForPlaygroundForIndex(int index, PlayerForMatch player){
        playersForPlayground.set(index, player);
    }

    public void setListPlacementForPlayer(){
        for(PlayerForMatch pl : players)
            if (!playersForPlayground.contains(pl))
                playersForPlacement.add(pl);
    }

    public String placement(PlayerForMatch playerWho, PlayerForMatch playerWhom) {
        if (countPlacement<6) {
            switch (playerWho.getStatus()) {
                case 0: {
                    if (playerWhom.getStatus() == 0) {
                        int ind = -1;
                        ind = playersForPlayground.indexOf(playerWho);

                        changeStatus(playerWho, playersForPlayground, 1);
                        playerWhom.setWhoPlacementGameNumber(playerWho.getGameNumber());
                        changeStatus(playerWhom, playersForPlacement, 2);
                        countPlacement++;

                        if (ind != -1)
                            playersForPlayground.set(ind, playerWhom);
                        playersForPlacement.remove(playerWhom);

                        return "Игрок с номером " + playerWho.getGameNumber() + " заменен на игрока " + playerWhom.getGameNumber();
                    } else return "Выбранного игрока нельзя заменить";
                }
                case 2: {
                    if (playerWho.getWhoPlacementGameNumber() == playerWhom.getGameNumber()) {

                        int ind = -1;
                        ind = playersForPlayground.indexOf(playerWho);
                        changeStatus(playerWho, playersForPlayground, 3);
                        changeStatus(playerWhom, playersForPlacement, 3);
                        if (ind != -1)
                            playersForPlayground.set(ind, playerWhom);

                        if (playersForPlacement.contains(playerWho))
                            playersForPlacement.remove(playerWho);
                        if (playersForPlacement.contains(playerWhom))
                            playersForPlacement.remove(playerWhom);

                        return "Обратная замена игрока " + playerWho.getGameNumber();
                    } else return "Выбранного игрока нельзя заменить";

                }
                default:
                    return "Выбранного игрока нельзя заменить";
            }
        } else  return "Превышено количество замен в партии";
    }
    private void changeStatus(PlayerForMatch player, List<PlayerForMatch> players, int status){
        int ind = -1;
        int indMainList = -1;
        ind = players.indexOf(player);
        indMainList = this.players.indexOf(player);
        player.setStatus(status);
        if (ind!=-1)
            players.set(ind, player);
        if (indMainList!=-1)
            this.players.set(indMainList, player);


    }

}
