package com.example.volleyballassistent.workDB.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.Companion.CASCADE
import androidx.room.PrimaryKey

@Entity(tableName = "Player", foreignKeys = arrayOf(ForeignKey(entity = Team::class,
    parentColumns = arrayOf("id"),
    childColumns = arrayOf("team_id"),
    onDelete = ForeignKey.CASCADE)))
data class Player(
    @PrimaryKey(autoGenerate = true)
    var id:Long?=null,
    @ColumnInfo(name = "FIO")
    var name:String,
    @ColumnInfo(name = "number")
    var gameNumber:Int,
    @ColumnInfo(name = "position")
    var position:String,
    @ColumnInfo(name = "captain")
    var captain:Boolean,
    @ColumnInfo(name = "team_id")
    var teamId:Long?=null
)
