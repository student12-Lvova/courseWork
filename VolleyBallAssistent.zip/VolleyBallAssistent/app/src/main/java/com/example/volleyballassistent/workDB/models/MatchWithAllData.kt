package com.example.volleyballassistent.workDB.models

import androidx.room.Embedded
import androidx.room.Relation

class MatchWithAllData {
    @Embedded
    var match: Match? = null

    @Relation(parentColumn = "id", entity = Team::class, entityColumn = "team_id")
    var teams: List<Team>? = null
}