package com.example.volleyballassistent

import android.app.Application
import com.example.volleyballassistent.workServer.MyApi
import com.example.volleyballassistent.workServer.RetrofitService
import com.example.volleyballassistent.workServer.models.UserToServer
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class App : Application() {
    lateinit var retrofitService: RetrofitService
    lateinit var api: MyApi

    var status = ""

    override fun onCreate() {
        super.onCreate()
        //Parse SDK stuff goes here

    }
}