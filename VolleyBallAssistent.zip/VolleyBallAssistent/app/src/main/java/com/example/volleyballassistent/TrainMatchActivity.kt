package com.example.volleyballassistent

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.LightingColorFilter
import android.media.MediaPlayer
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.example.volleyballassistent.controllers.TrainMatch
import com.example.volleyballassistent.models.TeamForTrainMatch
import com.example.volleyballassistent.ui.settings.SettingsMatchFragment
import com.example.volleyballassistent.workDB.models.Team
import kotlinx.android.synthetic.main.activity_train_match.*
import kotlinx.android.synthetic.main.timer.view.*
import java.util.*
import kotlin.math.roundToInt

class TrainMatchActivity : AppCompatActivity() {

    lateinit var match: TrainMatch

    lateinit var mySharedPreferences: SharedPreferences
    private val section = "settings"

    private val pointsToWin = "pointsToWin"
    private val flagSets = "flagSets"
    private val setsToWin = "setsToWin"
    private val pointsForTimeBrake = "pointsForTimeBrake"
    private val flagTimeBrake = "flagTimeBrake"
    private val changeOfSidesInTimeBrake = "changeOfSidesInTimeBrake"
    private val flagTimeOut = "flagTimeOut"
    private val timeInTimeOut = "timeInTimeOut"
    private val toss = "toss"

    lateinit var listPointsSetsTeamA:ArrayList<String>
    lateinit var listPointsSetsTeamB:ArrayList<String>

    var pointTeamA = 0
    var pointTeamB = 0
    var flagTimeBrakeTwo:Boolean = false
    lateinit var alert :AlertDialog

    override fun onBackPressed() {
       finish()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_train_match)
        val actionBar: ActionBar? = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)

        mySharedPreferences = this.getSharedPreferences(section, Context.MODE_PRIVATE)
        goToNewFragment(findViewById(R.id.fragment_teamA))
        goToNewFragment(findViewById(R.id.fragment_teamB))

        listPointsSetsTeamA = ArrayList()
        listPointsSetsTeamB = ArrayList()

        match = TrainMatch(mySharedPreferences.getInt(pointsToWin,25),
            mySharedPreferences.getBoolean(flagSets, true),
            mySharedPreferences.getInt(setsToWin,3),
            mySharedPreferences.getBoolean(flagTimeBrake,false),
            mySharedPreferences.getInt(pointsForTimeBrake,15),
            TeamForTrainMatch(Team(null, "", "", "", "")),
            TeamForTrainMatch(Team(null, "", "", "", ""))
        )
        if (mySharedPreferences.getBoolean(toss,false)){
            val rnds = (0..1).random()
            var builder = AlertDialog.Builder(this, R.style.AlertDialog)
                .setPositiveButton("Продолжить") { dialog, id ->}
            var title = layoutInflater.inflate(R.layout.title_dialog, null) as TextView?
            title!!.text = "Начинает " + (if(rnds==0) "Команда 1" else "Команда 2")
            builder.setCustomTitle(title)
            var myDialog = builder.create()
            myDialog.window!!.decorView.background.colorFilter =
                LightingColorFilter(-0x1000000, 0x4D4D4D)
            builder.show()

            imageBall(rnds)
        }else imageBall(-1)

        startTime()

    }

    fun visibleBtnTimeOut(){
        val bundle = Bundle()

// set Fragmentclass Arguments
        val fragobj = TMTeamAFragment()
        fragobj.setArguments(bundle)
    }
    fun imageBall(flag: Int){
        if(match.numSet%2==1)
            when(flag){
                0->{
                    ib_BallTA.visibility = View.VISIBLE
                    ib_BallTB.visibility = View.INVISIBLE
                }
                1->{
                    ib_BallTB.visibility = View.VISIBLE
                    ib_BallTA.visibility = View.INVISIBLE
                }
                else ->{
                    ib_BallTB.visibility = View.INVISIBLE
                    ib_BallTA.visibility = View.INVISIBLE
                }
            }
        else
            when(flag){
                0->{
                    ib_BallTB.visibility = View.VISIBLE
                    ib_BallTA.visibility = View.INVISIBLE
                }
                1->{
                    ib_BallTA.visibility = View.VISIBLE
                    ib_BallTB.visibility = View.INVISIBLE
                }
                else ->{
                    ib_BallTB.visibility = View.INVISIBLE
                    ib_BallTA.visibility = View.INVISIBLE
                }
            }


    }

    private fun startTime() {
        timeMatch.start()
    }
    private fun goToNewFragment(fragment: FrameLayout){
        val mFragment = TMTeamAFragment()
        val mBundle = Bundle()
        mBundle.putBoolean("flagTimeOut", mySharedPreferences.getBoolean(flagTimeOut,false))
        mFragment.arguments = mBundle

        supportFragmentManager
            .beginTransaction()
            .replace(fragment.id, mFragment)
            .addToBackStack(null)
            .commit()
    }

    fun onSvist(view: View?){
        var mp = MediaPlayer.create(this, R.raw.svist);
        mp.start()
    }
    fun onTimeOutTeam(view: View?){
        var teamName = ""
        if (((view?.parent as View).parent as View).id == R.id.fragment_teamA)
                teamName = match.teamA.name
        if (((view?.parent as View).parent as View).id == R.id.fragment_teamB)
            teamName = match.teamB.name

        (view as AppCompatButton).setTextColor(Color.BLACK)
        view.isClickable = false

        var dialogView = LayoutInflater.from(this).inflate(R.layout.timer, null)
        var builder = AlertDialog.Builder(this, R.style.AlertDialog)
            .setView(dialogView)
            .setTitle("Тайм-аут команды $teamName")
            .setCancelable(false)
        alert = builder.show()

        startTimer(dialogView.timerTimeOut)

        dialogView.btnEndTimeOut.setOnClickListener{
            alert.dismiss()
        }


    }
    fun onScoreTeam(view: View?){
        match.teamA.name = findViewById<FrameLayout>(R.id.fragment_teamA)
            .findViewById<EditText>(R.id.etNameTeam).text.toString()
        match.teamB.name = findViewById<FrameLayout>(R.id.fragment_teamB)
            .findViewById<EditText>(R.id.etNameTeam).text.toString()
        when(((view?.parent as View).parent as View).id){
            R.id.fragment_teamA ->{
                pointTeamA = (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam)
                    .text.toString().toInt() + 1
                if (!flagTimeBrakeTwo)
                    imageBall(0)
                else imageBall(1)
                if(match.addPointTA()) {
                    var str = (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam).text.toString()
                    (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam)
                        .text = (str.toInt() + 1).toString()
                    changeOfSides(true)
                }
                else{
                    if(match.isTimeBrakeAccounting && mySharedPreferences.getBoolean(changeOfSidesInTimeBrake,false)
                        && pointTeamA == (mySharedPreferences.getInt(pointsForTimeBrake,15).toFloat()/2).roundToInt()
                        && match.numSet==match.setsToWin){
                        changeOfSides(false)
                    }
                }

                (view as AppCompatButton).text = (match.teamA.curScore).toString()
            }
            R.id.fragment_teamB ->{
                pointTeamB = (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam)
                    .text.toString().toInt() + 1
                if (!flagTimeBrakeTwo)
                    imageBall(1)
                else imageBall(0)
                if(match.addPointTB()) {
                    var str = (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam).text.toString()
                    (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam)
                        .text = (str.toInt() + 1).toString()
                    changeOfSides(true)
                }
                else{
                    if(match.isTimeBrakeAccounting && mySharedPreferences.getBoolean(changeOfSidesInTimeBrake,false)
                        && pointTeamB == (mySharedPreferences.getInt(pointsForTimeBrake,15).toFloat()/2).roundToInt()
                        && match.numSet==match.setsToWin){
                        changeOfSides(false)
                    }
                }
                (view as AppCompatButton).text = (match.teamB.curScore).toString()
            }
        }
    }
    fun onMinusScoreTeam(view: View?){
        when(((view?.parent as View).parent as View).id){
            R.id.fragment_teamA ->{
                pointTeamA = (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam)
                    .text.toString().toInt() - 1
                if (match.deletePointTA()) {
                    var str = (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam).text.toString()
                    (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam).text =
                        ((str.toInt() - 1).toString())
                    changeOfSides(true)
                }
                else (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam)
                        .text = (match.teamA.curScore).toString()
                if (match.currentSetsChronPoint.chronologyPoint
                        .get(match.currentSetsChronPoint.chronologyPoint.size-1).equals("A"))
                    imageBall(0)
                else imageBall(1)

            }
            R.id.fragment_teamB -> {
                pointTeamB = (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam)
                    .text.toString().toInt() - 1
                    if (match.deletePointTB()) {
                        var str = (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam).text.toString()
                        (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam).text =
                            (str.toInt() - 1).toString()
                        changeOfSides(true)
                    }
                    else (view.parent as View).findViewById<AppCompatButton>(R.id.btnScoreTeam)
                        .text = (match.teamB.curScore).toString()

                if (match.currentSetsChronPoint.chronologyPoint
                        .get(match.currentSetsChronPoint.chronologyPoint.size-1).equals("A"))
                    imageBall(0)
                else imageBall(1)
                }


        }
    }

    private fun startTimer(timerTimeOut: TextView) {
        val timer = object: CountDownTimer((mySharedPreferences.getInt(timeInTimeOut,60)).toLong()*1000, 1000) {//минута
        override fun onTick(p0: Long) {
            var p = p0 / 1000
            if (p>=10)
                timerTimeOut.text = "00:$p"
            else
                timerTimeOut.text = "00:0$p"
        }
            override fun onFinish() {
                alert.dismiss()
            }
        }
        timer.start()
    }
    fun changeOfSides(flag:Boolean) {
        listPointsSetsTeamA.add(pointTeamA.toString())
        listPointsSetsTeamB.add(pointTeamB.toString())
        var fA = fragment_teamA
        var fB = fragment_teamB


        if (!flag){
            frameLayout.removeAllViews()
            frameLayout1.removeAllViews()
            flagTimeBrakeTwo = true
            frameLayout.addView(fB)
            frameLayout1.addView(fA)
        }
        else{
            flagTimeBrakeTwo=false
            if (!match.checkEndMatch()){
                frameLayout.removeAllViews()
                frameLayout1.removeAllViews()
                pointTeamA=0
                pointTeamB=0
                ll_ScoreSets.removeAllViews()

                if (match.numSet%2==0){//1 и тд
                    //var helpFragment = fragment_teamB
                    for (pointsSets in listPointsSetsTeamA){
                        var v = TextView(this)
                        v.textSize = 20.0f
                        v.setText("${listPointsSetsTeamB.get(listPointsSetsTeamA.indexOf(pointsSets))}:" +
                                "${pointsSets}")
                        ll_ScoreSets.addView(v)
                    }
                    frameLayout.addView(fB)
                    frameLayout1.addView(fA)
                }
                else{
                    for (pointsSets in listPointsSetsTeamA){
                        var v = TextView(this)
                        v.textSize = 20.0f
                        v.setText("${pointsSets}:" +
                                "${listPointsSetsTeamB.get(listPointsSetsTeamA.indexOf(pointsSets))}")
                        ll_ScoreSets.addView(v)
                    }
                    frameLayout.addView(fA)
                    frameLayout1.addView(fB)
                }

                fragment_teamA.findViewById<AppCompatButton>(R.id.btnScoreTeam).text = "0"
                updateBtnTimeOut(fragment_teamA.findViewById(R.id.btnTimeOut1))
                updateBtnTimeOut(fragment_teamA.findViewById(R.id.btnTimeOut2))
                fragment_teamB.findViewById<AppCompatButton>(R.id.btnScoreTeam).text = "0"
                updateBtnTimeOut(fragment_teamB.findViewById(R.id.btnTimeOut1))
                updateBtnTimeOut(fragment_teamB.findViewById(R.id.btnTimeOut2))
            }
            else{
                endMatch()
            }
            visibleBtnTimeOut()


        }
    }
    private fun endMatch(){
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Матч окончен")
            .setMessage("Победила " +
                    if(match.teamA.scorePart!=match.teamB.scorePart){
                        "команда " +
                        if(match.teamA.scorePart>match.teamB.scorePart) match.teamA.name else match.teamB.name
                    }
                    else{
                        if(match.teamA.curScore==match.teamB.curScore) "Дружба!"
                        else{
                            "команда " +
                            if(match.teamA.curScore>match.teamB.curScore) match.teamA.name else match.teamB.name
                        }
                    })
            .setPositiveButton("ОК") {
                    dialog, id ->  dialog.cancel()
                val intent = Intent(this, Main2Activity::class.java)
                startActivity(intent)
            }
        builder.create().show()
    }
    private fun updateBtnTimeOut(findViewById: AppCompatButton?) {
        findViewById?.setTextColor(Color.WHITE)
        findViewById?.isClickable = false
    }
    var column=0;
    private fun columnsForChronologyPoints():ArrayList<Int>{
        var columns = ArrayList<Int>()
        columns.add(column)
        columns.add(column+1)
        column += 2

        return columns
    }

    fun onChronologyPoints(view: View?){
        grid.removeAllViews()

        for (points in match.chronologyPoints){
            var countPointTeamA = 0
            var countPointTeamB = 0
            var numPoint=1

            var nameTeamA = TextView(this)
            nameTeamA.text = "К1"
            var nameTeamB = TextView(this)
            nameTeamB.text = "К2"

            var curColumns = columnsForChronologyPoints()
            addGridLayout(curColumns[0], 0, nameTeamA)
            addGridLayout(curColumns[1], 0, nameTeamB)
            //заполняем строки
            for (point in points.chronologyPoint) {
                numPoint++
                var teamA = AppCompatButton(this)
                teamA.textSize = 8F
                var teamB = AppCompatButton(this)
                teamB.textSize = 8F
                if (point.equals("A")){
                    var arr = createFieldsGridLayout(++countPointTeamA,teamA,teamB)
                    teamA=arr[0]
                    teamB=arr[1]
                }
                else{
                    var arr = createFieldsGridLayout(++countPointTeamB,teamB,teamA)
                    teamB=arr[0]
                    teamA=arr[1]
                }
                addGridLayout(curColumns[0], numPoint, teamA)
                addGridLayout(curColumns[1], numPoint, teamB)
            }
        }


    }

    private fun createFieldsGridLayout(countPointTeamA:Int, team1: AppCompatButton, team2:AppCompatButton):ArrayList<AppCompatButton>{
        team1.text = countPointTeamA.toString()
        team1.isClickable = false
        team2.text = ""
        team2.isClickable = false
        team2.background.alpha = 0
        var arr = ArrayList<AppCompatButton>()
        arr.add(team1)
        arr.add(team2)
        return arr
    }

    private fun addGridLayout(numColumn: Int, numRow: Int, view: View) {
        val layoutParams = GridLayout.LayoutParams()
        // кнопка помещается в нулевой столбец и растягивается на 1 столбец
        layoutParams.columnSpec = GridLayout.spec(numColumn, 1)
        // кнопка помещается во вторую строку и растягивается на 1 строку
        layoutParams.rowSpec = GridLayout.spec(numRow, 1)
        layoutParams.width = 120
        layoutParams.height = 110
        if (numColumn%2!=0)
            layoutParams.rightMargin = 50
        grid.addView(view, layoutParams)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main2, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.itemMenu_endMatch -> {
                endMatch()
                return true
            }
            R.id.itemMenu_toss -> {
                if(match.teamA.curScore==0&&match.teamB.curScore==0){
                    val rnds = (0..1).random()
                    if (rnds==0)
                        Toast.makeText(applicationContext,
                            "Начинает " + if(match.teamA.name.equals("")) "Команда 1" else match.teamA.name,
                            Toast.LENGTH_SHORT).show()
                    else
                        Toast.makeText(applicationContext,
                            "Начинает " + if(match.teamB.name.equals("")) "Команда 2" else match.teamB.name,
                            Toast.LENGTH_SHORT).show()
                    imageBall(rnds)
                }else{
                    Toast.makeText(applicationContext,"Жеребьевка доступна только в начале партии",
                        Toast.LENGTH_SHORT).show()
                }
                return true
            }
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}