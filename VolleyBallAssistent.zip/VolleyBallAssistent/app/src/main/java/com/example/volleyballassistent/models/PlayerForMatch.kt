package com.example.volleyballassistent.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.Companion.CASCADE
import androidx.room.PrimaryKey


class PlayerForMatch(
    var gameNumber:Int,
    var name:String,
    var position:String,
    // 0 - не заменялся 1- заменен 2 - больше нельзя заменять
    var status:Int,
    //кто заменял
    var whoPlacementGameNumber:Int

)
