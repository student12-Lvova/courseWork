package com.example.volleyballassistent.ui.view_teams

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.volleyballassistent.Main2Activity
import com.example.volleyballassistent.adapters.PlayerAdapter
import com.example.volleyballassistent.adapters.TeamsAdapter
import com.example.volleyballassistent.controllers.OfficialMatch
import com.example.volleyballassistent.databinding.FragmentTeamBinding
import com.example.volleyballassistent.models.TeamForTrainMatch
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewTeam
import com.example.volleyballassistent.workDB.models.Team
import kotlinx.android.synthetic.main.appoint_captain.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class TeamFragment : Fragment() {

    private var _binding: FragmentTeamBinding? = null

    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewTeam : ViewTeam

    lateinit var teamAdapter: TeamsAdapter
    lateinit var recyclerView: RecyclerView

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    lateinit var mySharedPreferences: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTeamBinding.inflate(inflater, container, false)
        val root: View = binding.root
        db= MainDB.getDatabase(this.requireContext(), CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewTeam = ViewTeam(repository, db.wordDao())
        mySharedPreferences = this.requireActivity().getSharedPreferences("work",
            AppCompatActivity.MODE_PRIVATE
        )
        if (mySharedPreferences.getString("statusWork", "1")!="1" &&
            mySharedPreferences.getString("statusWork", "1")!=""){
            binding.tvStatusTeams.text = "Команды не загруженны"
        }else{
            binding.tvStatusTeams.visibility= View.GONE
        }
        observer()
        return root
    }
    private fun observer(){
        viewTeam.getTeams()
        viewTeam.allTeams.observe(viewLifecycleOwner) {
            recyclerView = binding.recyclerView
            teamAdapter = TeamsAdapter()
            recyclerView.adapter = teamAdapter
            teamAdapter.setList(it, this.requireContext())
        }

    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}