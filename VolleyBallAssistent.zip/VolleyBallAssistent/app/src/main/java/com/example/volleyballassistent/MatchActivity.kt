package com.example.volleyballassistent

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.fragment.app.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.example.volleyballassistent.databinding.ActivityMatchBinding
import com.example.volleyballassistent.models.ModelsForDB
import com.example.volleyballassistent.ui.match.DataMatchModel
import com.example.volleyballassistent.adapters.MyPagerAdapter
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewTeam
import com.example.volleyballassistent.workDB.models.*
import com.example.volleyballassistent.workServer.auth.DataModelAuth
import kotlinx.android.synthetic.main.activity_match.*
import kotlinx.android.synthetic.main.add_player.view.*
import kotlinx.android.synthetic.main.appoint_captain.view.*
import kotlinx.android.synthetic.main.choosing_team_serve_ball.view.*
import kotlinx.android.synthetic.main.fragment_inf_about_match.*
import kotlinx.android.synthetic.main.fragment_inf_about_match.view.*
import kotlinx.android.synthetic.main.fragment_profile.*
import kotlinx.android.synthetic.main.fragment_inf_team.*
import kotlinx.android.synthetic.main.fragment_inf_team.view.*
import kotlinx.android.synthetic.main.fragment_settings_match.*
import kotlinx.android.synthetic.main.list_players_for_appoint_captain.view.*
import kotlinx.android.synthetic.main.timer.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.*


class MatchActivity : AppCompatActivity() {
    lateinit var binding: ActivityMatchBinding
    private val dataModel:DataMatchModel by viewModels()
    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewTeam : ViewTeam

    lateinit var mySharedPreferences: SharedPreferences
    private val section = "current_match"
    private val idTeam1 = "idTeam1"
    private val idTeam2 = "idTeam2"
    private val idMatch = "idMatch"
    private val setsToWin = "setsToWin"
    private val nameTeamServeBall = "nameTeamServeBall"
    lateinit var prefEditor: SharedPreferences.Editor

    lateinit var match:Match
    var listPlayerTeam1 : MutableList<Player> = listOf<Player>().toMutableList()
    lateinit var team1: Team
    var listPlayerTeam2 : MutableList<Player> = listOf<Player>().toMutableList()
    lateinit var team2: Team
    lateinit var arr :Array<String>
    var countSets = 3;
    var transition = false;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMatchBinding.inflate(layoutInflater)
        db= MainDB.getDatabase(this, CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewTeam = ViewTeam(repository, db.wordDao())
        setContentView(binding.root)
        val actionBar: ActionBar? = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)


        mySharedPreferences = this.getSharedPreferences(section, Context.MODE_PRIVATE)
        match = Match(null, "", "", "", false,protocol = false, teamPlacement = false,
            false, null, null)
        team1 = Team(null,"", "", "", "")
        team2 = Team(null,"", "", "", "")

            var fragmentAdapter = MyPagerAdapter(supportFragmentManager)
            viewpager.adapter = fragmentAdapter
            tabs.setupWithViewPager(viewpager)

        dataModel.team1.observe(this) {
            team1 =it.team
            listPlayerTeam1 = it.players
        }
        dataModel.team2.observe(this) {
            team2 = it.team
            listPlayerTeam2 = it.players
        }

        dataModel.match.observe(this) {
            match = it
        }
        dataModel.countSets.observe(this){
            countSets = it
        }
        dataModel.transition.observe(this){
            transition = it
        }


        arr = arrayOf("3","5")
    }
    @RequiresApi(Build.VERSION_CODES.O)
    fun onCreateMatch(view: View){
            if (
                checkCountPlayers(listPlayerTeam1, "хозяев") && //проверка игроков первой команды
                checkDataForTeam(team1, "хозяев") &&//проверка данных команды 1
                checkCountPlayers(listPlayerTeam2, "гостей") && //проверка игроков второй команды
                checkDataForTeam(team2, "гостей") &&//проверка данных команды 2
                checkDataForMatch()) {
                if ((team1.id == null || team2.id == null) || team1.id != team2.id) {

                    prefEditor = mySharedPreferences.edit()

                        var team1WithPlayers = TeamWithPlayers(team1, listPlayerTeam1)
                        var team2WithPlayers = TeamWithPlayers(team2, listPlayerTeam2)
                        match.dateMatch = LocalDate.now().toString()
                        viewTeam.insertMatch(match, team1WithPlayers, team2WithPlayers)
                        prefEditor.putInt(setsToWin, countSets)
                        prefEditor.putBoolean("transition", transition)
                        viewTeam.idMatch.observe(this) {
                            viewTeam.getMatchById(it)
                            prefEditor.putLong(idMatch, it)
                            viewTeam.cur_match.observe(this){ match->
                                prefEditor.putLong(idTeam1, match.team1Id!!.toLong())
                                prefEditor.putLong(idTeam2, match.team2Id!!.toLong())
                                prefEditor.putBoolean("transition", transition)
                                prefEditor.apply()
                                choosingTeamServeBall()
                            }

                        }
                    }

                } else {
                    Toast.makeText(
                        this@MatchActivity,
                        "Выбраны одинаковые команды!", Toast.LENGTH_SHORT
                    ).show()
                }


    }
    private fun choosingTeamServeBall() {

        var dialogView = LayoutInflater.from(this).inflate(R.layout.choosing_team_serve_ball, null)
        var builder = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
        var title = layoutInflater.inflate(R.layout.title_dialog, null) as TextView?
        title!!.text = "Назначение команды, начинающей подавать!"
        builder.setCustomTitle(title)
        var alert = builder.show()

        var teamServeBall = ""

        dialogView.btnTeam1.text = team1.name
        dialogView.btnTeam1.setOnClickListener{
            teamServeBall = team1.name
            startMatch(teamServeBall)
            alert.dismiss()
        }
        dialogView.btnTeam2.text = team2.name
        dialogView.btnTeam2.setOnClickListener{
            teamServeBall = team2.name
            startMatch(teamServeBall)
            alert.dismiss()
        }
        dialogView.btnRandChoose.setOnClickListener{
            val rnds = (0..1).random()
            teamServeBall = if(rnds==0) team1.name else team2.name
            Toast.makeText(
                this@MatchActivity,
                "Начинает команда $teamServeBall", Toast.LENGTH_SHORT).show()
            startMatch(teamServeBall)
            alert.dismiss()

        }

    }

    private fun startMatch(team:String) {
        prefEditor.putString(nameTeamServeBall, team)
        prefEditor.apply()

        val intent = Intent(this, StartMatchActivity::class.java)
        startActivity(intent)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun checkDataForMatch(): Boolean {
        if(match.name.isEmpty()){
            Toast.makeText(
                this@MatchActivity,
                "Заполните название матча!", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }
    private fun checkDataForTeam(team: Team, nameTeam: String): Boolean {
        if(team.name.isEmpty()){
            Toast.makeText(
                this@MatchActivity,
                "Заполните название команды $nameTeam!", Toast.LENGTH_SHORT).show()
            return false
        }
        if(team.nameRepresentative.isEmpty()){
            Toast.makeText(
                this@MatchActivity,
                "Заполните ФИО представителя команды $nameTeam!", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }
    private fun checkCountPlayers(list: MutableList<Player>, nameTeam: String): Boolean {
        var flagCaptain = false
        var countPlayer = 0
        if (list.size in 6..14){
            for (pl in list) {
                if (pl.position!="Л") countPlayer++
                if (!flagCaptain)
                    flagCaptain = pl.captain
            }
            return if (!flagCaptain){
                Toast.makeText(
                    this@MatchActivity,
                    "Назначите капитана команды $nameTeam!", Toast.LENGTH_SHORT).show()
                false
            }else{
                if (countPlayer<6){
                    Toast.makeText(
                        this@MatchActivity,
                        "Количество игроков у $nameTeam <6 или >14!", Toast.LENGTH_SHORT).show()
                    false
                }else true
            }


        }
        else Toast.makeText(
            this@MatchActivity,
            "Количество игроков у $nameTeam <6 или >14!", Toast.LENGTH_SHORT).show()
        return false
    }

    override fun onBackPressed() {
        finish()
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

}