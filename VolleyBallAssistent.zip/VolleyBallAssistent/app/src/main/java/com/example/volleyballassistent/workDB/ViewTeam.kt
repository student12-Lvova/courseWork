package com.example.volleyballassistent.workDB

import android.content.Context
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.*
import com.example.volleyballassistent.workDB.models.*
import com.example.volleyballassistent.workServer.MyApi
import com.example.volleyballassistent.workServer.models.MatchToServer
import com.example.volleyballassistent.workServer.models.TeamToServer
import com.example.volleyballassistent.workServer.models.UserToServer
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewTeam(repository:MyDBRepository, dao: Dao): ViewModel() {
    var dao = dao
    var repository = repository

    val allTeams: MutableLiveData<List<TeamWithPlayers>> = MutableLiveData()
    val allMatches: MutableLiveData<List<Match>> = MutableLiveData()
    var listAllTeams: MutableList<TeamWithPlayers> = listOf<TeamWithPlayers>().toMutableList()
    var listMatchesForCalendar: MutableList<Match> = listOf<Match>().toMutableList()
    var idMatch: MutableLiveData<Long> = MutableLiveData()
    var cur_match : MutableLiveData<Match> = MutableLiveData()
    var cur_team1:MutableLiveData<TeamWithPlayers> = MutableLiveData()
    var cur_team2:MutableLiveData<TeamWithPlayers> = MutableLiveData()

    fun getTeams() {
        listAllTeams = listOf<TeamWithPlayers>().toMutableList()
        viewModelScope.launch {
            val teams = dao.getAllTeam()
            for (team in teams){
                listAllTeams.add(TeamWithPlayers(team, dao.getAllPlayer(team.id!!).toMutableList()))
            }
            allTeams.value = listAllTeams
        }
    }
    fun getTeamById(id:Long, num:Int) {
        var twn = TeamWithPlayers()
        viewModelScope.launch {
            twn.team = dao.getTeam(id)
            twn.players = dao.getAllPlayer(id).toMutableList()
            if (num==1)
                cur_team1.value = twn
            else cur_team2.value = twn
        }

    }
    fun getMatchById(id:Long)= viewModelScope.launch {
            cur_match.value = dao.getMatch(id)
    }

    fun getMatches() {
        viewModelScope.launch {
            allMatches.value = dao.getAllMatch()
        }
    }
    fun getMatchesForCalendar(api: MyApi) {
        listMatchesForCalendar = listOf<Match>().toMutableList()
        viewModelScope.launch {
            var matches = dao.getAllMatch()
            matches.forEach {
                if (it.flagCalendar) {
                    listMatchesForCalendar.add(it)
                    updateTeams(it.team1Id,it.team1Id, api)
                }
            }
            allMatches.value = listMatchesForCalendar
        }
    }

    private fun updateTeams(team1Id: Int?, team2Id: Int?, api: MyApi) {
        updateTeamWithServer(team1Id, api);
        updateTeamWithServer(team2Id, api);

    }

    private fun updateTeamWithServer(id: Int?, api: MyApi) {
        var call: Call<TeamToServer>? = api.getAllTeamsById(id!!.toLong())
        if (call!=null){
            call!!.enqueue(object : Callback<TeamToServer> {
                override fun onFailure(call: Call<TeamToServer>, t: Throwable) {
                }
                override fun onResponse(
                    call: Call<TeamToServer>,
                    response: Response<TeamToServer>
                ) {
                    if(response.isSuccessful){
                        var teamToServer = response.body()!!
                        updateTeam(Team(teamToServer.id!!.toLong(), teamToServer.nameTeam!!,
                        teamToServer.address!!, teamToServer.fio!!, teamToServer.email!!))
                    }
                }
            })
        }

    }

    fun insertMatch(match: Match, team1WithPlayers: TeamWithPlayers, team2WithPlayers: TeamWithPlayers) = viewModelScope.launch {
        var idTeam1 = 0L
        var idTeam2 = 0L
        if(team1WithPlayers.team.id==null)
            idTeam1= repository.insertTeam(team1WithPlayers.team)
        else {
            idTeam1 = team1WithPlayers.team.id!!
            updateTeam(team1WithPlayers.team)
            deleteAllPlayers(idTeam1)
        }
        viewModelScope.launch {
            team1WithPlayers.players.forEach {
                if (it.id == null)
                    it.teamId = idTeam1
                insertPlayer(it)
            }
        }

        if(team2WithPlayers.team.id==null)
            idTeam2= repository.insertTeam(team2WithPlayers.team)
        else {
            idTeam2 = team2WithPlayers.team.id!!
            updateTeam(team2WithPlayers.team)
            deleteAllPlayers(idTeam2)
        }
        viewModelScope.launch {
            team2WithPlayers.players.forEach {
                if (it.id == null)
                    it.teamId = idTeam2
                insertPlayer(it)
            }
            match.team1Id = idTeam1.toInt()
            match.team2Id = idTeam2.toInt()
            idMatch.value = repository.insertMatch(match)
        }


    }
    fun insert(match: Match, api:MyApi) = viewModelScope.launch {
        repository.insertMatch(match)
    }

    fun updateTeam(team: Team) = viewModelScope.launch {
        repository.updateTeam(team)
    }
    fun insertTeam(team: Team) = viewModelScope.launch {
        repository.insertTeam(team)
    }

    fun insertPlayer(player: Player) = viewModelScope.launch {
        repository.insertPlayer(player)
    }
    fun updatePlayer(player: Player) = viewModelScope.launch {
        repository.updatePlayer(player)
    }
    fun deleteAllPlayers(id: Long) = viewModelScope.launch {
        repository.deleteAllPlayers(id)
    }

    fun addDescForMatch(api: MyApi, context: Context,id: Long, desc: String) = viewModelScope.launch{
        dao.updateDescMatch(id, desc)

        var match = dao.getMatch(id)
        var matchToServer = MatchToServer()
        matchToServer.id = match.id!!.toInt()
        matchToServer.dateMatch = match.dateMatch;
        matchToServer.nameMatch = match.name;
        matchToServer.description = match.description;
        matchToServer.flagCalendar = false;
        var teams = listOf<TeamToServer>().toMutableList()
        var team1 = getteamToServer(dao.getTeam(match.team1Id!!.toLong()), matchToServer.user);
        var team2:TeamToServer = getteamToServer(dao.getTeam(match.team2Id!!.toLong()), matchToServer.user);

        teams.add(team1)
        teams.add(team2)
        matchToServer.teams = teams
        var sp = context.getSharedPreferences("user",
            AppCompatActivity.MODE_PRIVATE
        )

        var callUser: Call<UserToServer>? =    api.getUserById(sp.getInt("idUser", -1).toLong())
        if (callUser!=null){
            callUser!!.enqueue(object : Callback<UserToServer> {
                override fun onFailure(call: Call<UserToServer>, t: Throwable) {
                }
                override fun onResponse(
                    call: Call<UserToServer>,
                    response: Response<UserToServer>
                ) {
                    if(response.isSuccessful){
                        matchToServer.user = response.body()
                        var call: Call<Long>? = api.insertMatchToServer(matchToServer)
                        if (call!=null){
                            call!!.enqueue(object : Callback<Long> {
                                override fun onFailure(call: Call<Long>, t: Throwable) {
                                }
                                override fun onResponse(
                                    call: Call<Long>,
                                    response: Response<Long>
                                ) {
                                    if(response.isSuccessful){
                                        if (response.body()!!.toLong()!=null)
                                            Toast.makeText(context, "Матч создан!!!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            })
                        }
                    }
                }
            })
        }
    }

    private fun getteamToServer(team: Team, user: UserToServer?): TeamToServer {
        var teamF = TeamToServer()
        teamF.id = team.id!!.toInt()
        teamF.nameTeam = team.name
        teamF.address = team.address
        teamF.fio = team.nameRepresentative
        teamF.email = team.emailRepresentative
        teamF.user = user
        return teamF
    }

    fun insertUser(user: User) = viewModelScope.launch{
        repository.insertUser(user)

    }

    fun updateUser(user: UserToServer) = viewModelScope.launch {
        repository.updateUser(User(user.id!!.toLong(), user.login!!, user.email!!))
    }

}
class TeamViewModelFactory(private val repository: MyDBRepository, private val dao: Dao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ViewTeam::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ViewTeam(repository, dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}