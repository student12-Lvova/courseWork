package com.example.volleyballassistent

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.volleyballassistent.Main2Activity
import com.example.volleyballassistent.R
import com.example.volleyballassistent.StartMatchActivity
import com.example.volleyballassistent.adapters.MatchAdapter
import com.example.volleyballassistent.adapters.MatchForCalendarAdapter
import com.example.volleyballassistent.controllers.OfficialMatch
import com.example.volleyballassistent.databinding.ActivityCalendarBinding
import com.example.volleyballassistent.databinding.ActivityMatchBinding
import com.example.volleyballassistent.ui.calendar.CalendarFragment
import com.example.volleyballassistent.ui.match.DataMatchModel
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewTeam
import kotlinx.android.synthetic.main.activity_calendar.*
import kotlinx.android.synthetic.main.choosing_team_serve_ball.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class CalendarActivity : AppCompatActivity() {
    lateinit var binding: ActivityCalendarBinding



    private val dataModel: DataMatchModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val actionBar: ActionBar? = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        setContentView(R.layout.activity_calendar)

        binding = ActivityCalendarBinding.inflate(layoutInflater)
        supportFragmentManager
            .beginTransaction()
            .replace(binding.fragment.id, CalendarFragment())
            .addToBackStack(null)
            .commit()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }


}