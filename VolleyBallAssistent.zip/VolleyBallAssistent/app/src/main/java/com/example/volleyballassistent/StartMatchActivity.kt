package com.example.volleyballassistent

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.FileProvider
import androidx.core.view.setMargins
import com.example.volleyballassistent.controllers.OfficialMatch
import com.example.volleyballassistent.databinding.ActivityStartMatchBinding
import com.example.volleyballassistent.models.PlayerForMatch
import com.example.volleyballassistent.models.TeamForTrainMatch
import com.example.volleyballassistent.models.TeamPlacementWithMatch
import com.example.volleyballassistent.ui.match.DataMatchModel
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewTeam
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workServer.MyApi
import com.example.volleyballassistent.workServer.RetrofitService
import com.example.volleyballassistent.workServer.auth.DataModelAuth
import com.example.volleyballassistent.workServer.models.UserToServer
import kotlinx.android.synthetic.main.activity_start_match.*
import kotlinx.android.synthetic.main.activity_train_match.fragment_teamA
import kotlinx.android.synthetic.main.activity_train_match.fragment_teamB
import kotlinx.android.synthetic.main.activity_train_match.frameLayout
import kotlinx.android.synthetic.main.activity_train_match.frameLayout1
import kotlinx.android.synthetic.main.activity_train_match.ib_BallTA
import kotlinx.android.synthetic.main.activity_train_match.ib_BallTB
import kotlinx.android.synthetic.main.activity_train_match.timeMatch
import kotlinx.android.synthetic.main.start_line_up_team.view.*
import kotlinx.android.synthetic.main.team_composition.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import java.io.*
import java.time.LocalDate
import java.util.*


class StartMatchActivity : AppCompatActivity() {
    lateinit var mySharedPreferences: SharedPreferences
    private val section = "current_match"
    private val idTeam1 = "idTeam1"
    private val idTeam2 = "idTeam2"
    private val idMatch = "idMatch"
    private val setsToWin = "setsToWin"
    private val prot = "protocole"
    private val sendEmail = "sendEmail"
    private val translation = "translation"
    private val nameTeamServeBall = "nameTeamServeBall"
    private val section1 = "user"
    private val idUser = "idUser"

    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewTeam : ViewTeam

    private val dataModel: DataMatchModel by viewModels()

    var team1 = TeamPlacementWithMatch()
    var team2 = TeamPlacementWithMatch()
    lateinit var match : Match
    lateinit var managmentMatch: OfficialMatch

    var token = ""
    lateinit var retrofitService: RetrofitService

    lateinit var binding: ActivityStartMatchBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStartMatchBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val actionBar: ActionBar? = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)

        db= MainDB.getDatabase(this, CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewTeam = ViewTeam(repository, db.wordDao())

        retrofitService = RetrofitService()

        mySharedPreferences = this.getSharedPreferences(section1, MODE_PRIVATE)
        token = mySharedPreferences.getString("token", "")!!
        mySharedPreferences = this.getSharedPreferences(section, MODE_PRIVATE)
        observer()

    }

    private fun observer(){
        managmentMatch = OfficialMatch(mySharedPreferences.getInt(setsToWin,3))

        managmentMatch.flagTranslation = mySharedPreferences.getBoolean("transition", false)
        var user = UserToServer()
        mySharedPreferences = this.getSharedPreferences(section1, MODE_PRIVATE)
        user.id = mySharedPreferences.getInt(idUser, -1)
        mySharedPreferences = this.getSharedPreferences(section, MODE_PRIVATE)
        managmentMatch.liveTranslation.user = user
        viewTeam.getTeamById(mySharedPreferences.getLong(idTeam1,0), 1)
            viewTeam.cur_team1.observe(this) {
                dataModel.team1.value = it
                managmentMatch.teamA = TeamForTrainMatch(it.team)
                managmentMatch.liveTranslation.team1name = it.team.name

                viewTeam.getTeamById(mySharedPreferences.getLong(idTeam2,0),2)
                viewTeam.cur_team2.observe(this) {
                    dataModel.team2.value = it
                    managmentMatch.teamB = TeamForTrainMatch(it.team)
                    managmentMatch.liveTranslation.team2name = it.team.name

                    viewTeam.getMatchById(mySharedPreferences.getLong(idMatch,0))
                    viewTeam.cur_match.observe(this){
                        dataModel.match.value = it
                        match = it
                        checkDetailsCurMatch()
                        if(mySharedPreferences.getString(nameTeamServeBall,"")==managmentMatch.teamA.name)
                            imageBall(0)
                        if(mySharedPreferences.getString(nameTeamServeBall,"")==managmentMatch.teamB.name)
                            imageBall(1)

                        startWork()
                    }
                }
            }

    }

    private fun checkDetailsCurMatch() {
        var p = mySharedPreferences.getBoolean(prot,false)
        var sE = mySharedPreferences.getBoolean(sendEmail,false)
        var t = mySharedPreferences.getBoolean(translation,false)

        if(p)  match.protocol = p
        if(sE)  match.sendingEmail = sE
        if(t)  managmentMatch.flagTranslation = t
    }

    fun startWork(){
        dataModel.dataMatch.value = managmentMatch
        goToNewFragment(findViewById(R.id.fragment_teamA), 1)
        goToNewFragment(findViewById(R.id.fragment_teamB), 2)

        tv_scoreSets.text = "0:0"
        startTime()

        dataModel.team1.observe(this) {
            team1 = TeamPlacementWithMatch(it)
            managmentMatch.teamA = TeamForTrainMatch(team1.team.team)
            dataModel.team2.observe(this) {
                team2 = TeamPlacementWithMatch(it)
                managmentMatch.teamB = TeamForTrainMatch(team2.team.team)
                appointmentStartingLineUp()
            }
        }

        dataModel.match.observe(this) {    match = it }
        dataModel.dataMatch.observe(this) {
            managmentMatch = it
            var cpAllSets = managmentMatch.chronologyPoints

            if (cpAllSets.size!=0){ 
                var cpLastSet = cpAllSets[cpAllSets.size-1].chronologyPoint
                if (cpLastSet.size!=0){
                    when(cpLastSet[cpLastSet.size-1])
                    {
                        "A" -> imageBall(0)
                        "B" -> imageBall(1)
                        else -> imageBall(-1)
                    }
                    if(managmentMatch.teamTransition){
                        if (cpLastSet.size!=1)
                            teamTransition(cpLastSet[cpLastSet.size-2], cpLastSet[cpLastSet.size-1])
                        else
                            teamTransition("", cpLastSet[cpLastSet.size-1])
                    }

                }
            }
            checkEndPart()
        }
    }
    fun onTransitionBack(view: View?){
        when(view!!.id){
            R.id.ib_backTeam2 -> teamTransitionBack("B")
            R.id.ib_backTeam1 -> teamTransitionBack("A")
        }
    }

    fun onReplacementPlayer(view: View?){
        var str = ""
        when(view!!.id){
            R.id.btnZonaA1 ->{
                replacementPlayer("A", view as AppCompatButton)
            }
            R.id.btnZonaA2 ->{
                replacementPlayer("A", view as AppCompatButton)
            }
            R.id.btnZonaA3 ->{
                replacementPlayer("A", view as AppCompatButton)
            }
            R.id.btnZonaA4 ->{
                replacementPlayer("A", view as AppCompatButton)
            }
            R.id.btnZonaA5 ->{
                replacementPlayer("A", view as AppCompatButton)
            }
            R.id.btnZonaA6 ->{
                replacementPlayer("A", view as AppCompatButton)
            }
            R.id.btnZonaB1 ->{
                replacementPlayer("B", view as AppCompatButton)
            }
            R.id.btnZonaB2 ->{
                replacementPlayer("B", view as AppCompatButton)
            }
            R.id.btnZonaB3 ->{
                replacementPlayer("B", view as AppCompatButton)
            }
            R.id.btnZonaB4 ->{
                replacementPlayer("B", view as AppCompatButton)
            }
            R.id.btnZonaB5 ->{
                replacementPlayer("B", view as AppCompatButton)
            }
            R.id.btnZonaB6 ->{
                replacementPlayer("B", view as AppCompatButton)
            }
        }
    }
    private fun replacementPlayer(namePlace: String,view: AppCompatButton) {
        var list = listOf<PlayerForMatch>().toMutableList()
            if (managmentMatch.nameTeamForSides(namePlace)==managmentMatch.teamA.name)
                //работаем с командой 1
                loadDialogviewForReplacement(view, team1)
            else
                loadDialogviewForReplacement(view, team2)
        }
    private fun loadDialogviewForReplacement(
        view: AppCompatButton,
        team: TeamPlacementWithMatch
    ){
        if (team.countPlacement<6){
            var curPlayer = PlayerForMatch(0,"0","0",0,0)
            team.playersForPlayground.forEach {
                if (it.gameNumber.toString() == view.text.toString()){
                    curPlayer = it
                }
            }
            var whom = PlayerForMatch(-1,"0","0",0,0)
            when (curPlayer!!.status) {
                3 -> {
                    Toast.makeText(
                        this,"Игрок ${curPlayer.gameNumber} не может быть заменен!",
                        Toast.LENGTH_SHORT).show()
                }
                0 -> {
                    if (team.playersForPlacement.size!=0){
                        var dialogView = LayoutInflater.from(this).inflate(R.layout.team_composition, null)
                        var builder = AlertDialog.Builder(this)
                            .setView(dialogView)
                            .setCancelable(true)
                        var title = layoutInflater.inflate(R.layout.title_dialog, null) as TextView?
                        title!!.text = "Замена игрока под номером - ${curPlayer.gameNumber}"
                        builder.setCustomTitle(title)
                        var alert = builder.show()
                        var flagViewLibero = true
                        //если в замене есть хоть один игрок не либеро, то показываем только игроков
                        //если остались только либеро , то показываем их
                        team.playersForPlacement.forEach {
                            if (it.position!="Л") flagViewLibero = false
                        }
                        team.playersForPlacement.forEach { pl ->
                            if (pl.status == 0) {
                                var btn = AppCompatButton(this)
                                btn.text = pl.gameNumber.toString()

                                val layoutParams = GridLayout.LayoutParams()
                                layoutParams.width = 100
                                layoutParams.height = 100
                                layoutParams.setMargins(5)
                                btn.layoutParams = layoutParams
                                btn.setTextColor(Color.BLACK)
                                btn.textSize = 18F

                                btn.setOnClickListener {
                                    var str = team.placement(curPlayer, pl)
                                    Toast.makeText(this, str, Toast.LENGTH_SHORT).show()
                                    alert.dismiss()
                                    if (str != "Выбранного игрока нельзя заменить") {
                                        whom = pl
                                    }
                                    view.text = whom.gameNumber.toString()
                                }
                                if (flagViewLibero) {
                                    btn.setBackgroundResource(R.drawable.ovalorange)
                                    dialogView.team_composition.addView(btn)
                                }
                                else {
                                    if (pl.position!="Л"){
                                        btn.setBackgroundResource(R.drawable.player)
                                        dialogView.team_composition.addView(btn)
                                    }
                                }

                            }
                        }
                    }
                    else
                        Toast.makeText(this,"Нет игроков для замены!", Toast.LENGTH_SHORT).show()
                }
                2 -> {
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("Замена игрока под номером - ${curPlayer.gameNumber}")
                        .setMessage("Провести обратную замену на игрока с номером - ${curPlayer.whoPlacementGameNumber}?")
                        .setCancelable(true)
                        .setPositiveButton("Да") { _, _ ->
                            team.players.forEach {
                                if (it.gameNumber == curPlayer.whoPlacementGameNumber)
                                    whom = it
                            }
                            Toast.makeText(this, team.placement(curPlayer, whom), Toast.LENGTH_LONG).show()
                            view.text = whom.gameNumber.toString()
                        }
                        .setNegativeButton("Нет") { _, _ ->
                            Toast.makeText(this, "Отмена замены!",Toast.LENGTH_LONG).show()
                        }
                    builder.show()
                }
            }
        }else
            Toast.makeText(this,
                "Превышено количество замен в партии команды ${team.team.team.name}!",
                Toast.LENGTH_SHORT).show()


    }

    private fun appointmentStartingLineUp() {
        team1 = TeamPlacementWithMatch(team1.team)
        team2 = TeamPlacementWithMatch(team2.team)
        loadDialogview(1)
    }
    //Заполняем стартовый состав
    private fun loadDialogview(numTeam: Int) {
        var nameTeam = if (numTeam==1) managmentMatch.teamA.name else managmentMatch.teamB.name
        var dialogView = LayoutInflater.from(this).inflate(R.layout.start_line_up_team, null)

        var builder = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)

        var title = layoutInflater.inflate(R.layout.title_dialog, null) as TextView?
        title!!.text = "Стартовый состав команды $nameTeam"
        builder.setCustomTitle(title)

        var alert = builder.show()

        if (numTeam==1) {
            if (managmentMatch.numSet%2!=0){//1
                dialogView.glTeamA.visibility = View.VISIBLE
                dialogView.glTeamB.visibility = View.INVISIBLE
            }else{
                dialogView.glTeamA.visibility = View.INVISIBLE
                dialogView.glTeamB.visibility = View.VISIBLE
            }
        }
        else{
            if (managmentMatch.numSet%2!=0){//1
                dialogView.glTeamA.visibility = View.INVISIBLE
                dialogView.glTeamB.visibility = View.VISIBLE
            }else{
                dialogView.glTeamA.visibility = View.VISIBLE
                dialogView.glTeamB.visibility = View.INVISIBLE
            }
        }

        //выбираем игрока на определенную зону
        dialogView.btnZonaA1.setOnClickListener{
            appointmentPlayerToZone(dialogView.btnZonaA1, numTeam, 1)
        }
        dialogView.btnZonaA2.setOnClickListener{
            appointmentPlayerToZone(dialogView.btnZonaA2, numTeam, 2)
        }
        dialogView.btnZonaA3.setOnClickListener{
            appointmentPlayerToZone(dialogView.btnZonaA3, numTeam, 3)
        }
        dialogView.btnZonaA4.setOnClickListener{
            appointmentPlayerToZone(dialogView.btnZonaA4, numTeam, 4)
        }
        dialogView.btnZonaA5.setOnClickListener {
            appointmentPlayerToZone(dialogView.btnZonaA5, numTeam, 5)
        }
        dialogView.btnZonaA6.setOnClickListener {
            appointmentPlayerToZone(dialogView.btnZonaA6, numTeam, 6)
        }
        dialogView.btnZonaB1.setOnClickListener{
            appointmentPlayerToZone(dialogView.btnZonaB1,numTeam, 1)
        }
        dialogView.btnZonaB2.setOnClickListener{
            appointmentPlayerToZone(dialogView.btnZonaB2, numTeam, 2)
        }
        dialogView.btnZonaB3.setOnClickListener{
            appointmentPlayerToZone(dialogView.btnZonaB3, numTeam, 3)
        }
        dialogView.btnZonaB4.setOnClickListener{
            appointmentPlayerToZone(dialogView.btnZonaB4, numTeam, 4)
        }
        dialogView.btnZonaB5.setOnClickListener {
            appointmentPlayerToZone(dialogView.btnZonaB5, numTeam, 5)
        }
        dialogView.btnZonaB6.setOnClickListener {
            appointmentPlayerToZone(dialogView.btnZonaB6, numTeam, 6)
        }

        dialogView.btnSaveStartLineUp.setOnClickListener{
            var flag = true
            if (numTeam==1)
                for (pl in team1.playersForPlayground){
                    if (pl.gameNumber==-1)
                        flag = false
                }
            if (numTeam==2)
                for (pl in team2.playersForPlayground){
                    if (pl.gameNumber==-1)
                        flag = false
                }

            if (numTeam==1)
                initPlayerInPlace(team1.playersForPlayground, numTeam)
            else initPlayerInPlace(team2.playersForPlayground, numTeam)

            if (flag) {
                alert.dismiss()
                if (numTeam==1)
                    loadDialogview(2)//записываем состав для второй команды
            }
            else
                Toast.makeText(this,"Заполните стартовый состав команды!",
                    Toast.LENGTH_SHORT).show()

            if (numTeam==1)
                team1.setListPlacementForPlayer()
            else
                team2.setListPlacementForPlayer()
        }
    }
    //показываем состав команды из возможных
    private fun appointmentPlayerToZone(btn1: AppCompatButton, numTeam: Int, numZone: Int) {
        var nameTeam = if (numTeam==1) managmentMatch.teamA.name else managmentMatch.teamB.name

        var dialogView = LayoutInflater.from(this).inflate(R.layout.team_composition, null)
        var builder = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(true)

        var title = layoutInflater.inflate(R.layout.title_dialog, null) as TextView?
        title!!.text = "Cостав команды $nameTeam"
        builder.setCustomTitle(title)

        var alert = builder.show()

        if (numTeam==1)
            for (player in team1.players){
                if (player.position!="Л")
                    addBtnForAppointmentPlayer(dialogView, alert, btn1,numTeam, player, numZone)
            }
        if (numTeam==2)
            for (player in team2.players){
                if (player.position!="Л")
                    addBtnForAppointmentPlayer(dialogView, alert, btn1, numTeam, player, numZone)
            }
    }
    //добавляем игроков из состава
    private fun addBtnForAppointmentPlayer(dialogView: View, alert: AlertDialog, btn1: AppCompatButton,
                                           numTeam: Int, player: PlayerForMatch, numZone:Int ) {
        var btn = AppCompatButton(this)
        btn.text = player.gameNumber.toString()

        if (player.position=="Л") btn.setBackgroundResource(R.drawable.ovalorange)
        else btn.setBackgroundResource(R.drawable.player)

        val layoutParams = GridLayout.LayoutParams()
        layoutParams.width = 100
        layoutParams.height = 100
        layoutParams.setMargins(5)
        btn.layoutParams = layoutParams
        btn.setTextColor(Color.BLACK)
        btn.textSize = 18F
        var flag = false
        if (numTeam==1)
            if (team1.playersForPlayground.size!=0 && team1.playersForPlayground.contains(player)) {
                btn.isActivated = false
                btn.isClickable = false
                btn.setBackgroundResource(R.drawable.mybuttongrey)
                btn.setTextColor(Color.WHITE)
            }
            else {
                flag = true
                btn.isActivated = true
                btn.isClickable = true
            }
        if (numTeam==2)
            if (team2.playersForPlayground.size!=0 && team2.playersForPlayground.contains(player)) {
                btn.isActivated = false
                btn.isClickable = false
                btn.setBackgroundResource(R.drawable.mybuttongrey)
                btn.setTextColor(Color.WHITE)
            }
            else {
                flag = true
                btn.isActivated = true
                btn.isClickable = true
            }

        btn.setOnClickListener{
            if (flag) {
                if (numTeam == 1)
                    team1.addPlayersForPlaygroundForIndex(numZone - 1, player)
                else
                    team2.addPlayersForPlaygroundForIndex(numZone - 1, player)
                alert.dismiss()
                btn1.setBackgroundResource(R.drawable.player)
                btn1.setTextColor(Color.BLACK)
                btn1.text = player.gameNumber.toString()
            }

        }
        dialogView.team_composition.addView(btn)
    }

    private fun teamTransition(teamLast:String, team:String){
        if (teamLast=="" && mySharedPreferences.getString(nameTeamServeBall,"")==managmentMatch.teamA.name &&
                team == "A") {
        }
        else{
            if (teamLast=="" && mySharedPreferences.getString(nameTeamServeBall,"")==managmentMatch.teamB.name &&
                team == "B") {
            }else{
                if (teamLast!=team){
                    if (managmentMatch.nameTeamForSides("A")==managmentMatch.teamA.name){
                        if (team=="A"){
                            var str = btnZonaA1.text.toString()
                            btnZonaA1.text = btnZonaA2.text.toString()
                            btnZonaA2.text = btnZonaA3.text.toString()
                            btnZonaA3.text = btnZonaA4.text.toString()
                            btnZonaA4.text = btnZonaA5.text.toString()
                            btnZonaA5.text = btnZonaA6.text.toString()
                            btnZonaA6.text = str
                        }else{
                            var str = btnZonaB1.text.toString()
                            btnZonaB1.text = btnZonaB2.text.toString()
                            btnZonaB2.text = btnZonaB3.text.toString()
                            btnZonaB3.text = btnZonaB4.text.toString()
                            btnZonaB4.text = btnZonaB5.text.toString()
                            btnZonaB5.text = btnZonaB6.text.toString()
                            btnZonaB6.text = str
                        }
                    }else {
                        if (team == "A") {
                            var str = btnZonaB1.text.toString()
                            btnZonaB1.text = btnZonaB2.text.toString()
                            btnZonaB2.text = btnZonaB3.text.toString()
                            btnZonaB3.text = btnZonaB4.text.toString()
                            btnZonaB4.text = btnZonaB5.text.toString()
                            btnZonaB5.text = btnZonaB6.text.toString()
                            btnZonaB6.text = str
                        } else {
                            var str = btnZonaA1.text.toString()
                            btnZonaA1.text = btnZonaA2.text.toString()
                            btnZonaA2.text = btnZonaA3.text.toString()
                            btnZonaA3.text = btnZonaA4.text.toString()
                            btnZonaA4.text = btnZonaA5.text.toString()
                            btnZonaA5.text = btnZonaA6.text.toString()
                            btnZonaA6.text = str
                        }
                    }
                }
            }
        }

    }
    private fun teamTransitionBack(team:String){
            if (team=="A"){
                var str = btnZonaA6.text.toString()
                btnZonaA6.text = btnZonaA5.text.toString()
                btnZonaA5.text = btnZonaA4.text.toString()
                btnZonaA4.text = btnZonaA3.text.toString()
                btnZonaA3.text = btnZonaA2.text.toString()
                btnZonaA2.text = btnZonaA1.text.toString()
                btnZonaA1.text = str
            }else{
                var str = btnZonaB6.text.toString()
                btnZonaB6.text = btnZonaB5.text.toString()
                btnZonaB5.text = btnZonaB4.text.toString()
                btnZonaB4.text = btnZonaB3.text.toString()
                btnZonaB3.text = btnZonaB2.text.toString()
                btnZonaB2.text = btnZonaB1.text.toString()
                btnZonaB1.text = str
            }
        }
    //заполнение полей игроков, где listPlayers - список с нумерацией соответствующей номерам зон на площадке, numTeam - номер команды
    private fun initPlayerInPlace(listPlayers : MutableList<PlayerForMatch>, numTeam:Int) {
        if(managmentMatch.nameTeamForSides("A")==managmentMatch.teamA.name){
            if (numTeam==1){
            listPlayers.forEach {
                when(listPlayers.indexOf(it)){
                    0-> btnZonaA1.text = it.gameNumber.toString()
                    1-> btnZonaA2.text = it.gameNumber.toString()
                    2-> btnZonaA3.text = it.gameNumber.toString()
                    3-> btnZonaA4.text = it.gameNumber.toString()
                    4-> btnZonaA5.text = it.gameNumber.toString()
                    else-> btnZonaA6.text = it.gameNumber.toString()
                }
            }
        }else{
            listPlayers.forEach {
                when(listPlayers.indexOf(it)){
                    0-> btnZonaB1.text = it.gameNumber.toString()
                    1-> btnZonaB2.text = it.gameNumber.toString()
                    2-> btnZonaB3.text = it.gameNumber.toString()
                    3-> btnZonaB4.text = it.gameNumber.toString()
                    4-> btnZonaB5.text = it.gameNumber.toString()
                    else-> btnZonaB6.text = it.gameNumber.toString()
                }
            }
        }
        }else{
            if (numTeam==1){
                listPlayers.forEach {
                    when(listPlayers.indexOf(it)){
                        0-> btnZonaB1.text = it.gameNumber.toString()
                        1-> btnZonaB2.text = it.gameNumber.toString()
                        2-> btnZonaB3.text = it.gameNumber.toString()
                        3-> btnZonaB4.text = it.gameNumber.toString()
                        4-> btnZonaB5.text = it.gameNumber.toString()
                        else-> btnZonaB6.text = it.gameNumber.toString()
                    }
                }
            }else{
                listPlayers.forEach {
                    when(listPlayers.indexOf(it)){
                        0-> btnZonaA1.text = it.gameNumber.toString()
                        1-> btnZonaA2.text = it.gameNumber.toString()
                        2-> btnZonaA3.text = it.gameNumber.toString()
                        3-> btnZonaA4.text = it.gameNumber.toString()
                        4-> btnZonaA5.text = it.gameNumber.toString()
                        else-> btnZonaA6.text = it.gameNumber.toString()
                    }
                }
            }
        }
    }

    private fun checkEndPart() {
        if (managmentMatch.checkEndPart()){
            if (managmentMatch.checkEndMatch()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    endMatch()
                }
            }
            else{
                changeOfSides(true)
                managmentMatch.teamA.curScore = 0
                managmentMatch.teamB.curScore = 0
            }
        }else{
            if (managmentMatch.numSet ==  mySharedPreferences.getInt(setsToWin,5) &&
                ((managmentMatch.teamA.curScore == 8 && managmentMatch.teamA.curScore > managmentMatch.teamB.curScore)
                        || (managmentMatch.teamB.curScore == 8 && managmentMatch.teamB.curScore > managmentMatch.teamA.curScore))) {
                changeOfSides(false)
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun endMatch() {
        var str = ""
        managmentMatch.storyScoreSets.forEach {
            str += it + "\n"
        }
        match.description += str
        var protocole = File("")
        if (mySharedPreferences.getBoolean("protocole",false) || match.protocol) {
            protocole = createProtocole()
            str += "Протокол матча составлен и загружен на устройство.\n"
        }
        if (mySharedPreferences.getBoolean("sendEmails",false) || match.sendingEmail){
            sendEmails(protocole)
            str += "Протокол отправлен представителям команд.\n"
        }
        viewTeam.addDescForMatch(retrofitService.retrofit.create(MyApi::class.java), this, match.id!!.toLong(), match.description)


        val builder = AlertDialog.Builder(this)
        builder.setTitle("Матч окончен!")
            .setMessage(str)
            .setCancelable(true)
            .setPositiveButton("Выйти") { _, _ ->
                val intent = Intent(this, Main2Activity::class.java)
                startActivity(intent)
            }
        builder.show()
         }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createProtocole() : File{
        var fileName = "${match.id}_Match_report_${LocalDate.now()}.doc"
        val root = File(Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS), "Protocols")
        if (!root.exists()) {
            root.mkdirs()
        }
        // Create file object
        val file = File(root, fileName)
        val writer = FileWriter(file)
        // Create file
        //Заголовок
        writer.append("Протокол матча ${match.name}\n")
        writer.append(LocalDate.now().toString() + "\n")
        //команда 1
        writer.append("\nКоманда A: ${managmentMatch.teamA.name}\n")
        writer.append("№\tФИО\tП\n")

        team1.players.forEach{
            writer.append("${it.gameNumber}\t${it.name}\t${it.position}\n")
        }
        writer.append("Представитель команды A: ${managmentMatch.teamA.nameRep}\n\n")
        //команда 2
        writer.append("\nКоманда Б: ${managmentMatch.teamB.name}\n")
        writer.append("№\tФИО\t\t\tП\n")
        var captainTeam2 = ""
        team2.players.forEach{
            writer.append("${it.gameNumber}\t${it.name}\t${it.position}\n")
        }
        writer.append("Представитель команды Б: ${managmentMatch.teamB.nameRep}\n\n")

        managmentMatch.storyScoreSets.forEach {
            writer.append("${it}\n")
        }

        writer.append("\nПредставитель команды A: ${managmentMatch.teamA.nameRep} (               )\n")
        writer.append("Капитан команды A: ${team1.captainTeam} (               )\n")
        writer.append("\nПредставитель команды Б: ${managmentMatch.teamB.nameRep} (               )\n")
        writer.append("Капитан команды Б: ${team2.captainTeam} (               )\n\n")

        writer.append("1-ый судья матча:                (               )\n")
        writer.append("2-ый судья матча:                (               )\n")
        writer.append("Секретарь:                       (               )\n")
        writer.flush();
        writer.close();
        return file
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun sendEmails(protocole: File) {

        val path: Uri = FileProvider.getUriForFile(
            Objects.requireNonNull(applicationContext),
            BuildConfig.APPLICATION_ID + ".provider", protocole)
        val emailIntent = Intent(Intent.ACTION_SEND)
// set the type to 'email'
// set the type to 'email'
        emailIntent.type = "vnd.android.cursor.dir/email"
        val to = arrayOf(managmentMatch.teamA.emailRep,managmentMatch.teamB.emailRep)
        emailIntent.putExtra(Intent.EXTRA_EMAIL, to)
// the attachment
// the attachment
        emailIntent.putExtra(Intent.EXTRA_STREAM, path)
// the mail subject
// the mail subject
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Протокол матча от " + LocalDate.now().toString())
        startActivity(Intent.createChooser(emailIntent, "Отправка протокола..."))

    }

    var flagChangeOfSides = false
    fun changeOfSides(flag:Boolean) {
        var fA = fragment_teamA
        var fB = fragment_teamB
        frameLayout.removeAllViews()
        frameLayout1.removeAllViews()

        if (!flag){
            frameLayout.addView(fB)
            frameLayout1.addView(fA)
            tv_scoreSets.text = "${managmentMatch.teamB.scorePart} : ${managmentMatch.teamA.scorePart}"

            if (!flagChangeOfSides)
                changeOfSidesPlayers()

            var cpAllSets = managmentMatch.chronologyPoints
            if (cpAllSets.size!=0){
                var cpLastSet = cpAllSets[cpAllSets.size-1].chronologyPoint
                if (cpLastSet.size!=0){
                    when(cpLastSet[cpLastSet.size-1])
                    {
                        "A" -> {
                            ib_BallTB.visibility = View.VISIBLE
                            ib_BallTA.visibility = View.INVISIBLE
                        }
                        "B" -> {
                            ib_BallTA.visibility = View.VISIBLE
                            ib_BallTB.visibility = View.INVISIBLE
                        }
                        else -> {
                            ib_BallTB.visibility = View.INVISIBLE
                            ib_BallTA.visibility = View.INVISIBLE
                        }
                    }
                    if (cpLastSet.size!=1)
                        teamTransition(cpLastSet[cpLastSet.size-2], cpLastSet[cpLastSet.size-1])
                    else
                        teamTransition("", cpLastSet[cpLastSet.size-1])

                }
            }
        }
        else{
            if (managmentMatch.numSet%2==0){//1 и тд
                tv_scoreSets.text = "${managmentMatch.teamB.scorePart} : ${managmentMatch.teamA.scorePart}"
                frameLayout.addView(fB)
                frameLayout1.addView(fA)
            }
            else{
                tv_scoreSets.text = "${managmentMatch.teamA.scorePart} : ${managmentMatch.teamB.scorePart}"
                frameLayout.addView(fA)
                frameLayout1.addView(fB)
            }
            appointmentStartingLineUp()
            managmentMatch.teamA.curScore = 0
            managmentMatch.teamB.curScore = 0
            dataModel.dataMatch.value = managmentMatch
        }
    }
    private fun changeOfSidesPlayers() {//0 - если как в первой партии 1- во второй 3-смена в таймбрайке

        flagChangeOfSides = true
                var z1 = btnZonaA1.text.toString()
                var z2 = btnZonaA2.text.toString()
                var z3 = btnZonaA3.text.toString()
                var z4 = btnZonaA4.text.toString()
                var z5 = btnZonaA5.text.toString()
                var z6 = btnZonaA6.text.toString()
                btnZonaA1.text = btnZonaB1.text.toString()
                btnZonaA2.text = btnZonaB2.text.toString()
                btnZonaA3.text = btnZonaB3.text.toString()
                btnZonaA4.text = btnZonaB4.text.toString()
                btnZonaA5.text = btnZonaB5.text.toString()
                btnZonaA6.text = btnZonaB6.text.toString()
                btnZonaB1.text = z1
                btnZonaB2.text = z2
                btnZonaB3.text = z3
                btnZonaB4.text = z4
                btnZonaB5.text = z5
                btnZonaB6.text = z6

    }

    private fun goToNewFragment(fragment: FrameLayout, num : Int){
        val mFragment = TeamInMatchFragment()
        val mBundle = Bundle()
        mBundle.putString("numTeam", "$num")
        mBundle.putInt("setsToWin", mySharedPreferences.getInt(setsToWin,5))
        if (num==1)        mBundle.putString("nameTeam", managmentMatch.teamA.name)
        if (num==2)        mBundle.putString("nameTeam", managmentMatch.teamB.name)

        mFragment.arguments = mBundle
        supportFragmentManager
            .beginTransaction()
            .replace(fragment.id, mFragment)
            .addToBackStack(null)
            .commit()
    }

    fun imageBall(flag: Int){
        if(managmentMatch.nameTeamForSides("A")==managmentMatch.teamA.name)
            when(flag){
                0->{
                    ib_BallTA.visibility = View.VISIBLE
                    ib_BallTB.visibility = View.INVISIBLE
                }
                1->{
                    ib_BallTB.visibility = View.VISIBLE
                    ib_BallTA.visibility = View.INVISIBLE
                }
                else ->{
                    ib_BallTB.visibility = View.INVISIBLE
                    ib_BallTA.visibility = View.INVISIBLE
                }
            }
        else
            when(flag){
                0->{
                    ib_BallTB.visibility = View.VISIBLE
                    ib_BallTA.visibility = View.INVISIBLE
                }
                1->{
                    ib_BallTA.visibility = View.VISIBLE
                    ib_BallTB.visibility = View.INVISIBLE
                }
                else ->{
                    ib_BallTB.visibility = View.INVISIBLE
                    ib_BallTA.visibility = View.INVISIBLE
                }
            }
    }

    private fun startTime() {
        timeMatch.start()
    }

    fun onSvist(view: View?){
        var mp = MediaPlayer.create(this, R.raw.svist);
        mp.start()
    }
    private fun interrupting_match() {
        if (managmentMatch.teamA.scorePart > managmentMatch.teamA.scorePart){
            managmentMatch.storyScoreSets.add("Матч окончен в пользу команды " + managmentMatch.teamA.name + " со счетом "
                    + managmentMatch.teamA.scorePart + ":" + managmentMatch.teamB.scorePart)
        }else{
            if (managmentMatch.teamA.scorePart < managmentMatch.teamA.scorePart){
                managmentMatch.storyScoreSets.add("Матч окончен в пользу команды " + managmentMatch.teamB.name + " со счетом "
                        + managmentMatch.teamA.scorePart + ":" + managmentMatch.teamB.scorePart)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            endMatch()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main2, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.itemMenu_endMatch -> {
                interrupting_match()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
    override fun onBackPressed() {
        finish()
    }
}