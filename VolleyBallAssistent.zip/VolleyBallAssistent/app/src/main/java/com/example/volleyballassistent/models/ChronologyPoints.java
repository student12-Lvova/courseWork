package com.example.volleyballassistent.models;

import java.util.ArrayList;
import java.util.List;

public class ChronologyPoints {

    List<String> chronologyPoint;
    int numSet;

    public ChronologyPoints(){
        chronologyPoint = new ArrayList<>();
    }

    public List<String> getChronologyPoint() {
        return chronologyPoint;
    }

    public void setNumSet(int numSet) {
        this.numSet = numSet;
    }
}
