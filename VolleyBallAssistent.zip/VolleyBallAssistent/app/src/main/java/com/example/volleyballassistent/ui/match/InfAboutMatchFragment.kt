package com.example.volleyballassistent.ui.match

import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.example.volleyballassistent.databinding.FragmentInfAboutMatchBinding
import com.example.volleyballassistent.workDB.models.Match
import kotlinx.android.synthetic.main.fragment_inf_about_match.*
import kotlinx.android.synthetic.main.fragment_settings_match.*
import kotlinx.android.synthetic.main.list_players_for_appoint_captain.view.*

class InfAboutMatchFragment : Fragment() {
    private lateinit var binding: FragmentInfAboutMatchBinding
    private val dataModel:DataMatchModel by activityViewModels()


    var match = Match(null, "", "", "", false,protocol = false, teamPlacement = false,
        false, null, null)
    var flagEmailsRepTeams = false
    lateinit var arr :Array<String>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentInfAboutMatchBinding.inflate(layoutInflater)
        dataModel.team1.observe(this.requireActivity()) {
            flagEmailsRepTeams = it.team.emailRepresentative!=null || it.team.emailRepresentative!=""
        }
        dataModel.team2.observe(this.requireActivity()) {
            flagEmailsRepTeams = it.team.emailRepresentative!=null || it.team.emailRepresentative!=""
        }
        initFieldsOnClick()

        return binding.root
    }

    private fun initFieldsOnClick() {
        var mySharedPreferences = this.requireContext().getSharedPreferences("work", AppCompatActivity.MODE_PRIVATE)
        if(!mySharedPreferences.getString("statusWork", "").equals("")){
            binding.cbTransition.visibility = View.GONE
            binding.textView4.visibility = View.GONE
        }
        binding.btnSave.visibility = View.GONE
        binding.edNameMatch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                match.name = s.toString()
                dataModel.match.value = match
            }
        })
        binding.etDescMatch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                match.description = s.toString()
                dataModel.match.value = match
            }
        })
            binding.cbProtocol.setOnCheckedChangeListener { view, isChecked ->
                match.protocol = isChecked
                if (!isChecked) {
                    binding.cbSendEmails.isChecked = false
                    binding.cbSendEmails.visibility = View.GONE
                    match.sendingEmail = false
                }
                else binding.cbSendEmails.visibility = View.VISIBLE
                dataModel.match.value = match
            }

            binding.cbSendEmails.setOnCheckedChangeListener { view, isChecked ->
                match.sendingEmail = isChecked
                dataModel.match.value = match
            }
            binding.cbTransition.setOnCheckedChangeListener { view, isChecked ->
                dataModel.transition.value = isChecked
            }

            binding.numPikerCountSets1.setOnValueChangedListener{ picker, oldVal, newVal ->
                dataModel.countSets.value = arr.get(newVal).toInt()
            }

            arr = arrayOf("3","5")
            binding.numPikerCountSets1.minValue = 0
            binding.numPikerCountSets1.maxValue = arr.size-1
            binding.numPikerCountSets1.displayedValues = arr
            binding.numPikerCountSets1.value = 0

            binding.cbSendEmails.visibility = View.GONE

    }


}