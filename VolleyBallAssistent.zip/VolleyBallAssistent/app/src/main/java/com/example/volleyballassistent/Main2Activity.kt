package com.example.volleyballassistent

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.util.AttributeSet
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.fragment.app.findFragment
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.volleyballassistent.databinding.ActivityMain2Binding
import com.example.volleyballassistent.ui.profile.ProfileFragment
import com.example.volleyballassistent.ui.view_matches.MatchesFragment
import com.example.volleyballassistent.ui.view_teams.TeamFragment
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewAllData
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workDB.models.Player
import com.example.volleyballassistent.workDB.models.Team
import com.example.volleyballassistent.workServer.MyApi
import com.example.volleyballassistent.workServer.RetrofitService
import com.example.volleyballassistent.workServer.auth.DataModelAuth
import com.example.volleyballassistent.workServer.models.MatchToServer
import com.example.volleyballassistent.workServer.models.PlayerToServer
import com.example.volleyballassistent.workServer.models.TeamToServer
import com.example.volleyballassistent.workServer.models.UserToServer
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.app_bar_main2.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import java.util.logging.Level
import java.util.logging.Logger


class Main2Activity : AppCompatActivity() {
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMain2Binding
    lateinit var navController:NavController

    lateinit var mySharedPreferences: SharedPreferences
    private val section = "settings"
    private val section1 = "user"
    private val idUser = "idUser"
    private val login = "login"
    private val email = "email"
    private val section2 = "work"
    lateinit var prefEditor: SharedPreferences.Editor

    lateinit var retrofitService: RetrofitService
    lateinit var api: MyApi
    var teamsToServer: MutableList<TeamToServer> = listOf<TeamToServer>().toMutableList()
    var matchToServer: MutableList<MatchToServer> = listOf<MatchToServer>().toMutableList()
    var playerToServer: MutableList<PlayerToServer> = listOf<PlayerToServer>().toMutableList()

    lateinit var context:Context

    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewAllData : ViewAllData

    val modelAuth:DataModelAuth by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        context = this

        db= MainDB.getDatabase(this, CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewAllData = ViewAllData(repository, db.wordDao())
        viewAllData.allDataDelete()

        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)
        mySharedPreferences = this.getSharedPreferences(section, MODE_PRIVATE)
        connectToServer()

    }
    private fun connectToServer() {
        retrofitService = RetrofitService()
        api = retrofitService.retrofit.create(MyApi::class.java)

        var call: Call<Long>? = api.connect()
        if (call==null){
            modelAuth.status.value = "Ошибка подключения к серверу!"
            connectToServer1()
        }else{
            call!!.enqueue(object : Callback<Long> {
                override fun onFailure(call: Call<Long>, t: Throwable) {
                    modelAuth.status.value = "Нет доступа к серверу или подключения к интернету!"

                    connectToServer1()
                }
                override fun onResponse(
                    call: Call<Long>,
                    response: Response<Long>
                ) {
                        modelAuth.status.value = ""
                        connectToServer1()
                }
            })
        }
    }

    private fun connectToServer1() {
        modelAuth.status.observe(this){ s->
            prefEditor = getSharedPreferences(section2, MODE_PRIVATE).edit()
            val editor = getSharedPreferences("work", MODE_PRIVATE).edit()
            editor.putString("statusWork", s)
            editor.apply()
            if (s!=""){
                findViewById<AppCompatButton>(R.id.btnLogin).visibility = View.GONE
                findViewById<AppCompatButton>(R.id.btnCalendar).visibility = View.GONE
                loadFragment(0)
            }else{
                mySharedPreferences = this.getSharedPreferences(section1, MODE_PRIVATE)
                var id = mySharedPreferences.getInt(idUser, -1)
                loginUser(id)
            }
            findViewById<TextView>(R.id.statusWork).text = s
        }



    }

    private fun loginUser(id: Int) {
        retrofitService = RetrofitService()
        api = retrofitService.retrofit.create(MyApi::class.java)
            var call: Call<UserToServer>? = api.getUserById(id.toLong())
                call!!.enqueue(object : Callback<UserToServer> {
                    override fun onFailure(call: Call<UserToServer>, t: Throwable) {
                        findViewById<TextView>(R.id.statusWork).text = "Пользователь не авторизирован!"
                        findViewById<AppCompatButton>(R.id.btnLogin).visibility = View.VISIBLE
                        findViewById<AppCompatButton>(R.id.btnCalendar).visibility = View.GONE
                        loadFragment(0)
                    }
                    override fun onResponse(
                        call: Call<UserToServer>,
                        response: Response<UserToServer>
                    ) {
                        if (response.body()!=null) {
                            loadUser(response.body()!!)
                            findViewById<TextView>(R.id.statusWork).text = ""
                            findViewById<AppCompatButton>(R.id.btnLogin).visibility = View.VISIBLE
                            findViewById<AppCompatButton>(R.id.btnCalendar).visibility = View.VISIBLE
                            loadFragment(1)
                        }
                        else {
                            findViewById<TextView>(R.id.statusWork).text = "Пользователь не авторизирован!"
                            findViewById<AppCompatButton>(R.id.btnLogin).visibility = View.VISIBLE
                            findViewById<AppCompatButton>(R.id.btnCalendar).visibility = View.VISIBLE
                            loadFragment(0)
                        }
                    }
                })

    }

    private fun loadFragment(status: Int) {
        navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main2)

        setSupportActionBar(binding.appBarMain2.toolbar)

        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main2)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.

        if (status==1){
            findViewById<AppCompatButton>(R.id.btnLogin).visibility = View.VISIBLE
            appBarConfiguration = AppBarConfiguration(
                setOf(
                    R.id.nav_home, R.id.nav_profile, R.id.nav_teams, R.id.nav_matches
                ), drawerLayout
            )
            setupActionBarWithNavController(navController, appBarConfiguration)
            navView.setupWithNavController(navController)
            navView.setNavigationItemSelectedListener {
                when(it.itemId){
                    R.id.nav_home -> {
                        toolbar.title = "Волейбольный помощник"
                        supportFragmentManager
                            .beginTransaction()
                            .replace(R.id.nav_host_fragment_content_main2, MainPageFragment())
                            .addToBackStack(null)
                            .commit()
                        true
                    }
                    R.id.nav_profile -> {
                        toolbar.title = "Мой профиль"
                        supportFragmentManager
                            .beginTransaction()
                            .replace(R.id.nav_host_fragment_content_main2, ProfileFragment())
                            .addToBackStack(null)
                            .commit()
                        true
                    }
                    R.id.nav_teams -> {
                        toolbar.title = "Мои команды"
                        supportFragmentManager
                            .beginTransaction()
                            .replace(R.id.nav_host_fragment_content_main2, TeamFragment())
                            .addToBackStack(null)
                            .commit()
                        true
                    }
                    R.id.nav_matches -> {
                        toolbar.title = "Мой матчи"
                        supportFragmentManager
                            .beginTransaction()
                            .replace(R.id.nav_host_fragment_content_main2, MatchesFragment())
                            .addToBackStack(null)
                            .commit()
                        true
                    }
                    R.id.nav_liveStream -> {
                        val uriUrl: Uri = Uri.parse("http://192.168.100.14:8080/translations")
                        val launchBrowser = Intent(Intent.ACTION_VIEW, uriUrl)
                        startActivity(launchBrowser)
                        true
                    }
                    else -> false
                }
            }
        }



    }

    private fun loadUser(user: UserToServer) {

        prefEditor.putInt("status", 1)
        prefEditor.apply()
        mySharedPreferences = this.getSharedPreferences(section, MODE_PRIVATE)
        prefEditor = mySharedPreferences.edit()
        prefEditor.putInt(idUser, user.id!!)
        prefEditor.putString(login, user.login)
        prefEditor.putString(email, user.email)
        prefEditor.apply()

        loadTeams(user.id!!)
    }
    private fun loadTeams(id: Int) {
        teamsToServer = listOf<TeamToServer>().toMutableList()
        var call:Call<List<TeamToServer>>? = api.getAllTeamsForUser(id.toLong())
        if (call!=null){
            call!!.enqueue(object : Callback<List<TeamToServer>> {
                override fun onFailure(call: Call<List<TeamToServer>>, t: Throwable) {
                    Toast.makeText(context, "Ошибка загрузки команд!!", Toast.LENGTH_SHORT).show()
                    Logger.getLogger(context.javaClass.name).log(Level.SEVERE, t.message)
                }
                override fun onResponse(
                    call: Call<List<TeamToServer>>,
                    response: Response<List<TeamToServer>>
                ) {
                    if(response.isSuccessful){
                        Toast.makeText(context, "Команды загружены!!!", Toast.LENGTH_SHORT).show()
                        teamsToServer = response.body() as MutableList<TeamToServer>
                        var teamsForDB:ArrayList<Team> = ArrayList<Team>()
                        teamsToServer.forEach {
                            teamsForDB.add(
                                Team(it.id.toLong(), it.nameTeam!!, it.address!!,
                                    it.fio!!, it.email!!))
                        }
                        viewAllData.loadAllTeams(teamsForDB)
                        loadPlayers(id)
                    }
                }
            })
        }
    }

    private fun loadPlayers(id: Int) {
        playerToServer = listOf<PlayerToServer>().toMutableList()
        var call:Call<List<PlayerToServer>>? = api.getAllPlayersForUser(id.toLong())
        if (call!=null){
            call!!.enqueue(object : Callback<List<PlayerToServer>> {
                override fun onFailure(call: Call<List<PlayerToServer>>, t: Throwable) {
                    Toast.makeText(context, "Ошибка загрузки команд!!", Toast.LENGTH_SHORT).show()
                    Logger.getLogger(context.javaClass.name).log(Level.SEVERE, t.message)
                }
                override fun onResponse(
                    call: Call<List<PlayerToServer>>,
                    response: Response<List<PlayerToServer>>
                ) {
                    if(response.isSuccessful){
                        Toast.makeText(context, "Игроки загружены!!!", Toast.LENGTH_SHORT).show()
                        playerToServer = response.body() as ArrayList<PlayerToServer>
                        var playersForDB:ArrayList<Player> = ArrayList<Player>()
                        playerToServer.forEach {
                            playersForDB.add(Player(it.id.toLong(), it.namePlayer!!, it.number, it.position.toString(), it.captain, it.team!!.id.toLong()))
                        }
                        viewAllData.loadAllPlayers(playersForDB)
                        loadMatches(id)
                    }
                }
            })
        }
    }

    private fun loadMatches(id: Int) {
        matchToServer = listOf<MatchToServer>().toMutableList()
        var call:Call<List<MatchToServer>>? = api.getAllMatchesForUser(id.toLong())
        if (call!=null){
            call!!.enqueue(object : Callback<List<MatchToServer>> {
                override fun onFailure(call: Call<List<MatchToServer>>, t: Throwable) {
                    Toast.makeText(context, "Ошибка загрузки матчей!!", Toast.LENGTH_SHORT).show()
                    Logger.getLogger(context.javaClass.name).log(Level.SEVERE, t.message)
                }
                override fun onResponse(
                    call: Call<List<MatchToServer>>,
                    response: Response<List<MatchToServer>>
                ) {
                    if(response.isSuccessful){
                        Toast.makeText(context, "Матчи загружены!!", Toast.LENGTH_SHORT).show()
                        matchToServer = response.body() as MutableList<MatchToServer>
                        var matchesForDB:ArrayList<Match> = ArrayList<Match>()
                        matchToServer.forEach {
                            if (it.teams!!.isNotEmpty())
                                matchesForDB.add(
                                    Match(it.id, it.nameMatch!!, it.description!!, it.dateMatch.toString(),it.flagCalendar!!,
                                        false, false, false,
                                        it.teams!![0].id!!.toInt(), it.teams!![1].id!!.toInt())
                                )
                        }
                        viewAllData.loadAllMatches(matchesForDB)
                    }
                }
            })
        }
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true
    }
    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main2)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

}





