package com.example.volleyballassistent

import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import com.example.volleyballassistent.controllers.OfficialMatch
import com.example.volleyballassistent.controllers.TrainMatch
import com.example.volleyballassistent.models.TeamForTrainMatch
import com.example.volleyballassistent.models.TeamPlacementWithMatch
import com.example.volleyballassistent.ui.match.DataMatchModel
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workDB.models.Team
import kotlinx.android.synthetic.main.activity_match.*
import kotlinx.android.synthetic.main.fragment_t_m_team_a.view.*
import kotlinx.android.synthetic.main.fragment_team_in_match.*
import kotlinx.android.synthetic.main.timer.view.*

/**
 * A simple [Fragment] subclass.
 * Use the [TeamInMatchFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
private const val ARG_PARAM1 = "numTeam"
class TeamInMatchFragment : Fragment(), View.OnClickListener {

    // TODO: Rename and change types of parameters
    private var numTeam: String? = null
    private var nameTeam: String? = null
    private var countsets: Int? = null


    private val dataModel: DataMatchModel by activityViewModels()
    lateinit var team: TeamForTrainMatch
    lateinit var match: Match

    lateinit var dataMatch_team: OfficialMatch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            numTeam = it.getString(ARG_PARAM1)
            nameTeam = it.getString("nameTeam")
            countsets = it.getInt("setsToWin")

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var v =inflater.inflate(R.layout.fragment_t_m_team_a, container, false)

        dataMatch_team = OfficialMatch(countsets!!.toInt())
        if (numTeam=="1") {
            dataMatch_team.teamA = TeamForTrainMatch(Team(null,nameTeam!!,"", "", ""))
            team = dataMatch_team.teamA
        }
        if (numTeam=="2") {
            dataMatch_team.teamB = TeamForTrainMatch(Team(null,nameTeam!!,"", "", ""))
            team = dataMatch_team.teamB
        }

        v.etNameTeam.setText(nameTeam)
        v.btnScoreTeam.setOnClickListener(this)
        v.btnMinusScore.setOnClickListener(this)
        v.btnTimeOut1.setOnClickListener(this)
        v.btnTimeOut2.setOnClickListener(this)

        dataModel.dataMatch.observe(viewLifecycleOwner) {
            dataMatch_team = it
            if (numTeam=="1")
                v.btnScoreTeam.text = it.teamA.curScore.toString()
            if (numTeam=="2")
                v.btnScoreTeam.text = it.teamB.curScore.toString()
        }

        return v
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment TMTeamAFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String) =
            TeamInMatchFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                }
            }
    }

    override fun onClick(view: View?) {
        when (view?.id){
            R.id.btnScoreTeam ->{
                if (numTeam=="1"){
                    dataMatch_team.addPointTA()
                    btnScoreTeam.text = dataMatch_team.teamA.curScore.toString()
                }
                if (numTeam=="2") {
                    dataMatch_team.addPointTB()
                    btnScoreTeam.text = dataMatch_team.teamB.curScore.toString()
                }
            }
            R.id.btnMinusScore -> {
                if (numTeam=="1") {
                    dataMatch_team.deletePointTA()
                    btnScoreTeam.text = dataMatch_team.teamA.curScore.toString()
                }
                if (numTeam=="2") {
                    dataMatch_team.deletePointTB()
                    btnScoreTeam.text = dataMatch_team.teamB.curScore.toString()
                }

            }
            R.id.btnTimeOut1 ->{
                managmentTimeOut(view)
            }
            R.id.btnTimeOut2 ->{
                managmentTimeOut(view)
            }
        }
        updateModel()


    }

    private fun updateModel() {
        dataModel.dataMatch.value = dataMatch_team
    }

    //ведение таймаутов
    private fun managmentTimeOut(view: View?){
        (view as AppCompatButton).setTextColor(Color.WHITE)
        view.isClickable = false

        var dialogView = LayoutInflater.from(this.requireContext()).inflate(R.layout.timer, null)
        var builder = AlertDialog.Builder(this.requireContext())
            .setView(dialogView)
            .setTitle("Тайм-аут команды ${team.name}")
            .setCancelable(false)
        var alert = builder.show()

        startTimer(dialogView.timerTimeOut, alert)

        dialogView.btnEndTimeOut.setOnClickListener{
            alert.dismiss()
        }
    }
    private fun startTimer(timerTimeOut: TextView, alert: AlertDialog) {
        val timer = object: CountDownTimer((60).toLong()*1000, 1000) {//минута
        override fun onTick(p0: Long) {
            var p = p0 / 1000
            if (p>=10)
                timerTimeOut.text = "00:$p"
            else
                timerTimeOut.text = "00:0$p"
        }
            override fun onFinish() {
                alert.dismiss()
            }
        }
        timer.start()
    }
}