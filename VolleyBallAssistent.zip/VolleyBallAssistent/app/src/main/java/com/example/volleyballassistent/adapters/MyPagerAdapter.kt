package com.example.volleyballassistent.adapters

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.lifecycle.asLiveData
import com.example.volleyballassistent.ui.match.InfAboutMatchFragment
import com.example.volleyballassistent.ui.match.TeamForMatchFragment
import com.example.volleyballassistent.workDB.MainDB

class MyPagerAdapter(fm: FragmentManager): FragmentPagerAdapter(fm) {
    override fun getCount(): Int {
        return 3
    }

    override fun getItem(position: Int): Fragment {
        return when(position){
            0 -> {
                val mFragment = TeamForMatchFragment()
                val mBundle = Bundle()
                mBundle.putString("numTeam", "1")
                mFragment.arguments = mBundle
                mFragment
            }
            1 -> {
                val mFragment = TeamForMatchFragment()
                val mBundle = Bundle()
                mBundle.putString("numTeam", "2")
                mFragment.arguments = mBundle
                mFragment
            }
            else -> {
                InfAboutMatchFragment()
            }
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when(position){
            0 -> {
                "Хозяева"
            }
            1 -> {
                "Гости"
            }
            else -> {
                "О матче"
            }
        }
    }
}