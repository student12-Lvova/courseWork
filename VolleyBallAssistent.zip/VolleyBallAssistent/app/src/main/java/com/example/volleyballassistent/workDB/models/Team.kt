package com.example.volleyballassistent.workDB.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Team")
data class Team(
    @PrimaryKey(autoGenerate = true)
    var id:Long?=null,
    @ColumnInfo(name = "name")
    var name:String,
    @ColumnInfo(name = "address")
    var address:String,
    @ColumnInfo(name = "nameRepresentative")
    var nameRepresentative:String,
    @ColumnInfo(name = "emailRepresentative")
    var emailRepresentative:String
)

