package com.example.volleyballassistent.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.children
import androidx.core.view.get
import androidx.core.view.setMargins
import androidx.recyclerview.widget.RecyclerView
import com.example.volleyballassistent.R
import com.example.volleyballassistent.ui.match.TeamForMatchFragment
import com.example.volleyballassistent.workDB.models.Player
import com.example.volleyballassistent.workDB.models.Team
import com.example.volleyballassistent.workDB.models.TeamWithPlayers
import kotlinx.android.synthetic.main.add_player.view.*
import kotlinx.android.synthetic.main.fragment_inf_team.view.*
import kotlinx.android.synthetic.main.list_players_for_appoint_captain.view.*
import kotlinx.android.synthetic.main.list_teams.view.*

class TeamsAdapter:RecyclerView.Adapter<TeamsAdapter.TeamViewHolder>() {

    private var teamsList = listOf<TeamWithPlayers>()
    var currentTeam = TeamWithPlayers()
    private lateinit var context:Context

    var positions = listOf("Игрок", "Либеро").toMutableList()
    private lateinit var spinnerAdapter: SpinnerAdapter

    class TeamViewHolder(view:View):RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TeamViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.list_teams, parent, false)
        return TeamViewHolder(view)
    }

    override fun getItemCount(): Int {
        return teamsList.size
    }

    override fun onBindViewHolder(holder: TeamViewHolder, position: Int) {
        currentTeam = teamsList[position]
        holder.itemView.tvIdTeam.text = currentTeam.team.id.toString()
        holder.itemView.tvIdTeam.visibility = View.GONE
        holder.itemView.tvNameTeam.text = currentTeam.team.name
        holder.itemView.btn_inf_team.setOnClickListener{
            for (team in teamsList){
                if (team.team.id!! == (it.parent as LinearLayout).tvIdTeam.text.toString().toLong()){
                    currentTeam = team
                    break
                }
            }
            (it.parent as LinearLayout).tvNameTeam.text
            var dialogView = LayoutInflater.from(context).inflate(R.layout.fragment_inf_team, null)

            var builder = AlertDialog.Builder(context)
                .setView(dialogView)
                .setCancelable(false)

            var alert = builder.show()

            dialogView.btnAddTeam.visibility = View.GONE
            dialogView.spChoiseTeam.visibility = View.GONE
            dialogView.btnSave.visibility = View.GONE
            dialogView.btnBack.visibility = View.VISIBLE
            dialogView.btnBack.setOnClickListener{
                alert.dismiss()
            }

            dialogView.edNameTeam.visibility = View.VISIBLE
            dialogView.edNameTeam.isEnabled = false
            dialogView.edNameTeam.setText(currentTeam.team.name)
            dialogView.etAdressTeam.setText(currentTeam.team.address)
            dialogView.etAdressTeam.isEnabled = false
            dialogView.edNameRep.setText(currentTeam.team.nameRepresentative)
            dialogView.edNameRep.isEnabled = false
            dialogView.edEmailRep.setText(currentTeam.team.emailRepresentative)
            dialogView.edEmailRep.isEnabled = false
            dialogView.btnAddPlayer.visibility = View.GONE
            var lp1 = dialogView.btnAddPlayer.layoutParams as GridLayout.LayoutParams

            while (dialogView.gridForNumPlayers.childCount!=0){
                if (dialogView.gridForNumPlayers.id!=R.id.btnAddPlayer){
                    dialogView.gridForNumPlayers.removeView(
                        dialogView.gridForNumPlayers.get(
                            dialogView.gridForNumPlayers.childCount-1
                        )
                    )
                }
            }

            for (it in currentTeam.players) {
                var btn = addBtnForPlayer(
                    it.gameNumber.toString(),
                    it.position.toCharArray()[0],
                    lp1)
                dialogView.gridForNumPlayers.addView(btn)

                if (it.captain)
                    dialogView.btnCap.text = it.gameNumber.toString()
            }
            if (currentTeam.players.size==0) dialogView.btnCap.text=""


        }
    }
    private fun addBtnForPlayer(num: String, position: Char, lp1: GridLayout.LayoutParams): AppCompatButton {
        var btn = AppCompatButton(context)
        btn.text = num
        if (position=='Л')
            btn.setBackgroundResource(R.drawable.ovalorange)
        else  btn.setBackgroundResource(R.drawable.player);
        btn.setTextAppearance(R.style.TextViewForBtn);
        btn.setOnClickListener{
            onViewPlayer(it)
        }
        val layoutParams = GridLayout.LayoutParams()
        layoutParams.width = lp1!!.width
        layoutParams.height = lp1.height
        layoutParams.setMargins(lp1.topMargin)
        btn.layoutParams = layoutParams
        return btn
    }
    private fun onViewPlayer(view: View) {
        var dialogView = LayoutInflater.from(context).inflate(R.layout.add_player, null)

        var builder = AlertDialog.Builder(context)
            .setView(dialogView)
            .setCancelable(true)
        builder.show()

        var curPlayer = Player(null, "", 0, "", false,null)
        for (player in currentTeam.players)
            if (player.gameNumber==(view as AppCompatButton).text.toString().toInt()) {
                curPlayer = player
                break
            }

        dialogView.et_namePlayer.setText(curPlayer.name)
        dialogView.et_numPlayer.setText(curPlayer.gameNumber.toString())

        if (curPlayer.position=="Л")
            positions = listOf("Либеро").toMutableList()
        if (curPlayer.position=="И")
            positions = listOf("Игрок").toMutableList()

        spinnerAdapter = ArrayAdapter(context,
            android.R.layout.simple_spinner_item, positions)
        dialogView.spinner_positionPlayer.adapter = spinnerAdapter
        dialogView.spinner_positionPlayer.getItemAtPosition(0)
        dialogView.spinner_positionPlayer.isEnabled = false

        dialogView.btnSavePlayer.visibility = View.GONE
        dialogView.btnDeletePlayer.visibility = View.GONE
        dialogView.et_namePlayer.isEnabled = false
        dialogView.et_numPlayer.isEnabled = false


    }


        fun setList(list: List<TeamWithPlayers>, context:Context){
            teamsList = list
            this.context = context
            notifyDataSetChanged()
        }
    fun getList():List<TeamWithPlayers>{
        return teamsList
    }
}