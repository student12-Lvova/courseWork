package com.example.volleyballassistent.workDB.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName = "User")
data class User(
    @ColumnInfo(name = "id")
    @PrimaryKey(autoGenerate = true)
    var id: Long?=null,
    @ColumnInfo(name = "login")
    var login:String,
    @ColumnInfo(name = "email")
    var email:String
    )