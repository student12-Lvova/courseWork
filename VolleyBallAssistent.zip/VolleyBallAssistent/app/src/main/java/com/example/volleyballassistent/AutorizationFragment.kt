package com.example.volleyballassistent

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.activityViewModels
import com.example.volleyballassistent.databinding.FragmentAutorizationBinding
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewAllData
import com.example.volleyballassistent.workDB.ViewTeam
import com.example.volleyballassistent.workDB.models.Match
import com.example.volleyballassistent.workDB.models.Player
import com.example.volleyballassistent.workDB.models.Team
import com.example.volleyballassistent.workDB.models.User
import com.example.volleyballassistent.workServer.MyApi
import com.example.volleyballassistent.workServer.RetrofitService
import com.example.volleyballassistent.workServer.auth.AuthRequestDto
import com.example.volleyballassistent.workServer.auth.AuthResponceDto
import com.example.volleyballassistent.workServer.auth.DataModelAuth
import com.example.volleyballassistent.workServer.models.*
import kotlinx.android.synthetic.main.fragment_autorization.*
import kotlinx.android.synthetic.main.fragment_profile.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import java.util.logging.Level
import java.util.logging.Logger
import kotlin.collections.ArrayList

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [AutorizationFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class AutorizationFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    private lateinit var binding: FragmentAutorizationBinding

    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewAllData : ViewAllData
    lateinit var viewTeam : ViewTeam

    lateinit var retrofitService:RetrofitService
    lateinit var api:MyApi
    var userToServer: UserToServer? = null

    var teamsToServer: MutableList<TeamToServer> = listOf<TeamToServer>().toMutableList()
    var matchToServer: MutableList<MatchToServer> = listOf<MatchToServer>().toMutableList()
    var playerToServer: MutableList<PlayerToServer> = listOf<PlayerToServer>().toMutableList()

    lateinit var mySharedPreferences: SharedPreferences
    private val section1 = "user"
    private val idUser = "idUser"
    private val login = "login"
    private val email = "email"
    private val section2 = "work"
    private val statusWork = "statusWork"
    lateinit var prefEditor: SharedPreferences.Editor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentAutorizationBinding.inflate(layoutInflater)

        db= MainDB.getDatabase(this.requireContext(), CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewAllData = ViewAllData(repository, db.wordDao())
        viewTeam = ViewTeam(repository, db.wordDao())

        mySharedPreferences = this.requireContext().getSharedPreferences(section1, AppCompatActivity.MODE_PRIVATE)
        prefEditor = mySharedPreferences.edit()

        binding.buttonLogin.setOnClickListener{
            login()
        }
        return binding.root


    }

    private fun login() {
        if (checkDataUser()){
            var user = User(null, "", "")
            retrofitService = RetrofitService()
            api = retrofitService.retrofit.create(MyApi::class.java)
            userToServer = UserToServer()
            var userAuth = UserToServer()
            var rezult = AuthResponceDto()
            userAuth.login = binding.etLoginL.text.toString()
            userAuth.password = binding.etPassword.text.toString()
            var call: Call<UserToServer>? = api.login(userAuth)
            if (call==null){
                Toast.makeText(requireContext(), "Ошибка авторизации!!", Toast.LENGTH_SHORT).show()
            }else{
                call!!.enqueue(object : Callback<UserToServer> {
                    override fun onFailure(call: Call<UserToServer>, t: Throwable) {
                        Toast.makeText(requireContext(), "Не правильный логин и/или пароль!!", Toast.LENGTH_SHORT).show()
                        Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                    }
                    override fun onResponse(
                        call: Call<UserToServer>,
                        response: Response<UserToServer>
                    ) {
                        if(response.isSuccessful){
                            getApiUser(response.body()!!.id!!.toInt())

                        }else
                            Toast.makeText(requireContext(), "Не правильный логин и/или пароль!!", Toast.LENGTH_SHORT).show()

                    }
                })
            }
        }
    }

    private fun getApiUser(id: Int) {
        var call: Call<UserToServer>? = api.getUserById(id.toLong())
        if (call == null) {
            Toast.makeText(
                requireContext(),
                "Не правильный логин и/или пароль!!",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            call!!.enqueue(object : Callback<UserToServer> {
                override fun onFailure(call: Call<UserToServer>, t: Throwable) {
                    Toast.makeText(requireContext(), "Ошибка авторизации!!", Toast.LENGTH_SHORT)
                        .show()
                    Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                }

                override fun onResponse(
                    call: Call<UserToServer>,
                    response: Response<UserToServer>
                ) {
                    var error = response.errorBody()?.string()?.let {
                        JSONObject(it).getString("message")
                    }
                    userToServer = response.body()
                    if (userToServer != null) {
                        viewAllData.loadUser(
                            User(
                                userToServer!!.id!!.toLong(),
                                userToServer!!.login!!,
                                userToServer!!.email!!
                            )
                        )
                        prefEditor = mySharedPreferences.edit()
                        prefEditor.putInt(idUser, userToServer!!.id!!)
                        prefEditor.putString(login, userToServer!!.login)
                        prefEditor.putString(email, userToServer!!.email)
                        prefEditor.apply()
                        mySharedPreferences = requireContext().getSharedPreferences(
                            section2,
                            AppCompatActivity.MODE_PRIVATE
                        )
                        prefEditor = mySharedPreferences.edit()
                        prefEditor.putString(statusWork, "1")
                        prefEditor.apply()
                        startWork(userToServer!!.id!!)
                    }
                }
            })
        }
    }

    private fun startWork(id: Int) {
        val intent = Intent(this.context, Main2Activity::class.java)
        startActivity(intent)

        loadDataInDB(id)
    }

    private fun loadDataInDB(id: Int) {
        loadTeams(id)
    }
    private fun loadTeams(id: Int) {
        teamsToServer = listOf<TeamToServer>().toMutableList()
        var call:Call<List<TeamToServer>>? = api.getAllTeamsForUser(id.toLong())
        if (call!=null){
            call!!.enqueue(object : Callback<List<TeamToServer>> {
                override fun onFailure(call: Call<List<TeamToServer>>, t: Throwable) {
                    Toast.makeText(requireContext(), "Ошибка загрузки команд!!", Toast.LENGTH_SHORT).show()
                    Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                }
                override fun onResponse(
                    call: Call<List<TeamToServer>>,
                    response: Response<List<TeamToServer>>
                ) {
                    if(response.isSuccessful){
                        Toast.makeText(requireView().context, "Команды загружены!!!", Toast.LENGTH_SHORT).show()
                        teamsToServer = response.body() as MutableList<TeamToServer>
                        var teamsForDB:ArrayList<Team> = ArrayList<Team>()
                        teamsToServer.forEach {
                            teamsForDB.add(
                                Team(it.id.toLong(), it.nameTeam!!, it.address!!,
                                    it.fio!!, it.email!!))
                        }
                        viewAllData.loadAllTeams(teamsForDB)
                        loadMatches(id)
                        loadPlayers(id)
                    }
                }
            })
        }
    }

    private fun loadPlayers(id: Int) {
        playerToServer= listOf<PlayerToServer>().toMutableList()
        var call:Call<List<PlayerToServer>>? = api.getAllPlayersForUser(id.toLong())
        if (call!=null){
            call!!.enqueue(object : Callback<List<PlayerToServer>> {
                override fun onFailure(call: Call<List<PlayerToServer>>, t: Throwable) {
                    Toast.makeText(requireContext(), "Ошибка загрузки матчей!!", Toast.LENGTH_SHORT).show()
                    Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                }
                override fun onResponse(
                    call: Call<List<PlayerToServer>>,
                    response: Response<List<PlayerToServer>>
                ) {
                    if(response.isSuccessful){
                        playerToServer = response.body() as MutableList<PlayerToServer>
                        var players:ArrayList<Player> = ArrayList<Player>()
                        playerToServer.forEach {
                            players.add(
                                Player(it.id!!.toLong(), it.namePlayer!!, it.number!!, it.position!!.toString(),
                                it.captain, it.team!!.id!!.toLong())
                            )
                        }
                        viewAllData.loadAllPlayers(players)
                    }
                }
            })
        }
    }

    private fun loadMatches(id: Int) {
        matchToServer = listOf<MatchToServer>().toMutableList()
        var call:Call<List<MatchToServer>>? = api.getAllMatchesForUser(id.toLong())
        if (call!=null){
            call!!.enqueue(object : Callback<List<MatchToServer>> {
                override fun onFailure(call: Call<List<MatchToServer>>, t: Throwable) {
                    Toast.makeText(requireContext(), "Ошибка загрузки матчей!!", Toast.LENGTH_SHORT).show()
                    Logger.getLogger(requireView().javaClass.name).log(Level.SEVERE, t.message)
                }
                override fun onResponse(
                    call: Call<List<MatchToServer>>,
                    response: Response<List<MatchToServer>>
                ) {
                    if(response.isSuccessful){
                        Toast.makeText(requireView().context, "Матчи загружены!!", Toast.LENGTH_SHORT).show()
                        matchToServer = response.body() as MutableList<MatchToServer>
                        var matchesForDB:ArrayList<Match> = ArrayList<Match>()
                        matchToServer.forEach {
                            if (it.teams!!.isNotEmpty())
                                matchesForDB.add(
                                    Match(it.id, it.nameMatch!!, it.description!!, it.dateMatch.toString(), it.flagCalendar!!,
                                        false, false, false,
                                        it.teams!![0].id!!.toInt(), it.teams!![1].id!!.toInt())
                                )
                        }
                        viewAllData.loadAllMatches(matchesForDB)
                    }
                }
            })
        }
    }

    private fun checkDataUser(): Boolean {

        if (et_LoginL.length() == 0) {
            et_LoginL.error = "Это обязательное поле!"
            return false
        }
        if (et_Password.length() == 0) {
            et_Password.error = "Это обязательное поле!"
            return false
        }
        return true
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment AutorizationFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            AutorizationFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}