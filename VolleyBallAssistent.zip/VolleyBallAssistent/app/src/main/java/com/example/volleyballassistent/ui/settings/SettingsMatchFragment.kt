package com.example.volleyballassistent.ui.settings

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.NumberPicker
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.isVisible
import com.example.volleyballassistent.R
import com.example.volleyballassistent.TrainMatchActivity
import com.example.volleyballassistent.databinding.ActivityMain2Binding
import com.example.volleyballassistent.databinding.FragmentSettingsMatchBinding
import kotlinx.android.synthetic.main.fragment_settings_match.*
import kotlinx.android.synthetic.main.fragment_settings_match.view.*
import org.w3c.dom.Text

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [SettingsMatchFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class SettingsMatchFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    lateinit var mySharedPreferences: SharedPreferences
    private val section = "settings"

    private val pointsToWin = "pointsToWin"
    private val flagSets = "flagSets"
    private val setsToWin = "setsToWin"
    private val pointsForTimeBrake = "pointsForTimeBrake"
    private val flagTimeBrake = "flagTimeBrake"
    private val changeOfSidesInTimeBrake = "changeOfSidesInTimeBrake"
    private val flagTimeOut = "flagTimeOut"
    private val timeInTimeOut = "timeInTimeOut"
    private val toss = "toss"

    lateinit var i:AppCompatButton
    lateinit var arr :Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onViewCreated(v: View, savedInstanceState: Bundle?) {
        super.onViewCreated(v, savedInstanceState)

        i.setOnClickListener {

            val prefEditor: SharedPreferences.Editor = mySharedPreferences.edit()
            prefEditor.putInt(pointsToWin, numPicker_countPointsSet.value)
            prefEditor.putBoolean(flagSets, checkBox_flagControlSets.isChecked)
            prefEditor.putInt(setsToWin, arr.get(numPiker_countSets.value).toInt())
            prefEditor.putInt(pointsForTimeBrake, numPicker_countPointsSetTimeBrake.value)
            prefEditor.putBoolean(flagTimeBrake, if(checkBox_flagControlSets.isChecked) checkBox_numSetTimeBrake.isChecked else false)
            prefEditor.putBoolean(changeOfSidesInTimeBrake, if(checkBox_flagControlSets.isChecked) checkBox_changeOfSidesInTimeBrake.isChecked else false)
            prefEditor.putBoolean(flagTimeOut, checkBox_flagControlTimeOut.isChecked)
            prefEditor.putInt(timeInTimeOut, numPicker_timeInTimeOut.value)
            prefEditor.putBoolean(toss, checkBox_toss.isChecked)
            prefEditor.apply()

            parentFragmentManager.popBackStackImmediate()

            val intent = Intent(this.context, TrainMatchActivity::class.java)
            startActivity(intent)
        }


    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        mySharedPreferences = this.requireActivity().getSharedPreferences(section, AppCompatActivity.MODE_PRIVATE)
        var v:View = inflater.inflate(R.layout.fragment_settings_match, container, false)

        startValueFields(v)
        startVisibleFields(v)

        var t = v.findViewById<NumberPicker>(R.id.numPiker_countSets)

        i=v.btnSaveSettings

        v.findViewById<CheckBox>(R.id.checkBox_flagControlSets).setOnCheckedChangeListener { view, isChecked ->
            setVisibleForSets(isChecked, v)
        }
        v.findViewById<CheckBox>(R.id.checkBox_flagControlTimeOut).setOnCheckedChangeListener { view, isChecked ->
            setVisibleForTimeOut(isChecked, v)
        }
        v.findViewById<CheckBox>(R.id.checkBox_numSetTimeBrake).setOnCheckedChangeListener { view, isChecked ->
            setVisibleForTimeBrake(isChecked, v)
        }


        return v
    }

    private fun startVisibleFields(v: View) {
        setVisibleForSets(mySharedPreferences.getBoolean(flagSets,false), v)
        setVisibleForTimeOut(mySharedPreferences.getBoolean(flagTimeOut,false), v)
        setVisibleForTimeBrake(mySharedPreferences.getBoolean(flagTimeBrake,false), v)
        v.findViewById<CheckBox>(R.id.checkBox_flagControlTimeOut).isChecked = mySharedPreferences.getBoolean(flagTimeOut,false)
    }

    private fun startValueFields(v: View) {
        v.findViewById<NumberPicker>(R.id.numPicker_countPointsSet).minValue = 15
        v.findViewById<NumberPicker>(R.id.numPicker_countPointsSet).maxValue = 100
        v.findViewById<NumberPicker>(R.id.numPicker_countPointsSet).value = mySharedPreferences.getInt(pointsToWin,25)

        arr = arrayOf("3","5")
        v.findViewById<NumberPicker>(R.id.numPiker_countSets).minValue = 0
        v.findViewById<NumberPicker>(R.id.numPiker_countSets).maxValue = arr.size-1
        v.findViewById<NumberPicker>(R.id.numPiker_countSets).displayedValues = arr
        v.findViewById<NumberPicker>(R.id.numPiker_countSets).value = mySharedPreferences.getInt(setsToWin,3)

        v.findViewById<NumberPicker>(R.id.numPicker_countPointsSetTimeBrake).minValue = 8
        v.findViewById<NumberPicker>(R.id.numPicker_countPointsSetTimeBrake).maxValue = v.findViewById<NumberPicker>(R.id.numPicker_countPointsSet).value
        v.findViewById<NumberPicker>(R.id.numPicker_countPointsSetTimeBrake).value = mySharedPreferences.getInt(pointsForTimeBrake,15)

        v.findViewById<CheckBox>(R.id.checkBox_numSetTimeBrake).isChecked = mySharedPreferences.getBoolean(flagTimeBrake,true)
        v.findViewById<CheckBox>(R.id.checkBox_changeOfSidesInTimeBrake).isChecked = mySharedPreferences.getBoolean(changeOfSidesInTimeBrake,true)

        v.findViewById<CheckBox>(R.id.checkBox_toss).isChecked = mySharedPreferences.getBoolean(toss,true)
        v.findViewById<CheckBox>(R.id.checkBox_flagControlSets).isChecked = mySharedPreferences.getBoolean(flagSets,true)
        v.findViewById<CheckBox>(R.id.checkBox_flagControlTimeOut).isChecked = mySharedPreferences.getBoolean(flagTimeOut,true)
        v.findViewById<NumberPicker>(R.id.numPicker_timeInTimeOut).minValue = 10
        v.findViewById<NumberPicker>(R.id.numPicker_timeInTimeOut).maxValue = 120
        v.findViewById<NumberPicker>(R.id.numPicker_timeInTimeOut).value = mySharedPreferences.getInt(timeInTimeOut,60)
    }

    fun setVisibleForSets(flag1:Boolean, v:View){
        v.findViewById<TextView>(R.id.editTextTextMultiLine1).isVisible = flag1
        v.findViewById<NumberPicker>(R.id.numPiker_countSets).isVisible = flag1
        v.findViewById<TextView>(R.id.tvTimeBrake).isVisible = flag1
        v.findViewById<CheckBox>(R.id.checkBox_numSetTimeBrake).isVisible = flag1

        v.findViewById<ScrollView>(R.id.scrollView3).isVisible = flag1
    }
    fun setVisibleForTimeBrake(flag1: Boolean, v:View){
        v.findViewById<TextView>(R.id.tvCountPointsTimeBrake).isVisible = flag1
        v.findViewById<NumberPicker>(R.id.numPicker_countPointsSetTimeBrake).isVisible = flag1
        v.findViewById<TextView>(R.id.tvFlagChangeSides).isVisible = flag1
        v.findViewById<CheckBox>(R.id.checkBox_changeOfSidesInTimeBrake).isVisible = flag1
    }
    fun setVisibleForTimeOut(flag1:Boolean, v:View){
        v.findViewById<TextView>(R.id.tvTimeTimeOut).isVisible = flag1
        v.findViewById<NumberPicker>(R.id.numPicker_timeInTimeOut).isVisible = flag1
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment SettingsMatchFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            SettingsMatchFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }


}