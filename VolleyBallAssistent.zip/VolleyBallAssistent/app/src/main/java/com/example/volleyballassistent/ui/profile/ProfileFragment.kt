package com.example.volleyballassistent.ui.profile

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.fragment.app.activityViewModels
import com.example.volleyballassistent.databinding.FragmentProfileBinding
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewAllData
import com.example.volleyballassistent.workDB.ViewTeam
import com.example.volleyballassistent.workDB.models.User
import com.example.volleyballassistent.workServer.MyApi
import com.example.volleyballassistent.workServer.RetrofitService
import com.example.volleyballassistent.workServer.auth.DataModelAuth
import com.example.volleyballassistent.workServer.models.UserToServer
import kotlinx.android.synthetic.main.fragment_profile.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    lateinit var retrofitService: RetrofitService
    lateinit var api: MyApi

    lateinit var mySharedPreferences: SharedPreferences
    private val section = "user"
    private val idUser = "idUser"
    private val login = "login"
    private val email = "email"

    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewTeam : ViewTeam

    private var status = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        retrofitService = RetrofitService()
        api = retrofitService.retrofit.create(MyApi::class.java)

        db= MainDB.getDatabase(this.requireContext(), CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewTeam = ViewTeam(repository, db.wordDao())

        mySharedPreferences = this.requireContext().getSharedPreferences(section, AppCompatActivity.MODE_PRIVATE)
        if (mySharedPreferences.getInt(idUser, -1)!=-1) {
            status = "profile"
            binding.etPassword1.visibility = View.GONE
            binding.buttonRegistration.visibility = View.GONE
            binding.etLogin.setText(mySharedPreferences.getString(login, ""))
            binding.etEmail.setText(mySharedPreferences.getString(email, ""))
        }
        else {
            status = "regist"
            binding.buttonSave.visibility = View.GONE
        }
        var context = this.requireContext()
        binding.buttonRegistration.setOnClickListener {
            if (checkAllFields()){
                var user = UserToServer()
                user.login = binding.etLogin.text.toString()
                user.email = binding.etEmail.text.toString()
                user.password = binding.etPassword1.text.toString()
                var call: Call<UserToServer>? = api.registration(user)
                call!!.enqueue(object : Callback<UserToServer> {
                    override fun onFailure(call: Call<UserToServer>, t: Throwable) {
                        Toast.makeText(context, "Ошибка регистрации пользователя!!", Toast.LENGTH_SHORT).show()
                    }
                    override fun onResponse(
                        call: Call<UserToServer>,
                        response: Response<UserToServer>
                    ) {
                        if (response.body()!=null) {
                            viewTeam.insertUser(
                                User(response.body()!!.id!!.toLong(), response.body()!!.login!!,
                                    response.body()!!.email!!)
                            )
                            var editor = mySharedPreferences.edit()
                            editor.putInt(idUser, response.body()!!.id!!.toInt())
                            editor.putString(login, response.body()!!.login)
                            editor.putString(email, response.body()!!.email)
                            requireActivity().onBackPressed()

                        }else {
                            AlertDialog.Builder(context)
                                .setTitle("Ошибка регистрации пользователя!!")
                                .setMessage("Логин и/или email могут быть заняты другим пользователем!")
                                .setPositiveButton("ОК") { _, _ -> }
                                .show()
                        }
                    }
                })
            }
        }
        binding.buttonSave.setOnClickListener {
            var user = UserToServer()
            user.login = binding.etLogin.text.toString()
            user.email = binding.etEmail.text.toString()
            user.id = mySharedPreferences.getInt(idUser, -1)
            var call: Call<Boolean>? = api.updateUserToServer(user)
            call!!.enqueue(object : Callback<Boolean> {
                override fun onFailure(call: Call<Boolean>, t: Throwable) {
                    Toast.makeText(context, "Ошибка изменения данных профиля!!", Toast.LENGTH_SHORT).show()
                }
                override fun onResponse(
                    call: Call<Boolean>,
                    response: Response<Boolean>
                ) {
                    if (response.body()==true) {
                        Toast.makeText(context, "Данные изменены!!", Toast.LENGTH_SHORT).show()
                        viewTeam.updateUser(user)
                    }else {
                        AlertDialog.Builder(context)
                            .setTitle("Ошибка изменения данных профиля!!")
                            .setMessage("Логин и/или email могут быть заняты другим пользователем!")
                            .setPositiveButton("ОК") { _, _ -> }
                            .show()
                    }
                }
            })
        }

        val root: View = binding.root
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun checkAllFields(): Boolean {
        //проверка логина
        if (binding.etLogin.length() == 0) {
            binding.etLogin.setError("Это обязательное поле!")
            return false
        }
        //проверка почты
        if (binding.etEmail.length() == 0) {
            binding.etEmail.setError("Это обязательное поле!")
            return false
        }
        //проверка старого пароля
        if (binding.etPassword1.length() == 0 ) {
            binding.etPassword1.setError("Это обязательное поле!")
            return false
        }
        if (binding.etPassword1.length()<8 || binding.etPassword1.length()>20) {
            binding.etPassword1.setError("Пароль должен быть больше 8 и не меньше 20!")
            return false
        }

        // after all validation return true.
        return true
    }
}