package com.example.volleyballassistent.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import androidx.recyclerview.widget.RecyclerView
import com.example.volleyballassistent.R
import com.example.volleyballassistent.workDB.models.Player
import kotlinx.android.synthetic.main.list_players_for_appoint_captain.view.*

class PlayerAdapter:RecyclerView.Adapter<PlayerAdapter.PlayerViewHolder>() {

    private var playerList = mutableListOf<Player>()

    class PlayerViewHolder(view:View):RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlayerViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.list_players_for_appoint_captain, parent, false)
        return PlayerViewHolder(view)
    }

    override fun getItemCount(): Int {
        return playerList.size
    }

    override fun onBindViewHolder(holder: PlayerViewHolder, position: Int) {
        holder.itemView.tvNamePlayer.text = playerList[position].name
        holder.itemView.btn_numPlayer.text = playerList[position].gameNumber.toString()
        holder.itemView.cb_captain.isChecked = playerList[position].captain
        holder.itemView.cb_captain.setOnClickListener {
            if ((it as CheckBox).isChecked){
                for (item in playerList){
                    item.captain=false
                    if(item.gameNumber.toString()==holder.itemView.btn_numPlayer.text)
                        item.captain=true
                }
            }
            notifyDataSetChanged()
        }


    }

        fun setList(list: MutableList<Player>){
            playerList = list
            notifyDataSetChanged()
        }
    fun getList():MutableList<Player>{
        return playerList
    }
}