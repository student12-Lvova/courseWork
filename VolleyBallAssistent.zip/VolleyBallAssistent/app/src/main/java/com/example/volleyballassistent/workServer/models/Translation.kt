package com.example.volleyballassistent.workServer.models

class Translation {
    var id:Int?=null
    var team1name: String? = null
    var team2name: String? = null
    var curScoreTeam1: String? = null
    var curScoreTeam2: String? = null
    var storyScores: String? = null
    var dateUpdate: String? = null
    var user: UserToServer? = null
}