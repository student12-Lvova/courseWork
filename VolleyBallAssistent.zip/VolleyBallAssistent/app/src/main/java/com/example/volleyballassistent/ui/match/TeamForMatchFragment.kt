package com.example.volleyballassistent.ui.match

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.children
import androidx.core.view.get
import androidx.core.view.setMargins
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.RecyclerView
import com.example.volleyballassistent.R
import com.example.volleyballassistent.adapters.PlayerAdapter
import com.example.volleyballassistent.databinding.FragmentInfTeamBinding
import com.example.volleyballassistent.databinding.FragmentTeamInMatchBinding
import com.example.volleyballassistent.models.ModelsForDB
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewTeam
import com.example.volleyballassistent.workDB.models.Player
import com.example.volleyballassistent.workDB.models.Team
import com.example.volleyballassistent.workDB.models.TeamWithPlayers
import kotlinx.android.synthetic.main.add_player.view.*
import kotlinx.android.synthetic.main.add_team.view.*
import kotlinx.android.synthetic.main.appoint_captain.view.*
import kotlinx.android.synthetic.main.fragment_profile.view.*
import kotlinx.android.synthetic.main.fragment_inf_team.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob


class TeamForMatchFragment : Fragment() {
    //---------------Работа с локальной БД----------------------------------------------------------
    lateinit var db: MainDB
    lateinit var repository: MyDBRepository
    lateinit var viewTeam : ViewTeam

    var listTeamWithPlayers = listOf<TeamWithPlayers>().toMutableList()
    lateinit var team: Team
    var namesTeams = listOf<String>().toMutableList()


    //текущая команда
    lateinit var currentTeam: TeamWithPlayers
    lateinit var selectedTeam: TeamWithPlayers

    //--------------Для передачи данных из\в активити-----------------------------------------------
    private val dataModel: DataMatchModel by activityViewModels()
    private val model: ModelsForDB by activityViewModels()
    var numTeam = 0

    //-------------Работа с игроками----------------------------------------
    var positions = listOf("Игрок", "Либеро").toMutableList()
    private lateinit var spinnerAdapter: SpinnerAdapter

    //Адаптер для выбора капитана
    lateinit var playerAdapter: PlayerAdapter
    lateinit var recyclerViewForPlayers: RecyclerView

    companion object {
        fun newInstance() = TeamForMatchFragment()
    }

    var flag = ""



    //---------------------init---------------------------------------------------------------------

    private lateinit var binding: FragmentInfTeamBinding
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db= MainDB.getDatabase(this.requireContext(), CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())


    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentInfTeamBinding.inflate(layoutInflater)

        numTeam = arguments?.getString("numTeam")!!.toInt()
        db= MainDB.getDatabase(this.requireContext(), CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewTeam = ViewTeam(repository, db.wordDao())

        team = Team(null, "", "", "","")
        var listPlayerTeam: MutableList<Player> = listOf<Player>().toMutableList()
        currentTeam = TeamWithPlayers(team, listPlayerTeam)

        if (numTeam==1){
            dataModel.team1.observe(viewLifecycleOwner){
                if (it!=null)
                    currentTeam = it
            }
        }else{
            dataModel.team2.observe(viewLifecycleOwner){
                if (it!=null)
                    currentTeam = it
            }
        }
        observerForTeam()

        return binding.root
    }

    private fun observerForTeam(){
        viewTeam.getTeams()

        viewTeam.allTeams.observe(viewLifecycleOwner) {
            listTeamWithPlayers = it.toMutableList()
            namesTeams = listOf<String>().toMutableList()
            listTeamWithPlayers.forEach { namesTeams.add(it.team.name) }
            initFields()
            if (it.isEmpty()){
                while (binding.gridForNumPlayers.childCount!=1){
                    if (binding.gridForNumPlayers.id!=R.id.btnAddPlayer){
                        binding.gridForNumPlayers.removeView(
                            binding.gridForNumPlayers.get(
                                binding.gridForNumPlayers.childCount-1
                            )
                        )
                    }
                }
                currentTeam.players.forEach {pl ->
                    var lp1 = binding.btnAddPlayer.layoutParams as GridLayout.LayoutParams
                    var btn = addBtnForPlayer(
                        pl.gameNumber.toString(),
                        pl.position.toCharArray()[0],
                        lp1)
                    binding.gridForNumPlayers.addView(btn)

                    if (pl.captain)
                        binding.btnCap.text = pl.gameNumber.toString()
                }
            }else
                setAdapterForTeam()
        }
    }

    private fun setAdapterForTeam() {
        var adapter = ArrayAdapter(this.requireContext(), android.R.layout.simple_spinner_item, namesTeams)
        binding.spChoiseTeam.adapter = adapter
        binding.spChoiseTeam.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if(currentTeam.team.id ==null || currentTeam.team.id!=listTeamWithPlayers[position].team.id)
                    currentTeam = listTeamWithPlayers[position]

                binding.etAdressTeam.setText(currentTeam.team.address)
                binding.edNameRep.setText(currentTeam.team.nameRepresentative)
                binding.edEmailRep.setText(currentTeam.team.emailRepresentative)

                while (binding.gridForNumPlayers.childCount!=1){
                    if (binding.gridForNumPlayers.id!=R.id.btnAddPlayer){
                        binding.gridForNumPlayers.removeView(
                            binding.gridForNumPlayers.get(
                                binding.gridForNumPlayers.childCount-1
                            )
                        )
                    }
                }
                currentTeam.players.forEach {
                    var lp1 = binding.btnAddPlayer.layoutParams as GridLayout.LayoutParams
                    var btn = addBtnForPlayer(
                        it.gameNumber.toString(),
                        it.position.toCharArray()[0],
                        lp1)
                    binding.gridForNumPlayers.addView(btn)

                    if (it.captain)
                        binding.btnCap.text = it.gameNumber.toString()
                }
                if (currentTeam.players.size==0) binding.btnCap.text=""
                updateDataTeam()
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {}
        }
    }

    //заполнение команд и их данных по выбору из списка
    private fun initFields() {
        if (listTeamWithPlayers.size==0 ){
            binding.btnSave.visibility = View.GONE
            binding.edNameTeam.visibility = View.VISIBLE
            binding.spChoiseTeam.visibility = View.GONE
            binding.btnAddTeam.visibility = View.GONE
        }else{
            binding.btnSave.visibility = View.GONE
            binding.edNameTeam.visibility = View.GONE
            binding.spChoiseTeam.visibility = View.VISIBLE
            binding.btnAddTeam.visibility = View.VISIBLE
        }

        if (arguments?.getString("typeWork") == "add"){
            binding.btnSave.visibility = View.VISIBLE
            binding.edNameTeam.visibility = View.VISIBLE
            binding.spChoiseTeam.visibility = View.GONE
            binding.btnAddTeam.visibility = View.GONE
        }

       initFieldsOnClick()
    }

    private fun initFieldsOnClick() {
        binding.edNameTeam.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

                currentTeam.team.name = s.toString()
                updateDataTeam()
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

            }
        })
        binding.etAdressTeam.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

                if (s.toString()!="")
                    currentTeam.team.address = s.toString()
                updateDataTeam()
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

            }
        })
        binding.edNameRep.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

                    currentTeam.team.nameRepresentative = s.toString()
                updateDataTeam()
            }
        })
        binding.edEmailRep.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

                    currentTeam.team.emailRepresentative = s.toString()
                updateDataTeam()
            }
        })
        binding.btnAddTeam.setOnClickListener {
            onAddTeam(binding.btnAddTeam)}
        binding.btnAddPlayer.setOnClickListener {
            onAddPlayer(binding.btnAddPlayer)}
        binding.btnCap.setOnClickListener {
            onAppointCaptain(binding.btnCap)}
        binding.btnSave.setOnClickListener {
            }
    }

    //обновление данных о команде
    private fun updateDataTeam() {
        if (numTeam == 1){
            dataModel.team1.value = currentTeam
        }
        if (numTeam == 2) {
            dataModel.team2.value = currentTeam
        }
    }

    //------------------Слушатели для кнопок---------------------------------------------------------
    //редактирование данных игрока
    private fun onEditPlayer(view: View) {
        var dialogView = LayoutInflater.from(this.requireContext()).inflate(R.layout.add_player, null)
        initFieldsDialogView(dialogView)
        var builder = AlertDialog.Builder(this.requireContext())
            .setView(dialogView)
            .setCancelable(true)
        var title = layoutInflater.inflate(R.layout.title_dialog, null) as TextView?
        title!!.text = "Редактирование игрока"
        builder.setCustomTitle(title)
        var alert = builder.show()
        var curPlayer = Player(null, "", 0, "", false,null)
        for (player in currentTeam.players)
            if (player.gameNumber==(view as AppCompatButton).text.toString().toInt()) {
                curPlayer = player
                break
            }

        dialogView.btnDeletePlayer.visibility = View.VISIBLE
        dialogView.et_namePlayer.setText(curPlayer.name)
        dialogView.et_numPlayer.setText(curPlayer.gameNumber.toString())
        if (curPlayer.position=="Л")
            dialogView.spinner_positionPlayer.setSelection(1)
        if (curPlayer.position=="И")  dialogView.spinner_positionPlayer.setSelection(0)
        dialogView.btnSavePlayer.text = "Сохранить"

        dialogView.btnSavePlayer.setOnClickListener{
            if(chekDataPlayer("edit", dialogView.et_namePlayer, dialogView.et_numPlayer,
                    curPlayer.gameNumber, dialogView.spinner_positionPlayer.selectedItem.toString().toCharArray()[0]))
            {
                currentTeam.players.forEach {
                    if(it.gameNumber == curPlayer.gameNumber){
                        (view as AppCompatButton).text = dialogView.et_numPlayer.text.toString()
                        alert.dismiss()
                        }
                }
            }
            updateDataTeam()
        }
        dialogView.btnDeletePlayer.setOnClickListener{
            var pl = curPlayer
            currentTeam.players.forEach {
                if (it.gameNumber==curPlayer.gameNumber){
                    pl=it
                }
            }
            currentTeam.players.remove(pl)
            binding.gridForNumPlayers.children.forEach {
                it as AppCompatButton
                if (it.text==curPlayer.gameNumber.toString())
                    binding.gridForNumPlayers.removeView(it)
                var index=-1
                currentTeam.players.forEach {
                    if (it.gameNumber == curPlayer.gameNumber)
                        index = currentTeam.players.indexOf(it)
                }
                if (index!=-1)
                    currentTeam.players.removeAt(index)
            }
            alert.dismiss()
            updateDataTeam()
        }

    }
    //добавление команды
    fun onAddTeam(view: View){
        var dialogView = LayoutInflater.from(this.requireContext()).inflate(R.layout.add_team, null)
        var builder = AlertDialog.Builder(this.requireContext())
            .setView(dialogView)
            .setCancelable(true)
        var title = layoutInflater.inflate(R.layout.title_dialog, null) as TextView?
        title!!.text = "Добавление команды"
        builder.setCustomTitle(title)
        var alert = builder.show()
        dialogView.btn_saveNewTeam.setOnClickListener{
            if (chekDataTeam(dialogView.ed_nameTeam, dialogView.ed_nameRep)){
                addTeam(dialogView.ed_nameTeam.text.toString(),
                    dialogView.et_adressTeam.text.toString(),
                    dialogView.ed_nameRep.text.toString(),
                    dialogView.ed_emailRep.text.toString())

                observerForTeam()
                alert.dismiss()
            }


        }


    }

    private fun addTeam(name: String, address: String, nameRep: String, emailRep: String) {
        viewTeam.insertTeam(Team(null, name, address, nameRep, emailRep))
    }

    private fun chekDataTeam(name: EditText, nameRep: EditText): Boolean {
        if (name.text==null || name.text.toString()==""){
            name.error = "Обязательное поле!"
            return false
        }
        if (nameRep.text==null || nameRep.text.toString()==""){
            nameRep.error = "Обязательное поле!"
            return false
        }
        return true
    }

    //добавление игрока
    fun onAddPlayer(view: View){
        var dialogView = LayoutInflater.from(this.requireContext()).inflate(R.layout.add_player, null)
        initFieldsDialogView(dialogView)
        var builder = AlertDialog.Builder(this.requireContext())
            .setView(dialogView)
            .setCancelable(true)
        var title = layoutInflater.inflate(R.layout.title_dialog, null) as TextView?
        title!!.text = "Добавление игрока"
        builder.setCustomTitle(title)
        dialogView.btnDeletePlayer.visibility = View.GONE
        var alert = builder.show()
        dialogView.btnSavePlayer.setOnClickListener{
            if(chekDataPlayer(
                    "add",
                    dialogView.et_namePlayer,
                    dialogView.et_numPlayer,
                    -1,
                    dialogView.spinner_positionPlayer.selectedItem.toString().toCharArray()[0]
                ))
            {
                var lp1 = btnAddPlayer.layoutParams as GridLayout.LayoutParams
                var btn = addBtnForPlayer(
                    dialogView.et_numPlayer.text.toString(),
                    dialogView.spinner_positionPlayer.selectedItem.toString().toCharArray()[0],
                    lp1)
                alert.dismiss()
                (view.parent as View).findViewById<GridLayout>(R.id.gridForNumPlayers).addView(btn)
            }
            updateDataTeam()
        }
        if ((view.parent as View).findViewById<GridLayout>(R.id.gridForNumPlayers).childCount>=14){
            view.visibility = View.GONE
        }
    }
    //Вызов окна для выбора капитана
    fun onAppointCaptain(view: View){
        var dialogView = LayoutInflater.from(this.requireContext()).inflate(R.layout.appoint_captain, null)
        var builder = AlertDialog.Builder(this.requireContext())
            .setView(dialogView)
            .setCancelable(false)
        var title = layoutInflater.inflate(R.layout.title_dialog, null) as TextView?
        title!!.text = "Выберите капитана"
        builder.setCustomTitle(title)
        var alert = builder.show()

        recyclerViewForPlayers = dialogView.recyclerView
        playerAdapter = PlayerAdapter()
        recyclerViewForPlayers.adapter = playerAdapter
        playerAdapter.setList(currentTeam.players)

        dialogView.btnSaveCaptain.setOnClickListener {
            currentTeam.players = playerAdapter.getList()
            for (item in currentTeam.players) {
                if (item.captain) {
                    if (item.position == "Л") {
                        (view as Button).setBackgroundResource(R.drawable.ovalorange)
                        (view as Button).setTextColor(Color.BLACK)
                    }
                    else {
                        (view as Button).setBackgroundResource(R.drawable.player)
                        (view as Button).setTextColor(Color.WHITE)
                    }

                    (view as Button).text = item.gameNumber.toString()
                    break
                }
            }
            alert.dismiss()
            updateDataTeam()
        }

    }

    //------------------Вспомогательные функции------------------------------------------------------
    //проверка вводимых данных об игроке где type - тип работы (добавление нового или редактирование старого)
    private fun chekDataPlayer(type:String, etNameplayer: EditText?, etNumplayer: EditText?, oldNumPlayer: Int, selectedItem: Char):Boolean {
        if (etNameplayer!!.length() == 0) {
            etNameplayer.error = "Это обязательное поле!"
            return false
        }
        if (etNumplayer!!.length() == 0) {
            etNumplayer.error = "Это обязательное поле!"
            return false
        }

        if (type=="add"){
            for (player in currentTeam.players){
                if (player.gameNumber == etNumplayer.text.toString().toInt()) {
                    etNumplayer.setError("Игрок с таким номером уже существует!")
                    return false
                }
            }
            addPlayer(etNameplayer.text.toString(),
                etNumplayer.text.toString().toInt(), selectedItem)
        }else{
            for (player in currentTeam.players){
                if (player.gameNumber == etNumplayer.text.toString().toInt() && oldNumPlayer!=etNumplayer.text.toString().toInt()) {
                    etNumplayer.setError("Игрок с таким номером уже существует!")
                    return false
                }
            }
            editPlayer(oldNumPlayer, etNameplayer.text.toString(),
                etNumplayer.text.toString().toInt(), selectedItem)
        }

        return true
    }
    //добавление нового игрока в список
    private fun addPlayer(name: String, num: Int, pos: Char) {
        currentTeam.players.add(
            Player(null, name, num, pos.toString(), false,null))
        updateDataTeam()
    }
    //редактирование старого
    private fun editPlayer(oldNumPlayer: Int, newName: String, newNumPlayer: Int, newPosition: Char) {
        currentTeam.players.forEach{
            if (it.gameNumber==oldNumPlayer){
                it.name = newName
                it.gameNumber = newNumPlayer
                it.position = newPosition.toString()
                updateDataTeam()
                setAdapterForTeam()
            }
        }
    }
    //работа с диалоговым окном для редактирования
    private fun initFieldsDialogView(dialogView: View) {
        var countLibero=0
        for (player in currentTeam.players){
            if (player.position == "Л") countLibero++
        }

        if (countLibero==2 && positions.size==2) positions.removeAt(1)

        spinnerAdapter = ArrayAdapter(this.requireContext(),
            android.R.layout.simple_spinner_item, positions)
        dialogView.spinner_positionPlayer.adapter = spinnerAdapter
    }
    //добавление кнопки игрока в интерфейсе
    private fun addBtnForPlayer(num: String, position: Char, lp1: GridLayout.LayoutParams): AppCompatButton {
        var btn = AppCompatButton(this.requireContext())
        btn.text = num
        if (position=='Л')
            btn.setBackgroundResource(R.drawable.ovalorange)
        else  btn.setBackgroundResource(R.drawable.player);
        btn.setTextAppearance(R.style.TextViewForBtn);
        btn.setOnClickListener{
            onEditPlayer(it)
        }
        val layoutParams = GridLayout.LayoutParams()
        layoutParams.width = lp1!!.width
        layoutParams.height = lp1.height
        layoutParams.setMargins(lp1.topMargin)
        btn.layoutParams = layoutParams
        return btn
    }


}