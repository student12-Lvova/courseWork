package com.example.volleyballassistent

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.ActionBar
import androidx.fragment.app.Fragment
import com.example.volleyballassistent.databinding.ActivityLoginBinding
import com.example.volleyballassistent.databinding.ActivityMatchBinding
import com.example.volleyballassistent.ui.match.DataMatchModel
import com.example.volleyballassistent.ui.profile.ProfileFragment
import com.example.volleyballassistent.ui.settings.SettingsMatchFragment
import com.example.volleyballassistent.workDB.MainDB
import com.example.volleyballassistent.workDB.MyDBRepository
import com.example.volleyballassistent.workDB.ViewTeam
import com.example.volleyballassistent.workServer.MyApi
import com.example.volleyballassistent.workServer.RetrofitService
import kotlinx.android.synthetic.main.app_bar_main2.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class LoginActivity : AppCompatActivity() {
    lateinit var binding: ActivityLoginBinding
    lateinit var db : MainDB
    lateinit var repository : MyDBRepository
    lateinit var viewTeam : ViewTeam

    lateinit var mySharedPreferences: SharedPreferences
    private val section = "user"
    private val idUser = "idUser"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val actionBar: ActionBar? = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        db= MainDB.getDatabase(this, CoroutineScope(SupervisorJob()))
        repository = MyDBRepository(db.wordDao())
        viewTeam = ViewTeam(repository, db.wordDao())
        setContentView(binding.root)

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.frameLayout, AutorizationFragment())
            .addToBackStack(null)
            .commit()

    }
    fun registration(view: View){
        mySharedPreferences = this.getSharedPreferences(section, MODE_PRIVATE)
        var prefEditor = mySharedPreferences.edit()
        prefEditor.putInt(idUser, -1)
        prefEditor.apply()
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.frameLayout, ProfileFragment())
            .addToBackStack(null)
            .commit()
    }
    override fun onBackPressed() {
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}