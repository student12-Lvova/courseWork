package com.example.volleyballassistent.workDB.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName = "Match", foreignKeys = arrayOf(ForeignKey(entity = Team::class,
    parentColumns = arrayOf("id"),
    childColumns = arrayOf("team1_id"),
    onDelete = ForeignKey.CASCADE),
    ForeignKey(entity = Team::class,
        parentColumns = arrayOf("id"),
        childColumns = arrayOf("team2_id"),
        onDelete = ForeignKey.CASCADE)))
data class Match(
    @PrimaryKey(autoGenerate = true)
    var id:Int?=null,
    @ColumnInfo(name = "name")
    var name:String,
    @ColumnInfo(name = "description")
    var description:String,
    @ColumnInfo(name = "dateMatch")
    var dateMatch: String,
    @ColumnInfo(name = "flagCalendar")
    var flagCalendar:Boolean,
    @ColumnInfo(name = "protocol")
    var protocol:Boolean,
    @ColumnInfo(name = "team_placement")
    var teamPlacement:Boolean,
    @ColumnInfo(name = "sending_email")
    var sendingEmail:Boolean,
    @ColumnInfo(name = "team1_id")
    var team1Id:Int?=null,
    @ColumnInfo(name = "team2_id")
    var team2Id:Int?=null
)
