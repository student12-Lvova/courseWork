package com.example.pr1_mp

import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.example.pr1_mp.R.*
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.currentTeam.EditCurrentTeamActivity
import com.example.pr1_mp.models.CurrentTeam
import com.example.pr1_mp.models.Representative
import com.example.pr1_mp.team.AddTeamActivity
import java.time.LocalDate


class CreateMatchActivity : AppCompatActivity() {
    lateinit var nameT1:Spinner
    lateinit var btnAddT1: Button
    lateinit var btnAddT2: Button
    lateinit var nameT2:Spinner
    lateinit var etFIOManageT1:TextView
    lateinit var etEmailManageT1:TextView
    lateinit var etPhoneManageT1:TextView
    lateinit var btnCoachingStaffT1: Button
    private lateinit var btnStaffTeam1: Button
    lateinit var etFIOManageT2:TextView
    lateinit var etEmailManageT2:TextView
    lateinit var etPhoneManageT2:TextView
    lateinit var btnCoachingStaffT2: Button
    lateinit var btnStaffTeam2: Button
    lateinit var btnStartMatch: Button
    lateinit var btnRestart:AppCompatButton

    lateinit var workMyDB: WorkMyDB
    var idUser: Long = 0
    lateinit var settings: SharedPreferences
    private val PREFS_FILE = "Account"
    private val PREF_ID = "Id"

    var idTeam1: Long = 0
    var idRepT1: Long = 0
    var idTeam2: Long = 0
    var idRepT2: Long = 0
    lateinit var listCurTeam: MutableList<CurrentTeam>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_create_match)
        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            // showing the back button in action bar
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        workMyDB = WorkMyDB(this@CreateMatchActivity)
        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE);
        idUser= settings.getString(PREF_ID,"id")!!.toLong();
        workMyDB.idUser=idUser
        workMyDB.deleteAllCurTeam()
        addInCurrentTeam()
        initFields()
    }


    private fun initFields() {
        etFIOManageT1 = findViewById(id.tvFIO)
        etEmailManageT1 = findViewById(id.tvEmail)
        etPhoneManageT1 = findViewById(id.tvPhoneNum)
        initSpiners()

        btnCoachingStaffT1 = findViewById(id.bInfAboutTrain)
        btnCoachingStaffT1.setOnClickListener(){
            val intent = Intent(this@CreateMatchActivity, AddStaffTrainers::class.java)
            intent.putExtra("idTeam", workMyDB.selectCurTeamByIdTeam(idTeam1.toInt()).id)
            intent.putExtra("type", "editCur")
            startActivity(intent)

        }
        btnStaffTeam1 = findViewById(id.bInfAboutTeam)
        btnStaffTeam1.setOnClickListener(){
            val intent = Intent(this@CreateMatchActivity, EditCurrentTeamActivity::class.java)
            if (idTeam1>0){
                intent.putExtra("idTeam",workMyDB.selectCurTeamByIdTeam(idTeam1.toInt()).id)
            }
            startActivity(intent)
        }

        btnAddT1 = findViewById(id.btnAddNewTeam1)
        btnAddT1.setOnClickListener(){
            val intent =
                Intent(this@CreateMatchActivity, AddTeamActivity::class.java)
            startActivity(intent)


        }

        btnAddT2 = findViewById(id.btnAddNewTeam2)
        btnAddT2.setOnClickListener(){
            val intent =
                Intent(this@CreateMatchActivity, AddTeamActivity::class.java)
            startActivity(intent)
        }

        etFIOManageT2 = findViewById(id.tvFIO1)
        etEmailManageT2 = findViewById(id.tvEmail1)
        etPhoneManageT2 = findViewById(id.tvPhoneNum1)

        btnCoachingStaffT2 = findViewById(id.bInfAboutTrain1)
        btnCoachingStaffT2.setOnClickListener(){
            val intent = Intent(this@CreateMatchActivity, AddStaffTrainers::class.java)
            intent.putExtra("idTeam", workMyDB.selectCurTeamByIdTeam(idTeam2.toInt()).id)
            intent.putExtra("type", "edit")
            startActivity(intent)

        }

        btnStaffTeam2 = findViewById(id.bInfAboutTeam1)
        btnStaffTeam2.setOnClickListener(){
            val intent = Intent(this@CreateMatchActivity, EditCurrentTeamActivity::class.java)
            if (idTeam2>0) {

                intent.putExtra("idTeam", workMyDB.selectCurTeamByIdTeam(idTeam2.toInt()).id)
            }
            startActivity(intent)
        }

        btnStartMatch = findViewById(id.btnStartMatch)
        btnStartMatch.setOnClickListener(){

            if (idTeam1!=idTeam2){

                var contentValues = ContentValues()
                var idCurTeam1 = workMyDB.selectCurTeamByIdTeam(idTeam1.toInt()).id
                var idCurTeam2 = workMyDB.selectCurTeamByIdTeam(idTeam2.toInt()).id
                contentValues.put("idTeam1", idCurTeam1)
                contentValues.put("idTeam2", idCurTeam2)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    contentValues.put("dateMatch", LocalDate.now().toString())
                }
                val intent = Intent(this@CreateMatchActivity, InfAboutMatchActivity::class.java)
                intent.putExtra("idMatch", workMyDB.addMatch(contentValues, idCurTeam1.toLong(), idCurTeam2.toLong()))
                startActivity(intent)
            }
            else
                Toast.makeText(this@CreateMatchActivity,
                    "Команды одинаковые!", Toast.LENGTH_SHORT).show()
        }

        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE);
        idUser = settings.getString(PREF_ID,"id")!!.toLong()

        btnRestart = findViewById(R.id.btnRestart)
        btnRestart.setOnClickListener {
            workMyDB = WorkMyDB(this)
            workMyDB.idUser= settings.getString(PREF_ID,"id")!!.toLong();
            initSpiners()
        }

    }

    private fun addInCurrentTeam() {

        var teams = workMyDB.selectAllTeamByIdUser()//все команды user-а
        //надо сохранить их в current_team
        //сначала игроков
        for (team in teams){
            if (workMyDB.selectCurTeamByIdTeam(team.id.toInt())==null){
                var players = workMyDB.selectPlayersByIdTeam(team.id.toInt())
                var cvCurrentPlayer = listOf<ContentValues>().toMutableList()
                for (pl in players){

                        var contentValues = ContentValues()
                        contentValues.put("idPlayer", pl.id);
                        contentValues.put("idTeam", team.id)
                        contentValues.put("position", pl.position.toString())

                        cvCurrentPlayer.add(contentValues)
                }
                var contentValues = ContentValues()
                contentValues.put("idTeam", team.id)

                var i = workMyDB.selectRepresentativeByIdTeam(team.id.toInt(), 'M')
                if (i==null){
                    i=workMyDB.selectRepresentativeByIdTeam(team.id.toInt(), 'T')
                    if (i!=null) {
                        contentValues.put("idManager", i.id)
                        workMyDB.addCurrentTeam(cvCurrentPlayer, contentValues, team.id.toInt())
                    }
                }
                else {
                    contentValues.put("idManager", i.id)
                    workMyDB.addCurrentTeam(cvCurrentPlayer, contentValues, team.id.toInt())
                }



            }

        }
    }

    private fun initSpiners(){


        listCurTeam = workMyDB.selectAllCurTeamByIdUser()

        var nameTeams  = listOf<String>().toMutableList()

        if (listCurTeam!=null){
            for (team  in  listCurTeam){
                nameTeams.add(team.team.name)
            }
        }


        var adapter =  ArrayAdapter(this,
            android.R.layout.simple_spinner_item, nameTeams)

        nameT1 = findViewById(id.spinnerNameT1)
        nameT1.adapter = adapter

        nameT2 = findViewById(id.spinnerNameT2)
        nameT2.adapter = adapter

        nameT1.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, view: View?,
                                        position: Int, id: Long) {
                var selectTeam = CurrentTeam()
                for (team in listCurTeam){
                    if (team.team.name.equals(nameTeams[position]))
                        selectTeam = team
                }
                idTeam1 = selectTeam.team.id.toLong()

                var manager = workMyDB.selectRepresentativeById(selectTeam.idManage)

                if (manager!=null) {
                    idRepT1 = manager.id
                    etFIOManageT1.text = manager.fio
                    etEmailManageT1.text = manager.email
                    etPhoneManageT1.text = manager.phoneNum
                }
                else Toast.makeText(this@CreateMatchActivity,
                    "не найден представитель команды", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // write code to perform some action
            }
        }
        nameT2.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, view: View?,
                                        position: Int, id: Long) {
                var selectTeam = CurrentTeam()
                for (team in listCurTeam){
                    if (team.team.name.equals(nameTeams[position]))
                        selectTeam = team
                }
                idTeam2 = selectTeam.team.id.toLong()

                var manager = workMyDB.selectRepresentativeById(selectTeam.idManage)

                if (manager!=null) {
                    idRepT2 = manager.id
                    etFIOManageT2.text = manager.fio
                    etEmailManageT2.text = manager.email
                    etPhoneManageT2.text = manager.phoneNum
                }
                else Toast.makeText(this@CreateMatchActivity,
                    "не найден представитель команды", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // write code to perform some action
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }
}

