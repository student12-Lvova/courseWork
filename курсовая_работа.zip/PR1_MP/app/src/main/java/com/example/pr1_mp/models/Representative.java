package com.example.pr1_mp.models;

import androidx.annotation.Size;

import org.jetbrains.annotations.NotNull;

public class Representative {

    private long id;
    @NotNull
    private String lastname;
    @NotNull
    private String firstname;
    private String patronymic;
    private String email;
    @Size(11)
    private String phoneNum;
    @NotNull
    private char jobTitle;

    public Representative(@NotNull long id, @NotNull String lastname, @NotNull String firstname,
                          String patronymic, String email, String phoneNum,
                          @NotNull char jobTitle) throws Exception {
        this.id = id;
        if(!lastname.matches("[а-яА-Я]+"))
            throw new Exception("Неверный ввод фамилии");
        this.lastname = lastname;
        if(!firstname.matches("[а-яА-Я]+"))
            throw new Exception("Неверный ввод фамилии");
        this.firstname = firstname;
        if(!patronymic.equals("")&&!patronymic.matches("[а-яА-Я]+"))
            throw new Exception("Неверный ввод отчества");
        this.patronymic = patronymic;
        this.email = email;
        this.phoneNum = phoneNum;
        this.jobTitle = jobTitle;
    }
    public Representative() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFIO() {
        if (patronymic.equals(""))
            return lastname + " " + firstname.charAt(0) + "." ;
        else
            return lastname + " " + firstname.charAt(0) + "." + patronymic.charAt(0) + ".";
    }

    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public char getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(char jobTitle) {
        this.jobTitle = jobTitle;
    }
}
