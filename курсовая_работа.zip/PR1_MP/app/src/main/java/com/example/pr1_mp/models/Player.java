package com.example.pr1_mp.models;

import org.jetbrains.annotations.NotNull;

import java.util.concurrent.ExecutionException;

public class Player {
    private long id;
    private long idTeam;
    @NotNull
    private String lastname;
    @NotNull
    private String firstname;
    private String patronymic;
    @NotNull
    private int numPlayer;
    @NotNull
    private String position;

    @NotNull
    private String fio;


    public Player(@NotNull long id, @NotNull long idTeam, @NotNull String lastname,
                  @NotNull String firstname, String patronymic, @NotNull int numPlayer,
                  @NotNull String position) throws Exception {
        this.id = id;
        this.idTeam = idTeam;
        this.lastname = lastname;
        this.firstname = firstname;
        this.patronymic = patronymic;
        this.numPlayer = numPlayer;
        this.position = position;
        if (patronymic.equals(""))
            this.fio =  lastname + " " + firstname.charAt(0) + "." ;
        else
            this.fio =  lastname + " " + firstname.charAt(0) + "." + patronymic.charAt(0) + ".";
    }
    public Player(@NotNull String lastname, @NotNull String firstname, String patronymic,
                  @NotNull int numPlayer, @NotNull String position) throws Exception {
        this.lastname = lastname;
        this.firstname = firstname;
        this.patronymic = patronymic;
        this.numPlayer = numPlayer;
        this.position = position;
        if (patronymic.equals(""))
            this.fio =  lastname + " " + firstname.charAt(0) + "." ;
        else
            this.fio =  lastname + " " + firstname.charAt(0) + "." + patronymic.charAt(0) + ".";

    }

    public Player() { }

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    public String getLastname() {
        return lastname;
    }
    public void setLastname(String lastname) throws Exception {
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) throws Exception {
        this.firstname = firstname;
    }

    public String getPatronymic() {
        return patronymic;
    }
    public void setPatronymic(String patronymic) throws Exception {
        this.patronymic = patronymic;
    }

    public int getNumPlayer() {
        return numPlayer;
    }
    public void setNumPlayer(int numPlayer) {
        this.numPlayer = numPlayer;
    }

    public String getPosition() {
        return position;
    }
    public void setPosition(String position) throws Exception {
        this.position = position;
    }

    public String getFio() {
        if (patronymic.equals(""))
            this.fio =  lastname + " " + firstname.charAt(0) + "." ;
        else
            this.fio =  lastname + " " + firstname.charAt(0) + "." + patronymic.charAt(0) + ".";
        return fio;
    }
}
