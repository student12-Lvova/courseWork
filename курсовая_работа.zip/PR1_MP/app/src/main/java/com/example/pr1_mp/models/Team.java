package com.example.pr1_mp.models;

import org.jetbrains.annotations.NotNull;

public class Team {
    private long id;
    @NotNull
    private long idUser;
    @NotNull
    private long idTrain;
    @NotNull
    private long idManage;
    @NotNull
    private String name;

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    private String address;

    public Team(@NotNull long id, @NotNull long idUser, @NotNull long idTrain,
                @NotNull long idManage, @NotNull String name, String address) {
        this.id = id;
        this.idUser = idUser;
        this.idTrain = idTrain;
        this.idManage = idManage;
        this.name = name;
        this.address = address;
    }

    public Team() { }

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    public long getIdUser() {
        return idUser;
    }
    public void setIdUser(long idUser) {
        this.idUser = idUser;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}
