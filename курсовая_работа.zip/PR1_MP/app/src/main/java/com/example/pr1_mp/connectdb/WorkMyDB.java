package com.example.pr1_mp.connectdb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.widget.Toast;

import com.example.pr1_mp.models.CurrentPlayer;
import com.example.pr1_mp.models.CurrentTeam;
import com.example.pr1_mp.models.Match;
import com.example.pr1_mp.models.Player;
import com.example.pr1_mp.models.Representative;
import com.example.pr1_mp.models.Team;
import com.example.pr1_mp.models.User;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class WorkMyDB {
    private DatabaseHelper mDBHelper;
    private SQLiteDatabase mDb;
    private Context context;

    public Long idUser;

    public WorkMyDB(Context context) {
        this.context = context;
        try {
            mDBHelper = new DatabaseHelper(context);
            mDBHelper.updateDataBase();
        } catch (IOException mIOException) {
            throw new Error("UnableToUpdateDatabase");
        }

        try {
            mDb = mDBHelper.getWritableDatabase();
        } catch (SQLException mSQLException ) {
            throw mSQLException;
        }
    }

    //User
    public boolean addUser(@NotNull ContentValues contentValues) throws Exception {
        if (checkDataUser(contentValues.getAsString("login"),
                contentValues.getAsString("oldPassword"),contentValues.getAsString("email"),
                contentValues.getAsString("phone"))) {
            long count = mDb.insert("users_mydb", null, contentValues);
            if (count <= 0) {
                Toast.makeText(
                        context,
                        "Что то прошло не так при создании нового пользователя! ",
                        Toast.LENGTH_SHORT
                ).show();
                return false;
            }
            return true;
        }
        return false;
    }
    public User selectUserId(@NotNull Long id) throws Exception {
        mDb = mDBHelper.getReadableDatabase();
        Cursor cursor = mDb.rawQuery("SELECT * FROM users_mydb where id="+id, null);
        cursor.moveToFirst();
        if (cursor.getCount()!=0)
            return new User(cursor.getLong(0),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3),
                cursor.getString(4));
        else throw new Exception("Ненайден пользователь с данным id");
    }
    public boolean auth(@NotNull String flogin, @NotNull String fpassword){
        Cursor cursor = mDb.rawQuery("select * from users_mydb where login = ? and password = ?", new String[]{flogin ,fpassword});
        if (cursor.getCount()>0){
            cursor.moveToFirst();
            idUser = cursor.getLong(0);
            return  true;
        }
        else return false;
    }
    public boolean updateUser(@NotNull ContentValues contentValues, @NotNull String oldPassword) throws Exception {
        if(checkDataUser(contentValues.getAsString("login"), oldPassword, contentValues.getAsString("email"), contentValues.getAsString("phone"))) {
            int count = mDb.update("users_mydb", contentValues, "id = ?", new String[]{idUser.toString()});
            if (count > 0) return true;
            else
                throw new Exception("Что-то пошло не так при изменении данных!");
        }
        return false;
    }
    private boolean checkDataUser(@NotNull String login, String oldPassword, @NotNull String email, String phone) {
        Cursor cursor = mDb.rawQuery("select * from users_mydb where (login = ? or email = ? or phone=?) and id!=?",
                new String[]{login, email, phone, String.valueOf(idUser)});
        if (cursor.getCount()<=0) {
            Cursor cursor1 = mDb.rawQuery("select * from users_mydb where id=?",new String[]{idUser.toString()});
            cursor1.moveToFirst();
            //проверим правильно ли введен старый пароль
            if (!oldPassword.equals("")&&!cursor1.getString(2).equals(oldPassword)) {
                Toast.makeText(
                        context,
                        "Старый пароль ввведен неверно! ",
                        Toast.LENGTH_SHORT
                ).show();
                return false;
            }
            else
                return true;
        }
        else Toast.makeText(context, "Заданые логин, email и номер телефона заняты другим пользователем!", Toast.LENGTH_SHORT).show();
        return false;
    }

    //Team
    public void addTeam(@NotNull List<ContentValues> listPlayers, @NotNull ContentValues cvTeam) throws Exception {
        if (listPlayers.size()>=6&&listPlayers.size()<=14){

            long countTeam = mDb.insert("teams", null, cvTeam);
            int idTeam = selectLastTeam();
            if (countTeam>0) {

                Toast.makeText(context, "Команда добавлена", Toast.LENGTH_SHORT).show();
                //добавляем игроков
                for (ContentValues cvPlayer: listPlayers) {
                    cvPlayer.put("idTeam", idTeam);
                    long count = mDb.insert("players", null, cvPlayer);
                    if (count>0) {
                    }else throw new Exception("Что-то пошло не так при добавлении игрока!");
                }

            } else throw new Exception("Что-то пошло не так при добавлении команды!");

        } else  Toast.makeText(context, "Количество игроков либо меньше 6, либо больше 12!", Toast.LENGTH_SHORT).show();
    }
    private int selectLastTeam() {
        Cursor cursor = mDb.rawQuery("SELECT * FROM teams ", null);
        cursor.moveToLast();
        return cursor.getInt(0);
    }
    public List<Team> selectAllTeamByIdUser(){
        List<Team> teams = new ArrayList<Team>() ;
        Cursor cursor = mDb.rawQuery("SELECT * FROM teams where idUser=?",new String[]{idUser.toString()});
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            Toast.makeText(context, "" + cursor.getCount(), Toast.LENGTH_SHORT).show();
            teams.add(new Team( cursor.getInt(0),
                    cursor.getInt(1),
                    cursor.getInt(2),
                    cursor.getInt(3),
                    cursor.getString(4),
                    cursor.getString(5)));
            cursor.moveToNext();
        }
        return teams;
    }
    public Team selectTeambyId(@NotNull int id) throws Exception {
        Cursor cursor = mDb.rawQuery("SELECT * FROM teams where id=?",
                new String[]{String.valueOf(id)});
        cursor.moveToFirst();
        if (cursor.getCount()!=0)
            return new Team( cursor.getInt(0),
                cursor.getInt(1),
                cursor.getInt(2),
                cursor.getInt(3),
                cursor.getString(4),
                cursor.getString(5));
        else {
            throw new Exception("По данному id = "+id+" не найдены данные о команде");
        }
    }
    public boolean updateTeam(@NotNull ContentValues contentValues, List<ContentValues> cvPlayers) throws Exception {
        int count = mDb.update("teams", contentValues, "id = ?",
                new String[]{contentValues.getAsInteger("id").toString()});
        if (count > 0) {
            Toast.makeText(context, "Изменения внесены!", Toast.LENGTH_SHORT).show();
            for (ContentValues cvPlayer : cvPlayers) {
                if (cvPlayer.getAsInteger("id")!=null){
                    count = mDb.update("players", cvPlayer, "id = ?",
                            new String[]{cvPlayer.getAsInteger("id").toString()});
                    if (count<=0)
                        throw new Exception("Что-то пошло не так при изменении данных игрока!");
                }
                else {
                    ContentValues cv = new ContentValues();
                    cv.put("idTeam", cvPlayer.getAsInteger("idTeam"));
                    cv.put("lastname", cvPlayer.getAsString("lastname"));
                    cv.put("firstname", cvPlayer.getAsString("firstname"));
                    cv.put("patronymic", cvPlayer.getAsString("patronymic"));
                    cv.put("numPlayer", cvPlayer.getAsInteger("numPlayer"));
                    cv.put("position", cvPlayer.getAsString("position"));

                    long count1 = mDb.insert("players", null, cv);
                    if (count1<=0L)
                        throw new Exception("Что-то пошло не так при добавлении нового игрока!");
                }

            }
            return true;
        } else {
            throw new Exception("Что-то пошло не так при изменении данных!");
        }
    }
    public int selectTeamLastId() {
        Cursor cursor = mDb.rawQuery("SELECT * FROM teams", null);
        cursor.moveToLast();
        return cursor.getInt(0);
    }

    //Representative
    public Representative selectRepresentativeById(@NotNull int id) throws Exception {
        Cursor cursor = mDb.rawQuery("SELECT * FROM representatives where id=?",
                new String[]{String.valueOf(id)});
        cursor.moveToFirst();
        if (cursor.getCount()!=0)
            return new Representative( cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getString(6).toCharArray()[0]);
        else {
            throw new Exception("По данному id = "+id+" не найдены данные о команде");
        }
    }
    public Representative selectRepresentativeByIdTeam(@NotNull int idTeam, @NotNull char jobTitle) throws Exception {
        Cursor cursor ;
        if (jobTitle=='M'){
            cursor = mDb.rawQuery("SELECT * FROM Representatives WHERE " +
                            "id = (SELECT idManage FROM teams where id=?)",
                    new String[]{String.valueOf(idTeam)});
            cursor.moveToFirst();
            if (cursor.getCount()>0){
                return new Representative(cursor.getLong(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getString(5),
                        cursor.getString(6).toCharArray()[0]);
            }
        }
        if (jobTitle=='T'){
            cursor = mDb.rawQuery("SELECT * FROM Representatives WHERE " +
                            "id = (SELECT idTrain FROM teams where id=?)",
                    new String[]{String.valueOf(idTeam)});
            cursor.moveToFirst();
            if (cursor.getCount()>0){
                return new Representative(cursor.getLong(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getString(5),
                        cursor.getString(6).toCharArray()[0]);
            }
        }
        return null;
    }
    public void addRepresentative(@NotNull ContentValues contentValues) throws Exception {
        long count = mDb.insert("representatives", null, contentValues);
        if (count<=0)
            throw new Exception("Представитель команды не добавлен");
    }
    public boolean updateRepresentative(@NotNull ContentValues contentValues){
        int count = mDb.update("representatives", contentValues, "id = ?",
                new String[]{contentValues.getAsInteger("id").toString()});
            if (count <= 0) {
                throw new RuntimeException("Что-то пошло не так при изменении данных!");
            }
            else return true;
    }
    public int selectRepresentativeLastId() {
        Cursor cursor = mDb.rawQuery("SELECT * FROM Representatives", null);
        cursor.moveToLast();
        return cursor.getInt(0);
    }

    //Player
    public boolean updatePlayer(ContentValues contentValues){
        int count = mDb.update("players", contentValues, "id = ?",
                new String[]{contentValues.getAsInteger("id").toString()});
        if (count > 0) {
            Toast.makeText(context, "Изменения внесены!", Toast.LENGTH_SHORT).show();
            return true;
        } else {
            Toast.makeText(context, "Что-то пошло не так при изменении данных!",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
    }
    public List<Player> selectPlayersByIdTeam(@NotNull int id) throws Exception {
        List<Player> players = new ArrayList<>();

        Cursor cursor = mDb.rawQuery("SELECT * FROM players where idTeam=?",
                new String[]{String.valueOf(id)});
        cursor.moveToFirst();

        while (!cursor.isAfterLast()){
            players.add(new Player(cursor.getLong(0),
                        cursor.getLong(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getInt(5),
                        cursor.getString(6)));
                cursor.moveToNext();
        }
        if (cursor.getCount()==0){
            throw new Exception("По данному idTeam = "+id+" не найдены игроки");
        }
        return players;
    }
    public Player selectPlayersById(@NotNull int id) throws Exception {

        Cursor cursor = mDb.rawQuery("SELECT * FROM players where id=?",
                new String[]{String.valueOf(id)});
        cursor.moveToFirst();

        if (cursor.getCount()>0){
            return new Player(cursor.getLong(0),
                    cursor.getLong(1),
                    cursor.getString(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getInt(5),
                    cursor.getString(6));
        }
        else{
            throw new Exception("По данному id = "+id+" не найден игрок");
        }
    }

    //Match
    public int addMatch(@NotNull ContentValues contentValues, @NotNull long idT1, @NotNull long idT2){

        mDb.delete("current_player", "idTeam !=? and idTeam !=?",
                new String[]{String.valueOf(idT1), String.valueOf(idT2)});
        mDb.delete("current_team", "id !=? and id !=?",
                new String[]{String.valueOf(idT1), String.valueOf(idT2)});

        contentValues.put("idUser", idUser);
        long count = mDb.insert("matches", null, contentValues);
        if (count<=0) throw new RuntimeException("Что-то пошло не так при создании матча");
        Cursor cursor = mDb.rawQuery("SELECT * FROM matches",null);
        cursor.moveToLast();
        return cursor.getInt(0);
    }
    public Match selectMatchById(@NotNull int idMatch) throws Exception {
        Cursor cursor = mDb.rawQuery("SELECT * FROM matches where id=?",
                new String[]{String.valueOf(idMatch)});
        cursor.moveToFirst();
        CurrentTeam team1 = selectCurTeamById(cursor.getInt(1));
        CurrentTeam team2 = selectCurTeamById(cursor.getInt(2));
        if (team1!=null && team2!=null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                return new Match(cursor.getLong(0), team1, team2,
                        cursor.getString(3), LocalDate.parse(cursor.getString(4)));
            }
        }
        throw new RuntimeException("Ванные о матче не найдены");
    }
    public boolean addDescMatch(@NotNull int id, @NotNull String desc) throws Exception {
        try {
            Cursor cursor = mDb.rawQuery("Update matches set description = ? where id=?",
                    new String[]{desc, String.valueOf(id)});
            return true;
        }catch (SQLException ex){
            throw new Exception("Описание матча не было добавлено");
        }
    }
    public List<Match> selectMatchesByIdUser() throws Exception {
        List<Match> matches = new ArrayList<Match>() ;
        Cursor cursor = mDb.rawQuery("SELECT * FROM matches where idUser=?",
                new String[]{String.valueOf(idUser)});
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            DateTimeFormatter formatter = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                formatter = DateTimeFormatter
                        .ofPattern("yyyy-MM-dd");
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                matches.add(new Match(cursor.getLong(0),
                        selectCurTeamById(cursor.getInt(1)),
                                selectCurTeamById(cursor.getInt(2)),
                                        cursor.getString(3),
                                        LocalDate.parse(cursor.getString(4), formatter)));
            }
            cursor.moveToNext();

        }
        if (matches==null)
            throw new Exception("Не найдены матчи");
        return matches;
    }

    //current team
    public void deleteAllCurTeam() throws Exception {
        List<CurrentTeam> list = selectAllCurTeamByIdUser();
        for (CurrentTeam curTeam: list) {
            long count = mDb.delete("current_player", "idTeam=?",
                    new String[]{String.valueOf(curTeam.getId())});
        }
        long i = idUser;
        List<Team> list1 = selectAllTeamByIdUser();
        for (Team team : list1){
            long count = mDb.delete("current_team", "idTeam=?",
                    new String[]{String.valueOf(team.getId())});
        }
    }
    public void addCurPlayer(@NotNull ContentValues cv, @NotNull int idTeam) throws Exception {
        cv.put("idTeam" , idTeam);
        long count = mDb.insert("current_player", null, cv);
        if (count>0) {
        }else throw new Exception("Что-то пошло не так при добавлении игрока в комсанду");

    }
    public void addCurrentTeam(@NotNull List<ContentValues> listPlayers, @NotNull ContentValues cvTeam, @NotNull int idTeam) throws Exception {
        Cursor cursor = mDb.rawQuery("SELECT * FROM current_team where idTeam =? ",
                new String[]{String.valueOf(idTeam)});
        cursor.moveToFirst();
        if (cursor.getCount()!=0){
            int i = cursor.getInt(0);
            mDb.delete("current_player", "idTeam =?",
                    new String[]{String.valueOf(i)});
            mDb.delete("current_team", "idTeam =?",new String[]{String.valueOf(idTeam)});
        }

        if (listPlayers.size()>=6&&listPlayers.size()<=14){

            long countTeam = mDb.insert("current_team", null, cvTeam);
            if (countTeam>0) {

                Toast.makeText(context, "Текущая Команда добавлена", Toast.LENGTH_SHORT).show();
                //добавляем игроков
                for (ContentValues cvPlayer: listPlayers) {
                    addCurPlayer(cvPlayer, selectIDCurTeam());
                    }

            } else throw new Exception("Что-то пошло не так при добавлении команды");

        } else  Toast.makeText(context, "Количество игроков либо меньше 6, либо больше 12!", Toast.LENGTH_SHORT).show();
    }
    public int selectIDCurTeam(){
        Cursor cursor = mDb.rawQuery("SELECT * FROM current_team ", null);
        cursor.moveToLast();
        return cursor.getInt(0);
    }
    public boolean selectCurPlayerByIdPlayer(@NotNull int idPlayer) throws Exception {
        Cursor cursor = mDb.rawQuery("SELECT * FROM current_player where idPlayer=?",
                new String[]{String.valueOf(idPlayer)});

        if (cursor.getCount()!=0)
            return true;
        else {
            return false;
        }
    }
    public List<CurrentPlayer> selectCurPlayerByIdCurTeam(@NotNull int idTeam) throws Exception {

        List<CurrentPlayer> players = new ArrayList<>();

        Cursor cursor = mDb.rawQuery("SELECT * FROM current_player where idTeam=?",
                new String[]{String.valueOf(idTeam)});
            cursor.moveToFirst();

            while (!cursor.isAfterLast()){
                players.add(new CurrentPlayer(selectPlayersById(cursor.getInt(2)), cursor.getString(3)));
                cursor.moveToNext();
            }

        return players;
    }
    public List<CurrentTeam> selectAllCurTeamByIdUser() throws Exception {
        List<CurrentTeam> cur_teams = new ArrayList<CurrentTeam>() ;

        List<Team> teams = selectAllTeamByIdUser();
        for (Team team : teams){

            Cursor cursor = mDb.rawQuery("SELECT * FROM current_team where idTeam= ?",
                    new String[]{String.valueOf(team.getId())});

            cursor.moveToFirst();
            while (!cursor.isAfterLast()){
                cur_teams.add(new CurrentTeam(
                        cursor.getInt(0),
                        selectTeambyId(cursor.getInt(1)),
                        cursor.getInt(5)
                ));
                cursor.moveToNext();
            }
        }



        return cur_teams;
    }
    public CurrentTeam selectCurTeamById(@NotNull int id) throws Exception {
        Cursor cursor = mDb.rawQuery("SELECT * FROM current_team where id=?",
                new String[]{String.valueOf(id)});
        cursor.moveToFirst();
        if (cursor.getCount()>0)
            return new CurrentTeam( cursor.getInt(0),
                    selectTeambyId(cursor.getInt(1)),
                    cursor.getInt(5));
        else {
            Toast.makeText(context, "По данному id = "+id+" не найдены данные о команде selectCurTeamById",
                    Toast.LENGTH_SHORT).show();
            return null;
        }
    }
    public CurrentTeam selectCurTeamByIdTeam(@NotNull int idTeam) throws Exception {
        Cursor cursor = mDb.rawQuery("SELECT * FROM current_team where idTeam=?",
                new String[]{String.valueOf(idTeam)});
        cursor.moveToFirst();
        if (cursor.getCount()>0)
            return new CurrentTeam(cursor.getInt(0), selectTeambyId(cursor.getInt(1)), cursor.getInt(5));
        else {
            return null;
        }
    }
    public void addCurPlayersByIdCurTeam(@NotNull int idTeam, @NotNull List<ContentValues> listPlayers) throws Exception {
        mDb.delete("current_player", "idTeam =?",
                new String[]{String.valueOf(idTeam)});
        for (ContentValues cv: listPlayers) {
            addCurPlayer(cv, idTeam);
        }

    }
    public void updateManagerCurTeam(@NotNull int id, @NotNull ContentValues idManager) throws Exception {
        int count = mDb.update("current_team", idManager, "id = ?",
                new String[]{String.valueOf(id)});
        if (count > 0) {
            Toast.makeText(context, "Изменения внесены!", Toast.LENGTH_SHORT).show();

        } else {
            throw new Exception("Что-то пошло не так при изменении представителя команды");

        }
    }


}

