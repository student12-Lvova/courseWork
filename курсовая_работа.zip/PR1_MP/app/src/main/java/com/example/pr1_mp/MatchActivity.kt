package com.example.pr1_mp

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.view.*
import android.widget.*
import android.widget.TableRow.LayoutParams
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.setMargins
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.models.CurrentMatch
import com.example.pr1_mp.models.CurrentPlayer
import com.example.pr1_mp.models.CurrentTeam
import com.example.pr1_mp.models.Match
import java.io.*


@Suppress("DEPRECATION")
class MatchActivity : AppCompatActivity() {
    private lateinit var tvComA: TextView
    private lateinit var tvComB: TextView
    private lateinit var tvScorePartTA: TextView
    private lateinit var tvScorePartTB: TextView
    private lateinit var btnMinusScoreTB: AppCompatButton
    private lateinit var btnReplacementTB: ImageButton
    private lateinit var btnTimeoutTB: AppCompatButton
    private lateinit var btnTimeoutTB2: AppCompatButton
    private lateinit var btnMinusScoreTA: AppCompatButton
    private lateinit var btnReplacementTA: ImageButton
    private lateinit var btnTimeoutTA: AppCompatButton
    private lateinit var btnTimeoutTA2: AppCompatButton
    private lateinit var btnScoreTA: AppCompatButton
    private lateinit var btnScoreTB: AppCompatButton
    private lateinit var ballTA: ImageView
    private lateinit var ballTB: ImageView
    private lateinit var timer: TextView
    private  lateinit var llPlacement:LinearLayout
    private lateinit var tvZona1:EditText
    private lateinit var tvZona2:EditText
    private lateinit var tvZona3:EditText
    private lateinit var tvZona4:EditText
    private lateinit var tvZona5:EditText
    private lateinit var tvZona6:EditText
    private lateinit var tvZonaB1:EditText
    private lateinit var tvZonaB2:EditText
    private lateinit var tvZonaB3:EditText
    private lateinit var tvZonaB4:EditText
    private lateinit var tvZonaB5:EditText
    private lateinit var tvZonaB6:EditText
    private lateinit var btnCanselReplace:AppCompatButton
    private lateinit var btnReplace:AppCompatButton
    private lateinit var btnStartLineUp:AppCompatButton

    private var startLineUpT1:MutableList<String> = listOf<String>().toMutableList()
    private var startLineUpT2:MutableList<String> = listOf<String>().toMutableList()
    private var tecLineUpT1:MutableList<String> = listOf<String>().toMutableList()
    private var tecLineUpT2:MutableList<String> = listOf<String>().toMutableList()

    private lateinit var workDB: WorkMyDB
    private var  recordProtocole:Boolean = false

    private lateinit var match: Match
    private lateinit var curTeam1:CurrentTeam
    private lateinit var curTeam2:CurrentTeam
    private var sourceA:Int = 0
    private var sourceB:Int = 0
    private var sourcePartA:Int = 0
    private var sourcePartB:Int = 0
    private lateinit var listBall:MutableList<String>
    private var listStatistics = listOf<MutableList<String>>().toMutableList()
    private var whoseBall:String = ""
    private var numPart =1;
    private var listRezultParts = listOf<String>().toMutableList()
    private lateinit var curMatch:CurrentMatch
    private lateinit var curPlTeam1:MutableList<CurrentPlayer>
    private lateinit var numCurPlT1:MutableList<String>
    private lateinit var curPlTeam2:MutableList<CurrentPlayer>
    private lateinit var numCurPlT2:MutableList<String>
    private var whoseReplace:String = ""

    private var flagTimeOutT1_1 = false
    private var flagTimeOutT1_2 = false
    private var flagTimeOutT2_1 = false
    private var flagTimeOutT2_2 = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_match)

        workDB = WorkMyDB(this)

        val extras = intent.extras
        if (extras != null && extras.getInt("idMatch")>0) {
            var idMatch = extras.getInt("idMatch")
            match = workDB.selectMatchById(idMatch)
            curMatch = CurrentMatch(idMatch, extras.getBoolean("placement"),
                extras.getBoolean("protocol"))
        }else{
            Toast.makeText(this, "Проблемы с созданием матча!", Toast.LENGTH_SHORT)
                .show()
            val intent = Intent(this@MatchActivity, CreateMatchActivity::class.java)
            startActivity(intent)
        }

        curTeam1 = workDB.selectCurTeamById(match.team1.id.toInt())
        curTeam2 = workDB.selectCurTeamById(match.team2.id.toInt())

        if (curMatch.isPlacement){
            AlertDialog.Builder(this)
                .setTitle("Стратовый состав!")
                .setMessage(
                    "Перед началом матча заполните стартовые составы коменд по номерам игроков!"
                )
                .setPositiveButton(
                    "Хорошо"
                ) { dialog, id -> dialog.cancel()}
                .show()
        }
        initFields()
        lisener()
        checkReceivedData()

        listBall = listOf<String>().toMutableList()
        timer.text = "00:00"
    }
    private fun initFields() {
        //названия команд
        tvComA = findViewById(R.id.tvTeamA)
        tvComB = findViewById(R.id.tvTeamB)

        tvScorePartTA = findViewById(R.id.tvScorePartTAM)
        tvScorePartTB = findViewById(R.id.tvScorePartTBM)

        //кнопки
        btnMinusScoreTB = findViewById(R.id.btnMinusScoreTB)
        btnTimeoutTB = findViewById(R.id.btnTimeoutTB)
        btnTimeoutTB2 = findViewById(R.id.btnTimeoutTB2)
        btnMinusScoreTA = findViewById(R.id.btnMinusScoreTA)
        btnTimeoutTA = findViewById(R.id.btnTimeoutTA)
        btnTimeoutTA2 = findViewById(R.id.btnTimeoutTA2)
        btnScoreTA = findViewById(R.id.b_source_com_aM)
        btnScoreTB = findViewById(R.id.b_source_com_bM)
        ballTA = findViewById(R.id.iv_ballM)
        ballTB = findViewById(R.id.iv_ball1M)
        ballTA.visibility = View.INVISIBLE
        ballTB.visibility = View.INVISIBLE
        timer = findViewById(R.id.chronometerMatchM)

        //замены
        btnReplacementTB = findViewById(R.id.btnReplacementTB)
        btnReplacementTA = findViewById(R.id.btnReplacementTA)
        tvZona1 = findViewById(R.id.tvZona1)
        tvZona2 = findViewById(R.id.tvZona2)
        tvZona3 = findViewById(R.id.tvZona3)
        tvZona4 = findViewById(R.id.tvZona4)
        tvZona5 = findViewById(R.id.tvZona5)
        tvZona6 = findViewById(R.id.tvZona6)
        tvZonaB1 = findViewById(R.id.tvZonaB1)
        tvZonaB2 = findViewById(R.id.tvZonaB2)
        tvZonaB3 = findViewById(R.id.tvZonaB3)
        tvZonaB4 = findViewById(R.id.tvZonaB4)
        tvZonaB5 = findViewById(R.id.tvZonaB5)
        tvZonaB6 = findViewById(R.id.tvZonaB6)
        btnCanselReplace = findViewById(R.id.btnCanselReplace)
        btnCanselReplace.visibility = View.VISIBLE
        btnReplace = findViewById(R.id.btnEndTimeForReplace)
        btnReplace.visibility = View.GONE
        btnStartLineUp = findViewById(R.id.btnStartLineUp)
        btnStartLineUp.visibility = View.GONE

        llPlacement = findViewById(R.id.llPlacement)
            if (curMatch.isPlacement) {
                allBtn(false)

                curPlTeam1 = listOf<CurrentPlayer>().toMutableList()
                curPlTeam2 = listOf<CurrentPlayer>().toMutableList()
                numCurPlT1 = listOf<String>().toMutableList()
                numCurPlT2 = listOf<String>().toMutableList()

                curPlTeam1 = workDB.selectCurPlayerByIdCurTeam(curTeam1.id)
                for (pl in curPlTeam1) {
                    numCurPlT1.add(pl.player.numPlayer.toString())
                }
                curPlTeam2 = workDB.selectCurPlayerByIdCurTeam(curTeam2.id)
                for (pl in curPlTeam2) {
                    numCurPlT2.add(pl.player.numPlayer.toString())
                }

                btnStartLineUp.visibility = View.VISIBLE
        }
        else {
                curPlTeam1 = workDB.selectCurPlayerByIdCurTeam(curTeam1.id)
                curPlTeam2 = workDB.selectCurPlayerByIdCurTeam(curTeam2.id)
            btnCanselReplace.visibility = View.GONE
            llPlacement.visibility = View.GONE
            btnReplacementTA.visibility = View.GONE
            btnReplacementTB.visibility = View.GONE
        }

        //Стартовый состав

    }
    private fun lisener() {
        tvComA.text = match.team1.team.name
        tvComB.text = match.team2.team.name
        tvScorePartTA.text = "0"
        tvScorePartTB.text = "0"

        //счетчики очков
        btnScoreTA.setOnClickListener{
            sourceA += 1;
            listBall.add(tvComA.text.toString())
            if (sourceA==1 && numPart==1 && whoseBall=="")
                whoseBall = tvComA.text.toString()
            btnScoreTA.text = sourceA.toString();
            ballTA.visibility = View.VISIBLE
            ballTB.visibility = View.INVISIBLE
            if(!endParty()&&curMatch.isPlacement&&listBall.count()>1) {
                if (listBall.isNotEmpty() && listBall[listBall.size - 2] != tvComA.text.toString()) {
                    plMoveForwardTeam1()
                }
            }


        }
        btnScoreTB.setOnClickListener{
            sourceB+=1;
            listBall.add(tvComB.text.toString())
            if (sourceB==1 && numPart==1 && whoseBall=="")
                whoseBall = tvComB.text.toString()
            btnScoreTB.setText(sourceB.toString());
            ballTB.visibility = View.VISIBLE
            ballTA.visibility = View.INVISIBLE
            if(!endParty()&&curMatch.isPlacement&&listBall.count()>1) {
                if (listBall.isNotEmpty() && listBall[listBall.size - 2] != tvComB.text.toString()) {
                    plMoveForwardTeam2()
                }
            }
        }
        btnMinusScoreTA.setOnClickListener{
            if(sourceA!=0)  sourceA-=1;
            else sourceA=0
            if (listBall.isNotEmpty()){
                listBall.removeAt(listBall.size-1)
                if (listBall.isNotEmpty()&&listBall[listBall.size-1] == tvComA.text.toString()){
                    ballTA.visibility = View.VISIBLE
                    ballTB.visibility = View.INVISIBLE

                }else{
                    ballTB.visibility = View.VISIBLE
                    ballTA.visibility = View.INVISIBLE
                    if(curMatch.isPlacement)
                        plMoveBackTeam1()
                }
            }

            btnScoreTA.setText(sourceA.toString())
            endParty()
        }
        btnMinusScoreTB.setOnClickListener{
            if(sourceB!=0) sourceB-=1;
            else sourceB=0
            if (listBall.isNotEmpty()){
                listBall.removeAt(listBall.size-1)
                if (listBall.isNotEmpty()&&listBall[listBall.size-1] == tvComA.text.toString()){
                    ballTA.visibility = View.VISIBLE
                    ballTB.visibility = View.INVISIBLE
                    if(curMatch.isPlacement)
                        plMoveBackTeam2()
                }else{
                    ballTB.visibility = View.VISIBLE
                    ballTA.visibility = View.INVISIBLE

                }
            }
            btnScoreTB.setText(sourceB.toString())
            endParty()
        }

        //таймауты
        btnTimeoutTB.setOnClickListener{
            btnTimeoutTB.isEnabled = false
            curTeam2.countTimeOut++
            btnTimeoutTB.setTextColor(Color.BLACK);
            flagTimeOutT2_1 = true

            startTimeOut()
        }
        btnTimeoutTB2.setOnClickListener{
            btnTimeoutTB2.isEnabled = false
            curTeam2.countTimeOut++
            btnTimeoutTB2.setTextColor(Color.BLACK);
            flagTimeOutT2_2 = true
            startTimeOut()
        }
        btnTimeoutTA.setOnClickListener{
            btnTimeoutTA.isEnabled = false
            curTeam1.countTimeOut++
            btnTimeoutTA.setTextColor(Color.BLACK);
            flagTimeOutT1_1 = true
            startTimeOut()
        }
        btnTimeoutTA2.setOnClickListener{
            btnTimeoutTA2.isEnabled = false
            curTeam1.countTimeOut++
            btnTimeoutTA2.setTextColor(Color.BLACK)
            flagTimeOutT1_2 = true
            startTimeOut()

        }

        //замены
        btnReplacementTA.setOnClickListener{
            if (curTeam1.countReplacement<6){
                llPlacement.visibility = View.VISIBLE

                whoseReplace = curTeam1.team.name

                allBtn(false)
                btnReplace.isEnabled = true

                tvZona1.isEnabled = true
                tvZona2.isEnabled = true
                tvZona3.isEnabled = true
                tvZona4.isEnabled = true
                tvZona5.isEnabled = true
                tvZona6.isEnabled = true

                tecLineUpT1 = startLineUpT1
                btnCanselReplace.visibility = View.VISIBLE
                btnReplace.visibility = View.VISIBLE
            }
            else
                Toast.makeText(this, "У команды ${curTeam1.team.name} закончились замены!", Toast.LENGTH_SHORT)
                    .show()


        }
        btnReplacementTB.setOnClickListener{
            if (curTeam2.countReplacement<6){
                llPlacement.visibility = View.VISIBLE

                allBtn(false)
                btnReplace.isEnabled = true

                whoseReplace = curTeam2.team.name

                tvZonaB1.isEnabled = true
                tvZonaB2.isEnabled = true
                tvZonaB3.isEnabled = true
                tvZonaB4.isEnabled = true
                tvZonaB5.isEnabled = true
                tvZonaB6.isEnabled = true

                tecLineUpT2 = startLineUpT2

                btnCanselReplace.visibility = View.VISIBLE
                btnReplace.visibility = View.VISIBLE
            }
            else
                Toast.makeText(this, "У команды ${curTeam2.team.name} закончились замены!", Toast.LENGTH_SHORT)
                    .show()
        }
        btnCanselReplace.setOnClickListener{
            btnReplace.visibility = View.GONE
            btnCanselReplace.visibility = View.GONE

            tvZona1.setText(startLineUpT1[0])
            tvZona2.setText(startLineUpT1[1])
            tvZona3.setText(startLineUpT1[2])
            tvZona4.setText(startLineUpT1[3])
            tvZona5.setText(startLineUpT1[4])
            tvZona6.setText(startLineUpT1[5])

            tvZonaB1.setText(startLineUpT2[0])
            tvZonaB2.setText(startLineUpT2[1])
            tvZonaB3.setText(startLineUpT2[2])
            tvZonaB4.setText(startLineUpT2[3])
            tvZonaB5.setText(startLineUpT2[4])
            tvZonaB6.setText(startLineUpT2[5])

            allBtn(true)
            zoneActive(false)
        }
        btnReplace.setOnClickListener {
            var listReplace: MutableList<String>
            var indexReplace=0;
            if(tvZonaB1.isEnabled){
                listReplace = listOf<String>().toMutableList()
                listReplace.add(tvZonaB1.text.toString())
                listReplace.add(tvZonaB2.text.toString())
                listReplace.add(tvZonaB3.text.toString())
                listReplace.add(tvZonaB4.text.toString())
                listReplace.add(tvZonaB5.text.toString())
                listReplace.add(tvZonaB6.text.toString())

                indexReplace=0;
                for (pl in listReplace.withIndex()){
                    if (pl.value!=tecLineUpT2.elementAt(pl.index))
                        indexReplace = pl.index+1
                }
                when(indexReplace){
                    1->{
                        if (tecLineUpT2.contains(tvZonaB1.text.toString())
                            || !numCurPlT2.contains(tvZonaB1.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam2.team.name} не соответствие номера игрока " +
                                        "в 1 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam2.countReplacement++
                            startLineUpT2.add(0,tvZonaB1.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                    2->{
                        if (tecLineUpT2.contains(tvZonaB2.text.toString())
                            || !numCurPlT2.contains(tvZonaB2.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam2.team.name} не соответствие номера игрока " +
                                        "в 2 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam2.countReplacement++
                            startLineUpT2.add(1,tvZonaB2.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                    3->{
                        if (tecLineUpT2.contains(tvZonaB3.text.toString())
                            || !numCurPlT2.contains(tvZonaB3.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam2.team.name} не соответствие номера игрока " +
                                        "в 3 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam2.countReplacement++
                            startLineUpT2.add(2,tvZonaB3.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                    4->{
                        if (tecLineUpT2.contains(tvZonaB4.text.toString())
                            || !numCurPlT2.contains(tvZonaB4.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam2.team.name} не соответствие номера игрока " +
                                        "в 4 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam2.countReplacement++
                            startLineUpT2.add(3,tvZonaB4.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                    5->{
                        if (tecLineUpT2.contains(tvZonaB5.text.toString())
                            || !numCurPlT2.contains(tvZonaB5.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam2.team.name} не соответствие номера игрока " +
                                        "в 5 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam2.countReplacement++
                            startLineUpT2.add(4,tvZonaB5.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                    6->{
                        if (tecLineUpT2.contains(tvZonaB6.text.toString())
                            || !numCurPlT2.contains(tvZonaB6.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam2.team.name} не соответствие номера игрока " +
                                        "в 6 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam2.countReplacement++
                            startLineUpT2.add(5,tvZonaB6.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                }
            }
            if (tvZona1.isEnabled){
                listReplace = listOf<String>().toMutableList()
                listReplace.add(tvZona1.text.toString())
                listReplace.add(tvZona2.text.toString())
                listReplace.add(tvZona3.text.toString())
                listReplace.add(tvZona4.text.toString())
                listReplace.add(tvZona5.text.toString())
                listReplace.add(tvZona6.text.toString())

                indexReplace=0;
                for ((index, value) in listReplace.withIndex()){
                    if (value!=tecLineUpT1.elementAt(index))
                        indexReplace = index
                }
                when(indexReplace){
                    1->{
                        if (tecLineUpT1.contains(tvZona1.text.toString())
                            || !numCurPlT1.contains(tvZona1.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam1.team.name} не соответствие номера игрока " +
                                        "в 1 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam1.countReplacement++
                            startLineUpT1.add(0,tvZona1.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                    2->{
                        if (tecLineUpT1.contains(tvZona2.text.toString())
                            || !numCurPlT1.contains(tvZona2.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam1.team.name} не соответствие номера игрока " +
                                        "в 2 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam1.countReplacement++
                            startLineUpT1.add(1,tvZona2.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                    3->{
                        if (tecLineUpT1.contains(tvZona3.text.toString())
                            || !numCurPlT1.contains(tvZona3.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam1.team.name} не соответствие номера игрока " +
                                        "в 3 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam1.countReplacement++
                            startLineUpT1.add(2,tvZona3.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                    4->{
                        if (tecLineUpT1.contains(tvZona4.text.toString())
                            || !numCurPlT1.contains(tvZona4.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam1.team.name} не соответствие номера игрока " +
                                        "в 4 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam1.countReplacement++
                            startLineUpT1.add(3,tvZona4.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                    5->{
                        if (tecLineUpT1.contains(tvZona5.text.toString())
                            || !numCurPlT2.contains(tvZona5.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam1.team.name} не соответствие номера игрока " +
                                        "в 5 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam1.countReplacement++
                            startLineUpT1.add(4,tvZona5.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                    6->{
                        if (tecLineUpT1.contains(tvZona6.text.toString())
                            || !numCurPlT1.contains(tvZona6.text.toString()))
                            Toast.makeText(this,
                                "У команды ${curTeam1.team.name} не соответствие номера игрока " +
                                        "в 6 зоне!", Toast.LENGTH_SHORT).show()
                        else{
                            curTeam1.countReplacement++
                            startLineUpT1.add(5,tvZona6.text.toString())
                            zoneActive(false)
                            allBtn(true)
                        }
                    }
                }
            }
        }
        //Стартовый состав
        btnStartLineUp.setOnClickListener {

            startLineUpT1= listOf<String>().toMutableList()
            startLineUpT2= listOf<String>().toMutableList()

            var zona1 = tvZona1.text.toString()
            var zona2 = tvZona2.text.toString()
            var zona3 = tvZona3.text.toString()
            var zona4 = tvZona4.text.toString()
            var zona5 = tvZona5.text.toString()
            var zona6 = tvZona6.text.toString()

            if (numCurPlT1.contains(zona1)) {
                startLineUpT1.add(zona1)
                if (numCurPlT1.contains(zona2) &&
                    !startLineUpT1.contains(zona2)
                ) {
                    startLineUpT1.add(zona2)
                    if (numCurPlT1.contains(zona3) &&
                        !startLineUpT1.contains(zona3)
                    ) {
                        startLineUpT1.add(zona3)
                        if (numCurPlT1.contains(zona4) &&
                            !startLineUpT1.contains(zona4)
                        ) {
                            startLineUpT1.add(zona4)
                            if (numCurPlT1.contains(zona5) &&
                                !startLineUpT1.contains(zona5)
                            ) {
                                startLineUpT1.add(zona5)
                                if (numCurPlT1.contains(zona6) &&
                                    !startLineUpT1.contains(zona6)
                                ) {
                                    startLineUpT1.add(zona6)
                                }
                            }
                        }
                    }
                }
            } else
                Toast.makeText(
                    this,
                    "У команды ${curTeam1.team.name} не соответствуют номера!",
                    Toast.LENGTH_SHORT
                )
                    .show()

            zona1 = tvZonaB1.text.toString()
            zona2 = tvZonaB2.text.toString()
            zona3 = tvZonaB3.text.toString()
            zona4 = tvZonaB4.text.toString()
            zona5 = tvZonaB5.text.toString()
            zona6 = tvZonaB6.text.toString()

            if (numCurPlT2.contains(zona1)) {
                startLineUpT2.add(zona1)
                if (numCurPlT2.contains(zona2) &&
                    !startLineUpT2.contains(zona2)
                ) {
                    startLineUpT2.add(zona2)
                    if (numCurPlT2.contains(zona3) &&
                        !startLineUpT2.contains(zona3)
                    ) {
                        startLineUpT2.add(zona3)
                        if (numCurPlT2.contains(zona4) &&
                            !startLineUpT2.contains(zona4)
                        ) {
                            startLineUpT2.add(zona4)
                            if (numCurPlT2.contains(zona5) &&
                                !startLineUpT2.contains(zona5)
                            ) {
                                startLineUpT2.add(zona5)
                                if (numCurPlT2.contains(zona6) &&
                                    !startLineUpT2.contains(zona6)
                                ) {
                                    startLineUpT2.add(zona6)
                                }
                            }
                        }
                    }
                }
            }

            if (startLineUpT1.count()==6&&startLineUpT2.count()==6){
                allBtn(true)
                btnStartLineUp.visibility = View.GONE
                zoneActive(false)

            }
            else{
                if (startLineUpT1.count()!=6)
                    Toast.makeText(
                        this,
                        "У команды ${curTeam1.team.name} не соответствуют номера!",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                if (startLineUpT2.count()!=6)
                    Toast.makeText(
                        this,
                        "У команды ${curTeam2.team.name} не соответствуют номера!",
                        Toast.LENGTH_SHORT
                    )
                        .show()
            }


        }

    }
    private fun startTimeOut()  {
        allBtn(false)
        var second = 60;
        while (second>0){

            second--;
        }
        val timer = object: CountDownTimer(60000, 1000) {//минута
        override fun onTick(p0: Long) {
            var p = p0 / 1000
            if (p>=10)
                timer.text = "00:$p"
            else
                timer.text = "00:0$p"
        }
            override fun onFinish() {

                allBtn(true)
                timer.text = "00:00"

                if (flagTimeOutT1_1)
                    btnTimeoutTA.isEnabled = false
                if (flagTimeOutT1_2)
                    btnTimeoutTA2.isEnabled = false
                if (flagTimeOutT2_1)
                    btnTimeoutTB.isEnabled = false
                if (flagTimeOutT2_2)
                    btnTimeoutTB2.isEnabled = false
            }
        }
        timer.start();
    }
    private fun checkReceivedData() {
        llPlacement =findViewById(R.id.llPlacement)
        //данные по матчу
        if (!curMatch.isPlacement){
            llPlacement.visibility = View.GONE
            btnReplacementTA.visibility = View.GONE
            btnReplacementTB.visibility = View.GONE
        }
        else{
            llPlacement.visibility = View.VISIBLE
            btnReplacementTA.visibility = View.VISIBLE
            btnReplacementTB.visibility = View.VISIBLE
        }

        recordProtocole=curMatch.isProtocol

    }

    private fun zoneActive(flag: Boolean) {

        tvZona1.isEnabled = flag
        tvZona2.isEnabled = flag
        tvZona3.isEnabled = flag
        tvZona4.isEnabled = flag
        tvZona5.isEnabled = flag
        tvZona6.isEnabled = flag
        tvZonaB1.isEnabled = flag
        tvZonaB2.isEnabled = flag
        tvZonaB3.isEnabled = flag
        tvZonaB4.isEnabled = flag
        tvZonaB5.isEnabled = flag
        tvZonaB6.isEnabled = flag

        btnCanselReplace.visibility=View.GONE
        btnReplace.visibility=View.GONE
        btnStartLineUp.visibility=View.GONE
    }
    private fun allBtn(flag:Boolean){
        tvScorePartTA.text = sourcePartA.toString()
        tvScorePartTB.text = sourcePartB.toString()

        btnMinusScoreTB.isEnabled = flag
        btnTimeoutTB.isEnabled = flag
        btnTimeoutTB2.isEnabled = flag
        btnMinusScoreTA.isEnabled = flag
        btnTimeoutTA.isEnabled = flag
        btnTimeoutTA2.isEnabled = flag
        btnScoreTA.isEnabled = flag
        btnScoreTB.isEnabled = flag
        ballTA.isEnabled = flag
        ballTB.isEnabled = flag
        //замены
        btnReplacementTB.isEnabled = flag
        btnReplacementTA.isEnabled = flag
        btnReplace.visibility = View.GONE
        btnCanselReplace.visibility = View.GONE
    }

    private fun plMoveForwardTeam1(){

        var num = tvZona1.text
        tvZona1.text = tvZona2.text
        tvZona2.text = tvZona3.text
        tvZona3.text = tvZona4.text
        tvZona4.text = tvZona5.text
        tvZona5.text = tvZona6.text
        tvZona6.text = num
    }
    private fun plMoveForwardTeam2(){

        var num = tvZonaB1.text
        tvZonaB1.text = tvZonaB2.text
        tvZonaB2.text = tvZonaB3.text
        tvZonaB3.text = tvZonaB4.text
        tvZonaB4.text = tvZonaB5.text
        tvZonaB5.text = tvZonaB6.text
        tvZonaB6.text = num
    }
    private fun plMoveBackTeam1(){
        var num = tvZona1.text
        tvZona1.text = tvZona6.text
        tvZona6.text = tvZona5.text
        tvZona5.text = tvZona4.text
        tvZona4.text = tvZona3.text
        tvZona3.text = tvZona2.text
        tvZona2.text = num
    }
    private fun plMoveBackTeam2(){
        var num = tvZonaB1.text

        tvZonaB1.text = tvZonaB6.text
        tvZonaB6.text = tvZonaB5.text
        tvZonaB5.text = tvZonaB4.text
        tvZonaB4.text = tvZonaB3.text
        tvZonaB3.text = tvZonaB2.text
        tvZonaB2.text = num
    }

    fun startTimer(){

        allBtn(false)
        var second = 60;
        while (second>0){
            second--;
        }
        val timer = object: CountDownTimer(3000, 1000) {//минута
        override fun onTick(p0: Long) {
            var p = p0 / 1000
            if (p>=10)
                timer.text = "00:$p"
            else
                timer.text = "00:0$p"
        }
            override fun onFinish() {
                sourceA=0
                sourceB=0
                timer.text = "00:00"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
                    changeOfSides()
                }
                if(curMatch.isPlacement){
                    allBtn(false)
                    zoneActive(true)
                    btnStartLineUp.visibility = View.VISIBLE
                }
                else
                    allBtn(true)

                    curTeam1.countTimeOut = 0
                    curTeam1.countReplacement = 0
                    curTeam2.countTimeOut = 0
                    curTeam1.countReplacement = 0

                btnTimeoutTA.setTextColor(Color.WHITE)
                btnTimeoutTA2.setTextColor(Color.WHITE)
                btnTimeoutTB.setTextColor(Color.WHITE)
                btnTimeoutTB2.setTextColor(Color.WHITE)

                listStatistics.add(listBall)
                listBall= listOf<String>().toMutableList()
                lisener()

                tvScorePartTA.text = sourcePartA.toString()
                tvScorePartTB.text = sourcePartB.toString()

            }
        }
        timer.start();
    }
    private fun endParty():Boolean {
        if (!numPart.equals(5)&&((sourceA==25&&sourceB<=23) || (sourceA>=25 && sourceA-sourceB==2))) {
            sourcePartA++

            if (sourcePartA==3&&sourcePartB<=1){
                allBtn(false)
                endMatch(match.team1.team.name, "$sourceA:$sourceB")
            }
            if (sourcePartA==3&&sourcePartB<=1){
                allBtn(false)
                endMatch(match.team1.team.name, "$sourceA:$sourceB")
            }

            listRezultParts.add("$numPart партия закончилась с результатом $sourceA:$sourceB" +
                    " в пользу команды ${curTeam1.team.name}  ")
            numPart++
            startTimer()


            return true
        }
        if(!numPart.equals(5) && ((sourceB==25&&sourceA<=23) || (sourceB>=25 && sourceB-sourceA==2))){

            sourcePartB++

            if (sourcePartB==3&&sourcePartA<=1){
                allBtn(false)
                endMatch(match.team2.team.name, "$sourcePartB:$sourcePartA")
            }

            listRezultParts.add("$numPart партия закончилась с результатом $sourceA:$sourceB" +
                    "в пользу команды ${curTeam2.team.name}  ")
            numPart++
            startTimer()
            return true

        }
        if (numPart.equals(5)){
            if (sourceA==8 || sourceB==8) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
                    numPart=6
                    changeOfSides()
                    numPart=5
                }
                btnScoreTA.text = sourceA.toString()
                btnScoreTB.text = sourceB.toString()
                tvScorePartTA.text = sourcePartA.toString()
                tvScorePartTB.text = sourcePartB.toString()
            }
            if((sourceB==15&&sourceA<=13) || (sourceB>15 && sourceB-sourceA==2)){

                sourcePartB++

                tvScorePartTB.text = sourcePartB.toString()
                allBtn(false)
                listRezultParts.add("$numPart партия закончилась с результатом $sourceA:$sourceB" +
                        " в пользу команды ${curTeam2.team.name}  ")
                endMatch(match.team2.team.name, "$sourcePartB:$sourcePartA")

            }
            if((sourceA==15&&sourceB<=13) || (sourceA>15 && sourceB-sourceA==2)){

                sourcePartA++

                allBtn(false)
                listRezultParts.add("$numPart партия закончилась с результатом $sourceA:$sourceB" +
                        " в пользу команды ${curTeam1.team.name}  ")
                endMatch(match.team1.team.name, "$sourcePartA:$sourcePartB")

            }

        }

        return false
    }
    @RequiresApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
    fun changeOfSides(){

        setContentView(R.layout.activity_match);

        var linearLayout = findViewById<LinearLayout>(R.id.llTextView)
        var dvoet = findViewById<TextView>(R.id.textView20M)
        linearLayout.removeAllViews()

        var llTimer = findViewById<LinearLayout>(R.id.llTimer)
        removeView(timer)
        llTimer.removeAllViews()
        llTimer.addView(timer)

        var rlHelpButton = findViewById<RelativeLayout>(R.id.llOptions)
        var llHB1 = findViewById<LinearLayout>(R.id.llHelpBtn1)
        var llHB2 = findViewById<LinearLayout>(R.id.llHelpBtn2)
        llHB1.removeAllViews()
        llHB2.removeAllViews()
        rlHelpButton.removeAllViews()

        var ll_forBtnPlus = findViewById<LinearLayout>(R.id.ll_forButton)
        ll_forBtnPlus.removeAllViews()

        var llPlacement = findViewById<LinearLayout>(R.id.llPlacement)
        var glTeamA = findViewById<androidx.gridlayout.widget.GridLayout>(R.id.glTeamA)
        var iv = findViewById<ImageView>(R.id.imageView15)
        var glTeamB = findViewById<androidx.gridlayout.widget.GridLayout>(R.id.glTeamB)

        removeView(tvComB)
        removeView(tvScorePartTB)
        removeView(dvoet)
        removeView(tvScorePartTA)
        removeView(tvComA)

        removeView(btnMinusScoreTA)
        removeView(btnReplacementTA)
        removeView(btnTimeoutTA)
        removeView(btnTimeoutTA2)

        removeView(btnMinusScoreTB)
        removeView(btnReplacementTB)
        removeView(btnTimeoutTB)
        removeView(btnTimeoutTB2)

        removeView(llHB1)
        removeView(llHB2)

        removeView(btnScoreTB)
        removeView(ballTB)
        removeView(ballTA)
        removeView(btnScoreTA)

        llPlacement.removeAllViews()
        removeView(glTeamA)
        removeView(glTeamB)
        removeView(iv)

        //номер партии 1,3
        if (numPart%2!=0){
            linearLayout.addView(tvComA)
            linearLayout.addView(tvScorePartTA)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                tvScorePartTA.textAlignment = TextView.TEXT_ALIGNMENT_TEXT_END
            }
            linearLayout.addView(dvoet)
            linearLayout.addView(tvScorePartTB)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                tvScorePartTB.textAlignment = TextView.TEXT_ALIGNMENT_TEXT_START
            }
            tvScorePartTB.text = sourcePartB.toString()
            linearLayout.addView(tvComB)

            llHB1.addView(btnMinusScoreTA)
            if (curMatch.isPlacement)
                llHB1.addView(btnReplacementTA)
            llHB1.addView(btnTimeoutTA)
            llHB1.addView(btnTimeoutTA2)
            llHB2.addView(btnTimeoutTB)
            llHB2.addView(btnTimeoutTB2)
            if (curMatch.isPlacement)
                llHB2.addView(btnReplacementTB)
            llHB2.addView(btnMinusScoreTB)
            rlHelpButton.addView(llHB1)
            rlHelpButton.addView(llHB2)

            ll_forBtnPlus.addView(btnScoreTA)
            btnScoreTA.text = sourceA.toString()
            ll_forBtnPlus.addView(ballTA)
            ll_forBtnPlus.addView(ballTB)
            ll_forBtnPlus.addView(btnScoreTB)
            btnScoreTB.text = sourceB.toString()

            if (curMatch.isPlacement){
                var pglTeamA = glTeamA.layoutParams
                var pglTeamB = glTeamB.layoutParams

                llPlacement.visibility = View.VISIBLE
                glTeamA.removeAllViews()
                removeView(tvZona5)
                removeView(tvZona1)
                removeView(tvZona2)
                removeView(tvZona3)
                removeView(tvZona4)
                removeView(tvZona6)

                glTeamA.columnCount=2
                glTeamA.rowCount = 3

                tvZona5.layoutParams = paramsEditText(0,0)
                glTeamA.addView(tvZona5)
                tvZona4.layoutParams = paramsEditText(0,1)
                tvZona4.width = 60
                tvZona4.height = 60
                glTeamA.addView(tvZona4)
                tvZona3.layoutParams = paramsEditText(1,1)
                glTeamA.addView(tvZona3)
                tvZona6.layoutParams = paramsEditText(1,0)
                glTeamA.addView(tvZona6)
                tvZona2.layoutParams = paramsEditText(2,1)
                glTeamA.addView(tvZona2)
                tvZona1.layoutParams = paramsEditText(2,0)
                glTeamA.addView(tvZona1)

                glTeamB.removeAllViews()
                removeView(tvZonaB2)
                removeView(tvZonaB1)
                removeView(tvZonaB5)
                removeView(tvZonaB3)
                removeView(tvZonaB4)
                removeView(tvZonaB6)

                tvZonaB2.layoutParams = paramsEditText(0,0)
                glTeamB.addView(tvZonaB2)
                tvZonaB1.layoutParams = paramsEditText(0,1)
                glTeamB.addView(tvZonaB1)
                tvZonaB6.layoutParams = paramsEditText(1,1)
                glTeamB.addView(tvZonaB6)
                tvZonaB3.layoutParams = paramsEditText(1,0)
                glTeamB.addView(tvZonaB3)
                tvZonaB5.layoutParams = paramsEditText(2,1)
                glTeamB.addView(tvZonaB5)
                tvZonaB4.layoutParams = paramsEditText(2,0)
                glTeamB.addView(tvZonaB4)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
                    llPlacement.removeAllViews()
                    removeView(glTeamA)
                    removeView(iv)
                    removeView(glTeamB)

                    llPlacement.addView(glTeamA)
                    glTeamA.layoutParams = pglTeamA
                    llPlacement.addView(iv)
                    llPlacement.addView(glTeamB)
                    glTeamB.layoutParams = pglTeamB
                }


            }
            else{
                llPlacement.visibility = View.GONE
                btnReplacementTA.visibility = View.GONE
                btnReplacementTB.visibility = View.GONE
            }

        }
        else{
            linearLayout.addView(tvComB)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                tvScorePartTB.textAlignment = TextView.TEXT_ALIGNMENT_TEXT_END
            }

            linearLayout.addView(tvScorePartTB)
            tvScorePartTB.text = sourcePartB.toString()
            linearLayout.addView(dvoet)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                tvScorePartTA.textAlignment = TextView.TEXT_ALIGNMENT_TEXT_START
            }

            linearLayout.addView(tvScorePartTA)

            linearLayout.addView(tvComA)

            llHB1.addView(btnMinusScoreTB)
            if (curMatch.isPlacement)
                llHB1.addView(btnReplacementTB)
            llHB1.addView(btnTimeoutTB)
            llHB1.addView(btnTimeoutTB2)

            llHB2.addView(btnTimeoutTA)
            llHB2.addView(btnTimeoutTA2)
            if (curMatch.isPlacement)
                llHB2.addView(btnReplacementTA)
            llHB2.addView(btnMinusScoreTA)

            rlHelpButton.addView(llHB1)
            rlHelpButton.addView(llHB2)

            ll_forBtnPlus.removeAllViews()

            ll_forBtnPlus.addView(btnScoreTB)
            btnScoreTB.text = sourceB.toString()
            ll_forBtnPlus.addView(ballTB)
            ll_forBtnPlus.addView(ballTA)
            ll_forBtnPlus.addView(btnScoreTA)
            btnScoreTA.text = sourceA.toString()

            if (curMatch.isPlacement){

                llPlacement.visibility = View.VISIBLE
                var p4 = glTeamA.layoutParams
                glTeamA.layoutParams = glTeamB.layoutParams
                glTeamB.layoutParams = p4

                glTeamA.removeAllViews()
                removeView(tvZona2)
                removeView(tvZona1)
                removeView(tvZona6)
                removeView(tvZona3)
                removeView(tvZona5)
                removeView(tvZona4)


                glTeamA.columnCount = 2
                glTeamA.rowCount = 3

                tvZona2.layoutParams = paramsEditText(0,0)
                glTeamA.addView(tvZona2)
                tvZona1.layoutParams = paramsEditText(0,1)
                glTeamA.addView(tvZona1)
                tvZona6.layoutParams = paramsEditText(1,1)
                glTeamA.addView(tvZona6)
                tvZona3.layoutParams = paramsEditText(1,0)
                glTeamA.addView(tvZona3)
                tvZona5.layoutParams = paramsEditText(2,0)
                glTeamA.addView(tvZona5)
                tvZona4.layoutParams = paramsEditText(2,1)
                glTeamA.addView(tvZona4)

                glTeamB.removeAllViews()
                removeView(tvZonaB5)
                removeView(tvZonaB4)
                removeView(tvZonaB3)
                removeView(tvZonaB6)
                removeView(tvZonaB2)
                removeView(tvZonaB1)

                glTeamB.columnCount = 2
                glTeamB.rowCount = 3
                tvZonaB5.layoutParams = paramsEditText(0,0)
                glTeamB.addView(tvZonaB5)
                tvZonaB4.layoutParams = paramsEditText(0,1)
                glTeamB.addView(tvZonaB4)
                tvZonaB3.layoutParams = paramsEditText(1,0)
                glTeamB.addView(tvZonaB3)
                tvZonaB6.layoutParams = paramsEditText(1,1)
                glTeamB.addView(tvZonaB6)
                tvZonaB2.layoutParams = paramsEditText(2,0)
                glTeamB.addView(tvZonaB2)
                tvZonaB1.layoutParams = paramsEditText(2,1)
                glTeamB.addView(tvZonaB1)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
                    llPlacement.removeAllViews()
                    removeView(glTeamA)
                    removeView(glTeamB)
                    removeView(iv)


                    llPlacement.addView(glTeamB)
                    llPlacement.addView(iv)
                    llPlacement.addView(glTeamA)

                }
                var params = LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
                params.gravity = Gravity.CENTER
                params.topMargin = 50
                llPlacement.layoutParams = params


            }
            else{
                llPlacement.visibility = View.GONE
                btnReplacementTA.visibility = View.GONE
                btnReplacementTB.visibility = View.GONE
            }



        }

        if (whoseBall==tvComA.text.toString())
        {
            ballTA.visibility = View.VISIBLE
            ballTB.visibility = View.INVISIBLE
            whoseBall=tvComB.text.toString()
        }
        else{
            if (whoseBall==tvComB.text.toString())
            {
                ballTA.visibility = View.VISIBLE
                ballTB.visibility = View.INVISIBLE
                whoseBall=tvComA.text.toString()
            }
        }

        if(curMatch.isPlacement) {
            var ll = findViewById<LinearLayout>(R.id.linerLayout)
            ll.removeAllViews()

            removeView(btnCanselReplace)
            removeView(btnReplace)
            removeView(btnStartLineUp)
            ll.addView(btnCanselReplace)
            ll.addView(btnReplace)
            ll.addView(btnStartLineUp)
        }
        else{
            var ll = findViewById<LinearLayout>(R.id.linerLayout)
            ll.removeAllViews()
        }
    }
    private fun endMatch(nameTeamWin:String, rezultMatch: String) {
        listRezultParts.add("$numPart партия закончилась с результатом $sourcePartA:$sourcePartB" +
                " в пользу команды ${curTeam1.team.name}  ")

        if (curMatch.isProtocol) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                recordProtocole(rezultMatch)
            }
            AlertDialog.Builder(this)
                .setTitle("Матч закончислся!")
                .setMessage(
                    "Матч закончислся победой команды $nameTeamWin со счетом $rezultMatch\n\n" +
                            "Протокол матча будет сохранен на устройстве"
                )
                .setNeutralButton(
                    "Хорошо"
                ) { dialog, id ->
                    val intent = Intent(this@MatchActivity, ForUserMainActivity::class.java)
                    startActivity(intent)

                }
                .show()

        }
            else
            AlertDialog.Builder(this)
                .setTitle("Матч закончислся!")
                .setMessage("Матч закончислся победой команды $nameTeamWin со счетом $rezultMatch\n\n")
                .setPositiveButton(
                    "Хорошо"
                ) { dialog, id ->
                    val intent = Intent(this@MatchActivity, ForUserMainActivity::class.java)
                    startActivity(intent)
                }
                .show()

    }
    private fun recordProtocole(rezultMatch: String) {
//if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            "Протокол матча ${LocalDate.now()}.doc"
//        }else
        var fileName = "${match.id}-Протокол матча ${match.date.toString()}.doc"

        // Create file object
        val file = File(Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS), fileName)
            // Create file
            var isCreated = file.createNewFile()
            if (isCreated){
                if(match.description!=null)
                    file.writeText(match.description, Charsets.UTF_8)
                file.appendText("\n\nСостав команды "+curTeam1.team.name + "\n", Charsets.UTF_8)
                for (pl in curPlTeam1){
                    file.appendText("\n${pl.player.numPlayer}     ${pl.player.fio}", Charsets.UTF_8)
                }
                file.appendText("\n\nСостав команды "+curTeam2.team.name+ "\n", Charsets.UTF_8)
                for (pl in curPlTeam2){
                    file.appendText("\n${pl.player.numPlayer}     ${pl.player.fio}", Charsets.UTF_8)
                }
                file.appendText("\n\nРезультаты партий:", Charsets.UTF_8)
                for (part in listRezultParts){
                    file.appendText("\n$part", Charsets.UTF_8)
                }
                file.appendText("\n\nРезультат матча: "+rezultMatch, Charsets.UTF_8)
            }
    }

    private fun paramsEditText(row: Int, column: Int): androidx.gridlayout.widget.GridLayout.LayoutParams {
        var params = androidx.gridlayout.widget.GridLayout.LayoutParams(
            androidx.gridlayout.widget.GridLayout.spec(row),
            androidx.gridlayout.widget.GridLayout.spec(column))
        params.width = 120
        params.height = 120
        params.setMargins(1)
        return params
    }
    private fun removeView(view: View) {

        if (view.getParent() != null)
            (view.getParent() as ViewGroup).removeView(view)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }


}