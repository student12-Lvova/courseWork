package com.example.pr1_mp

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.google.android.material.textfield.TextInputLayout


@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    private lateinit var rezultComA: TextView
    private lateinit var rezultComB: TextView
    private lateinit var tvComA: TextView
    private lateinit var tvComB: TextView
    private lateinit var timer: TextView
    private lateinit var btnSourceComA : Button
    private lateinit var btnSourceComB : Button
    private lateinit var btnMinusSourceComA: Button
    private lateinit var btnMinusSourceComB: Button
    private lateinit var ivImgForComA : ImageView
    private lateinit var ivImgForComB : ImageView

    private var sourceA = 0;
    private var sourceB = 0;
    private var sourcePartA = 0;
    private var sourcePartB = 0;
    private lateinit var listBall:MutableList<String>
    private var whoseBall:String = ""
    private var numPart =1;


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listBall = listOf<String>().toMutableList()

        timer = findViewById(R.id.chronometerMatchM)
        timer.text = "00:00"

        rezultComA = findViewById(R.id.tvScorePartTAM)
        rezultComA.text = "0"
        rezultComB = findViewById(R.id.tvScorePartTBM)
        rezultComB.text = "0"
        tvComA = findViewById(R.id.tv_com_a)
        tvComB = findViewById(R.id.tv_com_b)
        btnSourceComA = findViewById(R.id.b_source_com_aM)
        btnSourceComB = findViewById(R.id.b_source_com_bM)
        btnMinusSourceComA = findViewById(R.id.bSourceMinusTA)
        btnMinusSourceComB = findViewById(R.id.bSourceMinusTB)
        ivImgForComA = findViewById(R.id.iv_ballM)
        ivImgForComB = findViewById(R.id.iv_ball1M)

        ivImgForComA.visibility = View.INVISIBLE
        ivImgForComB.visibility = View.INVISIBLE

        btnSourceComA.setOnClickListener{
            if (sourceA==0 && sourceB==0 && numPart==1 && whoseBall=="")
                whoseBall="comA"
            sourceA += 1;
            listBall.add("comA")
            btnSourceComA.text = sourceA.toString();
            ivImgForComA.visibility = View.VISIBLE
            ivImgForComB.visibility = View.INVISIBLE
            endParty()

        }

        btnSourceComB.setOnClickListener{
            if (sourceA==0 && sourceB==0 && numPart==1 && whoseBall=="")
                whoseBall="comB"
            sourceB+=1;
            listBall.add("comB")
            btnSourceComB.setText(sourceB.toString());
            ivImgForComB.visibility = View.VISIBLE
            ivImgForComA.visibility = View.INVISIBLE
            endParty()
        }

        btnMinusSourceComA.setOnClickListener{
            if(sourceA!=0)  sourceA-=1;
            else sourceA=0
            if (listBall.isNotEmpty()){
                listBall.removeAt(listBall.size-1)
                if (listBall.isNotEmpty()&&listBall[listBall.size-1] == "comA"){
                    ivImgForComA.visibility = View.VISIBLE
                    ivImgForComB.visibility = View.INVISIBLE
                }else{
                    ivImgForComB.visibility = View.VISIBLE
                    ivImgForComA.visibility = View.INVISIBLE
                }
            }

            btnSourceComA.setText(sourceA.toString())
            endParty()
        }
        btnMinusSourceComB.setOnClickListener{
            if(sourceB!=0) sourceB-=1;
            else sourceB=0
            if (listBall.isNotEmpty()){
                listBall.removeAt(listBall.size-1)
                if (listBall.isNotEmpty()&&listBall[listBall.size-1] == "comA"){
                    ivImgForComA.visibility = View.VISIBLE
                    ivImgForComB.visibility = View.INVISIBLE
                }else{
                    ivImgForComB.visibility = View.VISIBLE
                    ivImgForComA.visibility = View.INVISIBLE
                }
            }
            btnSourceComB.setText(sourceB.toString())
            endParty()
        }

    }

    fun endParty () {
        if (((sourceA==25&&sourceB<=23) || (sourceA>=25 && sourceA-sourceB==2))) {
            sourcePartA++
            rezultComA.text = sourcePartA.toString()
            btnSourceComA.isClickable = false
            btnSourceComB.isClickable = false;
            btnMinusSourceComA.isClickable = false;
            btnMinusSourceComB.isClickable = false;

            numPart++
            startTimer()
        }
        if((sourceB==25&&sourceA<=23) || (sourceB>=25 && sourceB-sourceA==2)){

            sourcePartB++
            rezultComB.text = sourcePartB.toString()
            btnSourceComA.isClickable = false
            btnSourceComB.isClickable = false;
            btnMinusSourceComA.isClickable = false;
            btnMinusSourceComB.isClickable = false;

            numPart++
            startTimer()
        }

    }
    fun changeOfSides(){

        if (whoseBall=="comA")
        {
            ivImgForComB.visibility = View.VISIBLE
            ivImgForComA.visibility = View.INVISIBLE
            whoseBall="comB"
        }
        else{
            if (whoseBall=="comB")
            {
                ivImgForComA.visibility = View.VISIBLE
                ivImgForComB.visibility = View.INVISIBLE
                whoseBall="comA"
            }
        }


        var linearLayout = findViewById<LinearLayout>(R.id.llTextView)
        var textTeamA = findViewById<TextInputLayout>(R.id.textTeamA)
        var textTeamB = findViewById<TextInputLayout>(R.id.textTeamB)
        var scorePartTeamA = findViewById<TextView>(R.id.tvScorePartTAM)
        var dvoet = findViewById<TextView>(R.id.textView20M)
        var scorePartTeamB = findViewById<TextView>(R.id.tvScorePartTBM)

        var ll_forBtnPlus = findViewById<LinearLayout>(R.id.ll_forButton)
        var btnPlusTA = findViewById<AppCompatButton>(R.id.b_source_com_aM)
        var imgBallComA = findViewById<ImageView>(R.id.iv_ballM)
        var imgBallComB = findViewById<ImageView>(R.id.iv_ball1M)
        var btnPlusTB = findViewById<AppCompatButton>(R.id.b_source_com_bM)

        var ll_forBtnMinus = findViewById<RelativeLayout>(R.id.ll_forBtnMinus)
        var btnMinusTA = findViewById<AppCompatButton>(R.id.bSourceMinusTA)
        var btnMinusTB = findViewById<AppCompatButton>(R.id.bSourceMinusTB)

        //номер партии 1,3,5
        if (numPart%2!=0){
            linearLayout.removeAllViews()
            linearLayout.addView(textTeamA)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                scorePartTeamA.setTextAlignment(TextView.TEXT_ALIGNMENT_TEXT_END)
            }
            linearLayout.addView(scorePartTeamA)
            linearLayout.addView(dvoet)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                scorePartTeamB.textAlignment=TextView.TEXT_ALIGNMENT_TEXT_START
            }
            linearLayout.addView(scorePartTeamB)
            linearLayout.addView(textTeamB)

            ll_forBtnPlus.removeAllViews()
            ll_forBtnPlus.addView(btnPlusTA)
            ll_forBtnPlus.addView(imgBallComA)
            ll_forBtnPlus.addView(imgBallComB)
            ll_forBtnPlus.addView(btnPlusTB)

            ll_forBtnMinus.removeAllViews()
            ll_forBtnMinus.addView(btnMinusTA)
            ll_forBtnMinus.addView(btnMinusTB)
        }
        else{
            linearLayout.removeAllViews()
            linearLayout.addView(textTeamB)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                scorePartTeamB.textAlignment=TextView.TEXT_ALIGNMENT_TEXT_END
            }
            linearLayout.addView(scorePartTeamB)
            linearLayout.addView(dvoet)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                scorePartTeamA.textAlignment=TextView.TEXT_ALIGNMENT_TEXT_START
            }
            linearLayout.addView(scorePartTeamA)
            linearLayout.addView(textTeamA)

            ll_forBtnPlus.removeAllViews()
            ll_forBtnPlus.addView(btnPlusTB)
            ll_forBtnPlus.addView(imgBallComB)
            ll_forBtnPlus.addView(imgBallComA)
            ll_forBtnPlus.addView(btnPlusTA)

            ll_forBtnMinus.removeAllViews()
            ll_forBtnMinus.addView(btnMinusTB)
            ll_forBtnMinus.addView(btnMinusTA)
        }



    }
    fun startTimer(){

        var second = 60;
        while (second>0){

            second--;
        }
        val timer = object: CountDownTimer(3000, 1000) {//минута
            override fun onTick(p0: Long) {
                var p = p0 / 1000
                if (p>=10)
                    timer.text = "00:$p"
                else
                    timer.text = "00:0$p"
            }
            override fun onFinish() {
                btnSourceComA.isClickable = true
                btnSourceComB.isClickable = true
                btnMinusSourceComA.isClickable = true
                btnMinusSourceComB.isClickable = true
                sourceA=0
                sourceB=0
                btnSourceComA.text = sourceA.toString()
                btnSourceComB.text = sourceB.toString()
                timer.text = "00:00"
                changeOfSides()
            }
        }
        timer.start();
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }


}