package com.example.pr1_mp.currentTeam

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.get
import androidx.core.view.size
import com.example.pr1_mp.CreateMatchActivity
import com.example.pr1_mp.R
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.models.CurrentPlayer
import com.example.pr1_mp.models.CurrentTeam

//редактирование команды из бд для одного матча
// в составе можем убрать игрока или сменить выбранному номер и/или позицию
// изменения в тренерском составе в CreateMatch
// изменять название команды нельзя
class EditCurrentTeamActivity : AppCompatActivity() {

    private lateinit var textTeamName: TextView//название команды
    private lateinit var etPlayerNum: EditText//игровой номер игрока
    private lateinit var position: Spinner//позиция игрока

    private lateinit var tablePlayers: TableLayout
    private lateinit var llEditPlayer: LinearLayout
    private lateinit var btnUpdatePlayer: AppCompatButton
    private lateinit var btnAddTeam: AppCompatButton

    lateinit var workMyDB: WorkMyDB
    private var idTeam:Long = -1//
    private lateinit var team: CurrentTeam
    private lateinit var listPlayers:MutableList<CurrentPlayer>
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var curPlayer: CurrentPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_current_team)

        workMyDB = WorkMyDB(this)

        val extras = intent.extras
        if (extras != null && extras.getInt("idTeam")>0) {
            idTeam = extras.getInt("idTeam").toLong()
            team = workMyDB.selectCurTeamById(idTeam.toInt())
            listPlayers =
                workMyDB.selectCurPlayerByIdCurTeam(idTeam.toInt())

        }

        initComponents()
        fillField()
        onClickListener()
    }
    private fun initComponents() {
        //поля для заполнения
        textTeamName = findViewById(R.id.editNameTeam)
        etPlayerNum = findViewById(R.id.et_PlayerNum)
        position = findViewById(R.id.spinnerPosition)

        //кнопка добавления игрока
        llEditPlayer = findViewById(R.id.llEditPlayer)
        llEditPlayer.visibility = View.GONE
        btnUpdatePlayer = findViewById(R.id.bUpdatePlayer)
        btnUpdatePlayer.visibility = View.GONE
        tablePlayers = findViewById(R.id.tablePlayers)

        btnAddTeam = findViewById(R.id.btnEditTeam)

    }
    private fun fillField() {
        //заполняем поле с названием команды
        if (idTeam>0)
            textTeamName.text = team.team.name

        //заполняем spinner
        adapter =  ArrayAdapter(this,
            android.R.layout.simple_spinner_item, arrayListOf("Игрок", "Капитан","Либеро"))
        position.adapter = adapter

        //заполняем таблицу с //
        tablePlayers.addView(createRow0(), 0)
        if (listPlayers.size!=0){
            for (player in listPlayers)
                tablePlayers.addView(createRowPlayer(player))
        }
        etPlayerNum.isClickable=false
    }
    private fun onClickListener() {

        tablePlayers.setOnClickListener{
            llEditPlayer.visibility = View.GONE
            btnUpdatePlayer.visibility = View.GONE
        }

        //проверка полей
        btnUpdatePlayer.setOnClickListener {
            if (checkInfPlayer()) {
                curPlayer.player.numPlayer = etPlayerNum.text.toString().toInt()
                curPlayer.position = position.selectedItem.toString()

                for (player in listPlayers) {
                    if (listPlayers.indexOf(player) == curPlayer.id.toInt()) {
                        var index = listPlayers.indexOf(player)
                        listPlayers.removeAt(index)
                        listPlayers.add(index, curPlayer)
                        break
                    }
                }

                tablePlayers.removeAllViews()
                tablePlayers.addView(createRow0())
                for (player in listPlayers)
                    tablePlayers.addView(createRowPlayer(player), listPlayers.indexOf(player)+1)
            }

        }

        position.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, view: View?,
                                        pos: Int, id: Long) {
                var ch:Char = adapter.getItem(pos).toString().toCharArray()[0]
                var countLibero = 0
                for (player in listPlayers){
                    if (player.position!=null ){
                        if (player.position.toCharArray()[0] == ch &&
                            player.position.toCharArray()[0]=='К'){
                            Toast.makeText(this@EditCurrentTeamActivity,
                                "Капитан команды уже назначен", Toast.LENGTH_SHORT).show()
                            position.setSelection(adapter.getPosition(curPlayer.position.toString()))
                        }
                        if (player.position.toCharArray()[0] =='Л'){
                            if (countLibero<2)
                                countLibero++
                            else{
                                Toast.makeText(this@EditCurrentTeamActivity,
                                    "Вы не можете назначить больше 2 либеро в команде!", Toast.LENGTH_SHORT).show()
                                position.setSelection(adapter.getPosition(curPlayer.position.toString()))
                            }
                        }
                    }


                }


                if (curPlayer!=null)
                    curPlayer.position = ch.toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // write code to perform some action
            }
        }

        btnAddTeam.setOnClickListener{
            if (listPlayers.size in 6..14){


                var cvCurPlayers = listOf<ContentValues>().toMutableList()
                for (curPlayer in listPlayers){
                    var contentValues = ContentValues()
                    contentValues.put("idPlayer", curPlayer.player.id)
                    contentValues.put("position", curPlayer.position.toCharArray()[0].toString())
                    cvCurPlayers.add(contentValues)
                }

                    workMyDB.addCurPlayersByIdCurTeam(team.team.id.toInt(),cvCurPlayers)

                val intent = Intent(this@EditCurrentTeamActivity, CreateMatchActivity::class.java)
                startActivity(intent)
            }
            else
                Toast.makeText(this@EditCurrentTeamActivity,
                    "Кол-во игроков < 6 или > 14!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkInfPlayer():Boolean {

        var countLibero=0
        for (player in listPlayers) if (player.position=="Л") countLibero++
        for (player in listPlayers) {
            if (position.selectedItem.toString() == "Капитан" && player.position == "К"
                && player.position != curPlayer.position) {

                Toast.makeText(
                    applicationContext, "Нельзя назначить больше 1 капитана!",
                    Toast.LENGTH_SHORT
                ).show()
                return false
            }
            if (countLibero == 2 && position.selectedItem.toString() == "Либеро"
                && player.position == "Л" && player.position != curPlayer.position) {

                Toast.makeText(
                    applicationContext, "Нельзя назначить больше 2 либеро!",
                    Toast.LENGTH_SHORT
                ).show()
                return false
            }
        }
        return true
    }
    private fun createRowPlayer(player: CurrentPlayer): TableRow {
        var row= TableRow(this)

        var tvNum= TextView(this)
        tvNum.text = player.player.numPlayer.toString()
        //tvNum.layoutParams = marginView()
        var tvFIO= TextView(this)
        tvFIO.text = player.player.fio
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT)
        params.setMargins(5,5,5,5)
        //tvFIO.layoutParams = params
        var tvPos= TextView(this)
        if(player.position!=null)
            tvPos.text = player.position.toCharArray()[0].toString()
        else {
            tvPos.text = player.player.position.toCharArray()[0].toString()
            player.position = player.player.position.toCharArray()[0].toString()
        }
        //tvPos.layoutParams = marginView()

        var btnEdit = AppCompatButton(this)
        btnEdit.text = "Изм"
        btnEdit.setOnClickListener {
            llEditPlayer.visibility = View.VISIBLE
            btnUpdatePlayer.visibility = View.VISIBLE

            curPlayer = player
            etPlayerNum.setText(player.player.numPlayer.toString())
            curPlayer.id = (tablePlayers.size+1).toLong()

            //задать позицию
            position.getChildAt(adapter.getPosition(player.position))
        }
        //btnEdit.layoutParams = marginView()

        var btnDelete = AppCompatButton(this)
        btnDelete.text = "X"
        btnDelete.setOnClickListener {
            listPlayers.remove(player)
            tablePlayers.removeView(row)


        }
        //btnDelete. = marginView()
        row.addView(tvNum, 0)
        row.addView(tvFIO, 1)
        row.addView(tvPos, 2)
        row.addView(btnEdit, 3)
        row.addView(btnDelete, 4)
        row.layoutParams = marginRow()
        row[0].layoutParams = marginView()
        row[1].layoutParams = marginView()
        row[2].layoutParams = marginView()
        row[3].layoutParams = marginButton()
        row[4].layoutParams = marginButton()

        return row

    }
    private fun createRow0(): View {

        var row= TableRow(this)
        var tv= TextView(this)
        tv.layoutParams = marginView()
        tv.text = "№"
        var tv1= TextView(this)
        tv1.layoutParams = marginView()
        tv1.text = "ФИО"
        var tv2= TextView(this)
        tv2.layoutParams = marginView()
        tv2.text = "Поз."
        var tv3= TextView(this)
        tv3.layoutParams = marginView()
        var tv4= TextView(this)
        tv4.layoutParams = marginView()

        row.addView(tv, 0)
        row.addView(tv1, 1)
        row.addView(tv2, 2)
        row.addView(tv3, 3)
        row.addView(tv4, 4)
        row.layoutParams = marginRow()
        return row
    }

    private fun marginView(): TableRow.LayoutParams {
        val params = TableRow.LayoutParams(
            TableRow.LayoutParams.WRAP_CONTENT,
            TableRow.LayoutParams.WRAP_CONTENT, 1F
        )
        return params;
    }
    private fun marginButton(): TableRow.LayoutParams {
        val params = TableRow.LayoutParams(70,
            70, 1F
        )
        return params;
    }
    private fun marginRow(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
            TableLayout.LayoutParams.WRAP_CONTENT,
            TableLayout.LayoutParams.WRAP_CONTENT
        );
    }

}