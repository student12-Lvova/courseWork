package com.example.pr1_mp.models;

import androidx.annotation.Size;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.time.LocalDate;

public class Match {
    @NotNull
    private long id;
    @NotNull
    private CurrentTeam team1;
    @NotNull
    private CurrentTeam team2;
    @NotNull
    private String description;
    private LocalDate date;

    public Match(@NotNull long id, @NotNull CurrentTeam team1, @NotNull CurrentTeam team2, @NotNull String description, @NotNull LocalDate date) {
        this.id = id;
        this.team1 = team1;
        this.team2 = team2;
        this.description = description;
        this.date = date;
    }

    public long getId() {
        return id;
    }
    public void setId(@NotNull long id) {
        this.id = id;
    }

    public CurrentTeam getTeam1() {
        return team1;
    }
    public CurrentTeam getTeam2() {
        return team2;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getDate() {
        return date;
    }
}
