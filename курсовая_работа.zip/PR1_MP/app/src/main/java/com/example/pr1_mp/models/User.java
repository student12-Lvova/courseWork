package com.example.pr1_mp.models;

import androidx.annotation.Size;

import org.jetbrains.annotations.NotNull;


public class User {
    private long id;
    @NotNull
    @Size(min = 5, max = 20)
    private String login;
    @NotNull
    @Size(min = 16, max = 20)
    private String password;
    @NotNull
    private String email;
    @Size(11)
    private String phoneNum;

    public User(@NotNull long id, @NotNull String login, @NotNull String password,
                @NotNull String email, String phoneNum) {
        this.id = id;
        this.login = login;
        this.password = password;
        this.email = email;
        this.phoneNum = phoneNum;
    }

    public long getId() {
        return id;
    }

    public void setId(@NotNull long id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(@NotNull String email) {
        this.email = email;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(@NotNull String phoneNum) {
        this.phoneNum = phoneNum;
    }
}
