package com.example.pr1_mp

import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.pr1_mp.connectdb.WorkMyDB
import java.util.regex.Pattern


class RegistrationActivity : AppCompatActivity() {

    lateinit var workDb: WorkMyDB

    lateinit var tvLogin:EditText
    lateinit var tvPassword:EditText
    lateinit var tvEmail:EditText
    lateinit var tvPhoneNum:EditText
    lateinit var btnRegistration:Button

    lateinit var settings: SharedPreferences
    private val PREFS_FILE = "Account"
    private val PREF_LOGIN = "Login"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            // showing the back button in action bar
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        workDb = WorkMyDB(this@RegistrationActivity)
        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE)

        tvLogin = findViewById(R.id.etLogin)
        tvPassword = findViewById(R.id.editPassword)
        tvEmail = findViewById(R.id.etEmailReg)
        tvPhoneNum = findViewById(R.id.etPhoneNumReg)

        btnRegistration =findViewById(R.id.bEditStaffTrain)
        btnRegistration.setOnClickListener(){
            if(validateString(tvLogin,"login") &&
                validateString(tvPassword,"password") &&
                validateString(tvEmail,"email") &&
                validateString(tvPhoneNum,"phone") ){
                insertUser()
                val prefEditor: Editor = settings.edit()

                prefEditor.putString(PREF_LOGIN, tvLogin.text.toString())
                prefEditor.apply()

                val intent = Intent(this@RegistrationActivity, AuthActivity::class.java)
                startActivity(intent)
            }
        }
    }

    private fun insertUser() {
        var Flogin = tvLogin.text.toString()
        var Fpassword = tvPassword.text.toString()
        var Femail = tvEmail.text.toString()
        var FphoneNum = tvPhoneNum.text.toString()

       var contentValues = ContentValues()
       contentValues.put("login", Flogin);
       contentValues.put("password", Fpassword);
       contentValues.put("email", Femail)
       contentValues.put("phone", FphoneNum)

        workDb.addUser(contentValues)        //mDBHelper.close()
    }




    fun validateString(et:EditText, whatCheck: String):Boolean{
       // val regex = Regex("[a-zA-Z0-9]")
        val pattern: Pattern = Pattern.compile("[а-яёА-ЯЁ]+")
        var emailPattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
        val phonePattern: Pattern = Pattern.compile("\\d{11}")

        var strError = ""
        when(whatCheck){
            "login" -> {
                if (et.text.isEmpty() || et.text.length<5)
                    strError = "Минимальная длина логина 5 символов"
                if (pattern.matcher(et.text.toString()).find())
                    strError = getString(R.string.errorEnterLogin)
            }
            "password" -> {
                if (et.text.isEmpty() || (et.text.length<6 || et.text.length>20))
                    strError = "Минимальная длина пароля 6 символов, максимальная - 20"
                if (pattern.matcher(et.text.toString()).find())
                    strError = "Пароль должен содержать только латинский алфавит и цифры"
            }
            "email" -> {
                if (et.text.toString()=="" || !emailPattern.matcher(et.text.toString()).find())
                    strError = "Некорректный ввод электронной почты"
            }
            "phone" -> {
                if (et.text.toString()!="" && !phonePattern.matcher(et.text.toString()).find())
                    strError = "Некорректный ввод номера телефона"
            }


        }
        if (!strError.equals("")){
            Toast.makeText(applicationContext, strError, Toast.LENGTH_SHORT).show()
            return false
        }
        else
            return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }


}