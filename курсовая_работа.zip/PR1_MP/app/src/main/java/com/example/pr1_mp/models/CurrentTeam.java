package com.example.pr1_mp.models;

import androidx.annotation.Size;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class CurrentTeam {

    private int id;
    @NotNull
    private Team team;
    @Size(min=6, max=14)
    private List<Player> listPlayers;
    @NotNull
    private int idManage;

    private int tecScorePart;
    @Size(max=2)
    private int countTimeOut;
    @Size(max=6)
    private int countReplacement;


    public CurrentTeam(int id, Team team, int idManage) {
        this.id = id;
        this.team = team;
        this.idManage = idManage;
    }

    public CurrentTeam() {

    }

    public int getIdManage() {
        return idManage;
    }

    public void setIdManage(int idManage) {
        this.idManage = idManage;
    }

    public List<Player> getListPlayers() {
        return listPlayers;
    }

    public void setListPlayers(List<Player> listPlayers) {
        this.listPlayers = listPlayers;
    }

    public int getTecScorePart() {
        return tecScorePart;
    }

    public void setTecScorePart(int tecScorePart) {
        this.tecScorePart = tecScorePart;
    }

    public int getCountTimeOut() {
        return countTimeOut;
    }

    public void setCountTimeOut(int countTimeOut) {
        this.countTimeOut = countTimeOut;
    }

    public int getCountReplacement() {
        return countReplacement;
    }

    public void setCountReplacement(int countReplacement) {
        this.countReplacement = countReplacement;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }


}
