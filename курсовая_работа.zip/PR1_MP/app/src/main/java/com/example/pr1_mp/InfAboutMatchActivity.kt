package com.example.pr1_mp

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import androidx.appcompat.widget.AppCompatButton
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.models.CurrentMatch
import com.example.pr1_mp.models.Match

class InfAboutMatchActivity : AppCompatActivity() {
    //поля формы
    private  lateinit var descMatch:EditText
    private  lateinit var rbOficMatch:RadioButton
    private  lateinit var rbLubMatch:RadioButton
    private  lateinit var protocol:CheckBox
    private  lateinit var btnStartMatch:AppCompatButton

    lateinit var workMyDB: WorkMyDB
    var idUser: Long = 0
    var idMatch:Int = -1
    lateinit var match: Match

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inf_about_match)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            // showing the back button in action bar
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        workMyDB =
            WorkMyDB(this@InfAboutMatchActivity)
        val extras = intent.extras
        if (extras != null && extras.getInt("idMatch")>0) {
            idMatch = extras.getInt("idMatch")
            match = workMyDB.selectMatchById(idMatch)
        }

        initFields()
        listenFields()
    }

    private fun initFields() {
        descMatch = findViewById(R.id.editEmailRepT1)
        rbOficMatch = findViewById(R.id.rbTypeOfic)
        rbLubMatch = findViewById(R.id.rbTypeLub)
        protocol = findViewById(R.id.cbProtocol)
        btnStartMatch = findViewById(R.id.bAddNewTeam)
    }
    private fun listenFields() {
        var typeMatch=""
        var placement = false
        rbOficMatch.setOnClickListener{
            placement=true
            typeMatch = "ofic"
        }
        rbLubMatch.setOnClickListener{
            placement = false
            typeMatch = "lub"
        }

        btnStartMatch.setOnClickListener {
            if (workMyDB.addDescMatch(idMatch, descMatch.text.toString())){
                var currentMatch = CurrentMatch(idMatch, placement,
                    !protocol.isActivated)

                val intent = Intent(this@InfAboutMatchActivity, MatchActivity::class.java)
                intent.putExtra("idMatch", idMatch)
                intent.putExtra("placement", currentMatch.isPlacement)
                intent.putExtra("protocol", currentMatch.isProtocol)
                startActivity(intent)
            }

        }
    }
}