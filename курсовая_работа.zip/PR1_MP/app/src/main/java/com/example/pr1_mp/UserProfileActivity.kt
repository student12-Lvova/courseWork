package com.example.pr1_mp

import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.models.User
import java.util.regex.Pattern


class UserProfileActivity : AppCompatActivity() {
    lateinit var workDb: WorkMyDB

    lateinit var settings: SharedPreferences
    private val PREFS_FILE = "Account"
    private val PREF_LOGIN = "Login"
    private val PREF_ID = "Id"

    lateinit var id:String
    lateinit var user: User

    private lateinit var login:EditText
    private lateinit var new_password:EditText
    private lateinit var old_password:EditText
    private lateinit var email:EditText
    private lateinit var phoneNum:EditText
    private  lateinit var btnUpdate: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            // showing the back button in action bar
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE);
        workDb = WorkMyDB(this@UserProfileActivity)
        workDb.idUser = settings.getString(PREF_ID,"id")!!.toLong()

        btnUpdate = findViewById(R.id.bEditUserProfile)
        login = findViewById(R.id.etLogin)
        email= findViewById(R.id.editEmailAddress)
        phoneNum= findViewById(R.id.editTextPhone)
        old_password = findViewById(R.id.editOldPassword)
        new_password = findViewById(R.id.editNewPassword)

        fillFields()

        workDb.idUser = settings.getString(PREF_ID,"id")!!.toLong()


        btnUpdate.setOnClickListener {
            if(checkInfUser()){
                val userValues = ContentValues()
                userValues.put("login", login.text.toString())
                if (new_password.text.toString()!="")
                    userValues.put("password", new_password.text.toString())
                userValues.put("email", email.text.toString())
                userValues.put("phone", phoneNum.text.toString())
                userValues.put("login", login.text.toString())

                if(workDb.updateUser(userValues, old_password.text.toString())) {
                    val intent = Intent(this@UserProfileActivity, ForUserMainActivity::class.java)
                    startActivity(intent)
                }

            }

        }
    }

    private fun checkInfUser(): Boolean {
        var login = login.text
        var email = email.text
        var phoneNum = phoneNum.text
        var old_password = old_password.text
        var new_password = new_password.text

        val pattern: Pattern = Pattern.compile("[а-яёА-ЯЁ]+")
        var emailPattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
        val phonePattern: Pattern = Pattern.compile("\\d{11}")

        if (login.isEmpty() || login.length<5) {
            Toast.makeText(
                applicationContext, "Минимальная длина логина 5 символов",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }
        if (pattern.matcher(login.toString()).find()){
            Toast.makeText(
                applicationContext, getString(R.string.errorEnterLogin),
                Toast.LENGTH_SHORT
            ).show()
            return false
        }
        if (email.toString()=="" || !emailPattern.matcher(email.toString()).find()){
            Toast.makeText(
                applicationContext, "Некорректный ввод электронной почты",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }
        if (phoneNum.toString()!="" && !phonePattern.matcher(phoneNum.toString()).find()) {
            Toast.makeText(
                applicationContext, "Некорректный ввод номера телефона",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }
        if (new_password.isNotEmpty()){
            if (old_password.isEmpty()){
                Toast.makeText(
                    applicationContext, "Введите старый пароль!", Toast.LENGTH_SHORT).show()
                return false
            }
            if (new_password.length<6 || new_password.length>20) {
                Toast.makeText(applicationContext,
                    "Минимальная длина пароля 6 символов, максимальная - 20",
                    Toast.LENGTH_SHORT).show()
                return false
            }
            if (pattern.matcher(new_password.toString()).find()) {
                Toast.makeText(applicationContext,
                    "Пароль должен содержать только латинский алфавит и цифры",
                    Toast.LENGTH_SHORT).show()
                return false
            }
        }
        return true
    }

    private fun fillFields() {
        user = workDb.selectUserId(settings.getString(PREF_ID,"id")!!.toLong())

        login.setText(user.login)
        email.setText(user.email)
        phoneNum.setText(user.phoneNum)

        var edit = settings.edit()
        edit.putString(PREF_ID, user.id.toString())
        edit.putString(PREF_LOGIN, user.login)
        edit.apply()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }
}