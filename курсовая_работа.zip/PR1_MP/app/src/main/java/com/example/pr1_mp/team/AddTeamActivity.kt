package com.example.pr1_mp.team

import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.get
import com.example.pr1_mp.AddStaffTrainers
import com.example.pr1_mp.R
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.models.Player
import com.example.pr1_mp.models.Team
//создание новой команды дл бд
//добавляем игроков, тренерский состав, и инфу про команду
class  AddTeamActivity : AppCompatActivity() {

    private lateinit var editAddress:EditText
    private lateinit var editNameTeam: EditText
    private lateinit var etPlayerNum: EditText
    private lateinit var etLastname: EditText
    private lateinit var etFirstname: EditText
    private lateinit var etPatronymic: EditText
    private lateinit var position:Spinner

    private lateinit var tablePlayers: TableLayout
    private lateinit var btnLL: AppCompatButton
    private lateinit var btnAddPlayer: AppCompatButton
    private lateinit var btnAddTeam: AppCompatButton
    private lateinit var llAddPlayer: LinearLayout
    private lateinit var btnUpdatePlayer: AppCompatButton
    private lateinit var btnAddStaffTrainers:AppCompatButton


    lateinit var workMyDB: WorkMyDB
    private lateinit var team:Team
    private lateinit var listPlayers:MutableList<Player>
    private lateinit var curPlayer:Player
    private lateinit var adapter:ArrayAdapter<String>
    private var idManager:Int=0
    private var idTrainer:Int=0

    lateinit var settings: SharedPreferences
    private val PREFS_FILE = "Account"
    private val PREF_ID = "Id"
    private val PREF_IDM = "idM"
    private val PREF_IDT = "idT"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_team)
        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            // showing the back button in action bar
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        settings = getSharedPreferences(PREFS_FILE, MODE_PRIVATE);
        workMyDB = WorkMyDB(this)
        workMyDB.idUser = settings.getString(PREF_ID,"id")!!.toLong()
        idManager=settings.getInt(PREF_IDM,0)
        idTrainer=settings.getInt(PREF_IDT,0)

        team = Team()
        listPlayers = listOf<Player>().toMutableList()
        curPlayer = Player()

        initComponents()
        fillField()
        onClickListener()
    }
    private fun initComponents() {
        //поля для заполнения
        editNameTeam = findViewById(R.id.editNameTeam)
        editAddress = findViewById(R.id.editAddress)
        etLastname = findViewById(R.id.editLastnameM)
        etFirstname = findViewById(R.id.edit_firstname)
        etPatronymic = findViewById(R.id.edit_patronymic)
        etPlayerNum = findViewById(R.id.et_PlayerNum)
        position = findViewById(R.id.spinnerPosition)

        //кнопка добавления игрока
        llAddPlayer = findViewById(R.id.llEditPlayer)
        llAddPlayer.visibility = View.GONE
        btnUpdatePlayer = findViewById(R.id.bUpdatePlayer)
        btnUpdatePlayer.visibility = View.GONE
        btnAddPlayer = findViewById(R.id.bAddPlayer2)
        btnAddPlayer.visibility = View.GONE
        tablePlayers = findViewById(R.id.tablePlayers)

        //поля для редактирования и добавления
        btnLL = findViewById(R.id.bAddPlayer)

        btnAddTeam = findViewById(R.id.btnEditTeam)
        btnAddStaffTrainers = findViewById(R.id.btnAddStaffTrainers)

    }
    private fun fillField() {

        //заполняем spinner
        adapter =  ArrayAdapter(this,
            android.R.layout.simple_spinner_item, arrayListOf("Игрок", "Капитан","Либеро"))
        position.adapter = adapter

        //заполняем таблицу с игроками
        //tablePlayers.removeView(0)
        tablePlayers.addView(createRow0(), 0)
    }
    private fun onClickListener() {

        tablePlayers.setOnClickListener{
            llAddPlayer.visibility = View.GONE
            btnUpdatePlayer.visibility = View.GONE
            btnAddPlayer.visibility = View.GONE
        }

        btnLL.setOnClickListener {
            llAddPlayer.visibility = View.VISIBLE
            btnAddPlayer.visibility = View.VISIBLE
            btnUpdatePlayer.visibility = View.GONE

            etLastname.setText("")
            etFirstname.setText("")
            etPatronymic.setText("")
            etPlayerNum.setText("")

        }

        //проверка полей
        btnAddPlayer.setOnClickListener {
            //проверка на поля
            if (checkInfPlayer()){
                var player = Player(etLastname.text.toString(), etFirstname.text.toString(),
                    etPatronymic.text.toString(), etPlayerNum.text.toString().toInt(),
                    position.selectedItem.toString().toCharArray()[0].toString() )

                player.id = (listPlayers.size+1).toLong()
                listPlayers.add(player)

                tablePlayers.addView(createRowPlayer(player))
            }
        }

        btnUpdatePlayer.setOnClickListener {

            if (checkInfPlayer()) {
                curPlayer.lastname = etLastname.text.toString()
                curPlayer.firstname = etFirstname.text.toString()
                curPlayer.patronymic = etPatronymic.text.toString()
                curPlayer.numPlayer = etPlayerNum.text.toString().toInt()
                curPlayer.position = position.selectedItem.toString().toCharArray()[0].toString()

                for (player in listPlayers) {
                    if (player.id == curPlayer.id) {
                        var index = listPlayers.indexOf(player)
                        listPlayers.removeAt(index)
                        listPlayers.add(index, curPlayer)
                        break
                    }
                }

                tablePlayers.removeAllViews()
                tablePlayers.addView(createRow0())
                for (player in listPlayers)
                    tablePlayers.addView(createRowPlayer(player), listPlayers.indexOf(player)+1)
            }

        }

        position.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, view: View?,
                                        pos: Int, id: Long) {
                var ch:Char = adapter.getItem(pos).toString().toCharArray()[0]
                var countLibero = 0
                for (player in listPlayers){
                    if (player.position.toCharArray()[0] == ch && player.position.toCharArray()[0]=='К'){
                        Toast.makeText(this@AddTeamActivity,
                            "Капитан команды уже назначен", Toast.LENGTH_SHORT).show()
                        position.setSelection(adapter.getPosition(curPlayer.position.toString()))
                    }
                    if (player.position.toCharArray()[0] =='Л'){
                        if (countLibero<2)
                            countLibero++
                        else{
                            Toast.makeText(this@AddTeamActivity,
                                "Вы не можете назначить больше 2 либеро в команде!", Toast.LENGTH_SHORT).show()
                            position.setSelection(adapter.getPosition(curPlayer.position.toString()))
                        }
                    }

                }

            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // write code to perform some action
            }
        }

        btnAddTeam.setOnClickListener{
            if (listPlayers.size in 6..14){

                var cvPlayers = listOf<ContentValues>().toMutableList()
                for (player in listPlayers){
                    var contentValues = ContentValues()
                    contentValues.put("lastname", player.lastname)
                    contentValues.put("firstname", player.firstname)
                    contentValues.put("patronymic", player.patronymic)
                    contentValues.put("numPlayer", player.numPlayer)
                    contentValues.put("position", player.position.toCharArray()[0].toString())

                    cvPlayers.add(contentValues)
                }
                if (checkField()){
                    idManager=settings.getInt(PREF_IDM,0)
                    idTrainer=settings.getInt(PREF_IDT,0)
                    var contentValues = ContentValues()
                    contentValues.put("idUser", workMyDB.idUser)
                    if (idManager!=0)
                        contentValues.put("idManage", idManager)
                    if (idTrainer!=0)
                        contentValues.put("idTrain", idTrainer)
                    contentValues.put("name", editNameTeam.text.toString())
                    contentValues.put("address", editAddress.text.toString())

                    workMyDB.addTeam(cvPlayers,contentValues)

                    finish()
                }
            }
            else
                Toast.makeText(this@AddTeamActivity,
                    "Кол-во игроков < 6 или > 14!", Toast.LENGTH_SHORT).show()
        }

        btnAddStaffTrainers.setOnClickListener {
            val intent = Intent(this@AddTeamActivity, AddStaffTrainers::class.java)
            intent.putExtra("type", "add")
            startActivity(intent)

        }
    }

    private fun checkField(): Boolean {
        idManager=settings.getInt(PREF_IDM,0)
        idTrainer=settings.getInt(PREF_IDT,0)
        if (idManager==0&&idTrainer==0) {
            Toast.makeText(this@AddTeamActivity,
                "Добавите представителя команды!", Toast.LENGTH_SHORT).show()
            return false
        }
        if (editNameTeam.text.toString()==""){
            Toast.makeText(this@AddTeamActivity,
                "Добавите название команды!", Toast.LENGTH_SHORT).show()
            return false
        }
        if (editAddress.text.toString()==""){
            Toast.makeText(this@AddTeamActivity,
                "Добавите адрес команды!", Toast.LENGTH_SHORT).show()
            return false
        }
        return true

    }


    private fun checkInfPlayer():Boolean {

        var lastname = etLastname.text
        var firstname = etFirstname.text
        var patronymic = etPatronymic.text

        if (lastname.isEmpty() || !isCyrillic(lastname.toString())) {
            Toast.makeText(applicationContext, "Ошибка ввода фамилии", Toast.LENGTH_SHORT).show()
            etLastname.setBackgroundColor(Color.RED)
            return false
        }
        if (firstname.isEmpty() || !isCyrillic(firstname.toString())) {
            Toast.makeText(applicationContext, "Ошибка ввода имени", Toast.LENGTH_SHORT).show()
            etFirstname.setBackgroundColor(Color.RED)
            return false
        }
        if (patronymic.isNotEmpty() && !isCyrillic(patronymic.toString())) {
            Toast.makeText(applicationContext, "Ошибка ввода отчества", Toast.LENGTH_SHORT).show()
            etPatronymic.setBackgroundColor(Color.RED)
            return false
        }
        if (etPlayerNum.text.toString()=="") {
            Toast.makeText(
                this@AddTeamActivity,
                "Введите игровой номер игрока", Toast.LENGTH_SHORT).show()
            return false
        }
        else{
            var countLibero=0
            for (player in listPlayers) if (player.position=="Л") countLibero++
            for (player in listPlayers){
                if (curPlayer!=null){
                    if (player.numPlayer==etPlayerNum.text.toString().toInt()
                        && player.numPlayer!=curPlayer.numPlayer){//

                        Toast.makeText(
                            this@AddTeamActivity,
                            "Игровые номера индивидуальны!", Toast.LENGTH_SHORT).show()
                        return false
                    }
                    if (position.selectedItem.toString()=="Капитан" && player.position=="К"
                        && player.position!=curPlayer.position){

                        Toast.makeText(
                            this@AddTeamActivity,
                            "Нельзя назначить больше 1 капитана!", Toast.LENGTH_SHORT).show()
                        return false
                    }
                    if (countLibero==2 && position.selectedItem.toString()=="Либеро" && player.position=="Л"
                        && player.position!=curPlayer.position){

                        Toast.makeText(
                            this@AddTeamActivity,
                            "Нельзя назначить больше 2 либеро!", Toast.LENGTH_SHORT).show()
                        return false
                    }
                }
                else{
                    if (player.numPlayer==etPlayerNum.text.toString().toInt() && player.numPlayer!=curPlayer.numPlayer){
                        Toast.makeText(
                            this@AddTeamActivity,
                            "Игровые номера индивидуальны!", Toast.LENGTH_SHORT).show()
                        return false
                    }
                    if (position.selectedItem.toString()=="Капитан" && player.position=="К"){
                        Toast.makeText(
                            this@AddTeamActivity,
                            "Нельзя назначить больше 1 капитана!", Toast.LENGTH_SHORT).show()
                        return false
                    }
                    if (countLibero==2 && position.selectedItem.toString()=="Либеро" && player.position=="Л"){

                        Toast.makeText(
                            this@AddTeamActivity,
                            "Нельзя назначить больше 2 либеро!", Toast.LENGTH_SHORT).show()
                        return false
                    }
                }

            }
        }
        return true
    }
    fun isCyrillic(s: String): Boolean {
        for (a in s.toCharArray()) {
            if (Character.UnicodeBlock.of(a) != Character.UnicodeBlock.CYRILLIC)
                return false
        }
        return true
    }

    private fun createRowPlayer(player: Player): TableRow {
        var row=TableRow(this)

        var tvNum=TextView(this)
        tvNum.text = player.numPlayer.toString()
        //tvNum.layoutParams = marginView()
        var tvFIO=TextView(this)
        tvFIO.text = player.fio
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT)
        params.setMargins(5,5,5,5)
        //tvFIO.layoutParams = params
        var tvPos=TextView(this)
        tvPos.text = player.position.toString()
        //tvPos.layoutParams = marginView()

        var btnEdit = AppCompatButton(this)
        btnEdit.text = "Изм"
        btnEdit.setOnClickListener {
            llAddPlayer.visibility = View.VISIBLE
            btnUpdatePlayer.visibility = View.VISIBLE
            btnAddPlayer.visibility = View.GONE


            etPlayerNum.setText(player.numPlayer.toString())
            etLastname.setText(player.lastname)
            etFirstname.setText(player.firstname)
            etPatronymic.setText(player.patronymic)
            //задать позицию
            position.getChildAt(adapter.getPosition(player.position.toString()))
            curPlayer = player
        }
        //btnEdit.layoutParams = marginView()

        var btnDelete = AppCompatButton(this)
        btnDelete.text = "X"
        btnDelete.setOnClickListener {
            tablePlayers.removeView(row)
        }
        //btnDelete. = marginView()
        row.addView(tvNum, 0)
        row.addView(tvFIO, 1)
        row.addView(tvPos, 2)
        row.addView(btnEdit, 3)
        row.addView(btnDelete, 4)
        row.layoutParams = marginRow()
        row[0].layoutParams = marginView()
        row[1].layoutParams = marginView()
        row[2].layoutParams = marginView()
        row[3].layoutParams = marginButton()
        row[4].layoutParams = marginButton()

        return row

    }

    private fun createRow0(): View {

        var row=TableRow(this)
        var tv=TextView(this)
        tv.layoutParams = marginView()
        tv.text = "№"
        var tv1=TextView(this)
        tv1.layoutParams = marginView()
        tv1.text = "ФИО"
        var tv2=TextView(this)
        tv2.layoutParams = marginView()
        tv2.text = "Поз."
        var tv3=TextView(this)
        tv3.layoutParams = marginView()
        var tv4=TextView(this)
        tv4.layoutParams = marginView()

        row.addView(tv, 0)
        row.addView(tv1, 1)
        row.addView(tv2, 2)
        row.addView(tv3, 3)
        row.addView(tv4, 4)
        row.layoutParams = marginRow()
        return row
    }
    private fun marginView(): TableRow.LayoutParams {
        val params = TableRow.LayoutParams(
            TableRow.LayoutParams.WRAP_CONTENT,
            TableRow.LayoutParams.WRAP_CONTENT, 1F
        )
        return params;
    }
    private fun marginButton(): TableRow.LayoutParams {
        val params = TableRow.LayoutParams(70,
            70, 1F
        )
        return params;
    }
    private fun marginRow(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
            TableLayout.LayoutParams.WRAP_CONTENT,
            TableLayout.LayoutParams.WRAP_CONTENT
        );
    }


}
