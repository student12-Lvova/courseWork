package com.example.pr1_mp.team

import android.content.ContentValues
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.get
import com.example.pr1_mp.AddStaffTrainers
import com.example.pr1_mp.CreateMatchActivity
import com.example.pr1_mp.R
import com.example.pr1_mp.TeamsUserActivity
import com.example.pr1_mp.connectdb.WorkMyDB
import com.example.pr1_mp.models.CurrentPlayer
import com.example.pr1_mp.models.Player
import com.example.pr1_mp.models.Team

//изменение команды в бд
//можем изменить все что угодно
class EditTeamActivity : AppCompatActivity() {

    //
    private lateinit var textPlayerNum: TextView
    private lateinit var textAdressTeam: TextView
    private lateinit var etPlayerNum: EditText
    private lateinit var etLastname: EditText
    private lateinit var etFirstname: EditText
    private lateinit var etPatronymic: EditText
    private lateinit var position: Spinner
    private lateinit var tablePlayers: TableLayout
    private lateinit var btnLL: AppCompatButton
    private lateinit var btnAddPlayer: AppCompatButton
    private lateinit var btnEditTeam: AppCompatButton
    private lateinit var llAddPlayer: LinearLayout
    private lateinit var btnUpdatePlayer: AppCompatButton
    private lateinit var btnAddStaff: AppCompatButton

    lateinit var workMyDB: WorkMyDB
    private var idTeam:Long = -1
    private lateinit var team: Team
    private var listPlayers:MutableList<Player> = listOf<Player>().toMutableList()
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var curPlayer: Player


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_team)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        workMyDB = WorkMyDB(this)

        val extras = intent.extras
        if (extras != null && extras.getLong("idTeam") > 0) {
            idTeam = extras.getLong("idTeam")
            team = workMyDB.selectTeambyId(idTeam.toInt())
        }

        listPlayers = if (idTeam > 0) {
            workMyDB.selectPlayersByIdTeam(idTeam.toInt())
        } else
            listOf<Player>().toMutableList()

        initComponents()
        fillField()
        onClickListener()
    }
    private fun initComponents() {
        //поля для заполнения
        textPlayerNum = findViewById(R.id.editNameTeam)
        textAdressTeam = findViewById(R.id.editAddress)
        etLastname = findViewById(R.id.editLastnameM)
        etFirstname = findViewById(R.id.edit_firstname)
        etPatronymic = findViewById(R.id.edit_patronymic)
        etPlayerNum = findViewById(R.id.et_PlayerNum)
        position = findViewById(R.id.spinnerPosition)

        //кнопка добавления игрока
        llAddPlayer = findViewById(R.id.llEditPlayer)
        llAddPlayer.visibility = View.GONE
        btnUpdatePlayer = findViewById(R.id.bUpdatePlayer)
        btnUpdatePlayer.visibility = View.GONE
        btnAddPlayer = findViewById(R.id.bAddPlayer2)
        btnAddPlayer.visibility = View.GONE
        tablePlayers = findViewById(R.id.tablePlayers)

        //поля для редактирования и добавления
        btnLL = findViewById(R.id.bAddPlayer)

        btnEditTeam = findViewById(R.id.btnEditTeam)
        btnAddStaff = findViewById(R.id.btnEditStaffTrainers)

    }
    private fun checkField(): Boolean {
        if (textPlayerNum.text.toString()==""){
            Toast.makeText(this@EditTeamActivity,
                "Добавите название команды!", Toast.LENGTH_SHORT).show()
            return false
        }
        if (textAdressTeam.text.toString()==""){
            Toast.makeText(this@EditTeamActivity,
                "Добавите адрес команды!", Toast.LENGTH_SHORT).show()
            return false
        }
        return true

    }
    private fun fillField() {
        //заполняем поле с названием команды
        if (idTeam>0) {
            textPlayerNum.setText(team.name)
            textAdressTeam.text = team.address
        }

        //заполняем spinner
        adapter =  ArrayAdapter(this,
            android.R.layout.simple_spinner_item, arrayListOf("Игрок", "Капитан","Либеро"))
        position.adapter = adapter

        //заполняем таблицу с игроками
        //tablePlayers.removeView(0)
        tablePlayers.addView(createRow0(), 0)
        if (listPlayers.size!=0){
            for (player in listPlayers)
                tablePlayers.addView(createRowPlayer(player))
        }
    }
    private fun onClickListener() {

        tablePlayers.setOnClickListener{
            llAddPlayer.visibility = View.GONE
            btnUpdatePlayer.visibility = View.GONE
            btnAddPlayer.visibility = View.GONE
        }

        btnLL.setOnClickListener {
            llAddPlayer.visibility = View.VISIBLE
            btnAddPlayer.visibility = View.VISIBLE
            btnUpdatePlayer.visibility = View.GONE

            etLastname.setText("")
            etFirstname.setText("")
            etPatronymic.setText("")
            etPlayerNum.setText("")

            curPlayer = Player()
        }

        //проверка полей
        btnAddPlayer.setOnClickListener {
            //проверка на поля
            if (checkInfPlayer()){
                var player = Player(0,idTeam,etLastname.text.toString(), etFirstname.text.toString(),
                    etPatronymic.text.toString(), etPlayerNum.text.toString().toInt(),
                    position.selectedItem.toString().toCharArray()[0].toString() )

                listPlayers.add(player)

                tablePlayers.addView(createRowPlayer(player))
            }
        }

        btnUpdatePlayer.setOnClickListener {
            if (checkInfPlayer()) {
                curPlayer.lastname = etLastname.text.toString()
                curPlayer.firstname = etFirstname.text.toString()
                curPlayer.patronymic = etPatronymic.text.toString()
                curPlayer.numPlayer = etPlayerNum.text.toString().toInt()
                curPlayer.position = position.selectedItem.toString().toCharArray()[0].toString()

                for (player in listPlayers) {
                    if (player.id == curPlayer.id) {
                        var index = listPlayers.indexOf(player)
                        listPlayers.removeAt(index)
                        listPlayers.add(index, curPlayer)
                        break
                    }
                }

                tablePlayers.removeAllViews()
                tablePlayers.addView(createRow0())
                for (player in listPlayers)
                    tablePlayers.addView(createRowPlayer(player), listPlayers.indexOf(player)+1)
            }

        }

        position.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, view: View?,
                                        pos: Int, id: Long) {
                var ch:Char = adapter.getItem(pos).toString().toCharArray()[0]
                var countLibero = 0
                for (player in listPlayers){
                    if (player.position.toCharArray()[0] == ch && player.position.toCharArray()[0]=='К'){
                        Toast.makeText(this@EditTeamActivity,
                            "Капитан команды уже назначен", Toast.LENGTH_SHORT).show()
                        position.setSelection(adapter.getPosition(curPlayer.position.toString()))
                    }
                    if (player.position.toCharArray()[0] =='Л'){
                        if (countLibero<2)
                            countLibero++
                        else{
                            Toast.makeText(this@EditTeamActivity,
                                "Вы не можете назначить больше 2 либеро в команде!", Toast.LENGTH_SHORT).show()
                            position.setSelection(adapter.getPosition(curPlayer.position.toString()))
                        }
                    }

                }


                if (curPlayer!=null)
                    curPlayer.position = ch.toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // write code to perform some action
            }
        }

        btnAddStaff.setOnClickListener{
            val intent = Intent(this@EditTeamActivity, AddStaffTrainers::class.java)
            intent.putExtra("type", "edit")
            var id = idTeam
            intent.putExtra("idTeam", idTeam.toInt())
            startActivity(intent)
        }

        btnEditTeam.setOnClickListener{
            if (checkField()){
                if (listPlayers.size in 6..14){
                    var list: MutableList<Player> = listOf<Player>().toMutableList()

                    for (player in listPlayers) {
                        list.add(player)
                    }

                    var cvPlayers = listOf<ContentValues>().toMutableList()
                    for (curPlayer in list){
                        var contentValues = ContentValues()
                        if (curPlayer.id>0)
                            contentValues.put("id", curPlayer.id);
                        contentValues.put("idTeam", idTeam)
                        contentValues.put("lastname", curPlayer.lastname)
                        contentValues.put("firstname", curPlayer.firstname)
                        contentValues.put("patronymic", curPlayer.patronymic)
                        contentValues.put("numPlayer", curPlayer.numPlayer)
                        contentValues.put("position", curPlayer.position)

                        cvPlayers.add(contentValues)
                    }
                    var contentValues = ContentValues()
                    contentValues.put("id", idTeam)
                    contentValues.put("name", textPlayerNum.text.toString())
                    contentValues.put("address", textAdressTeam.text.toString())

                    workMyDB.updateTeam(contentValues, cvPlayers)

                    val intent = Intent(this@EditTeamActivity, TeamsUserActivity::class.java)
                    intent.putExtra("idTeam", workMyDB.selectTeamLastId())
                    startActivity(intent)
                }
                else
                    Toast.makeText(this@EditTeamActivity,
                        "Кол-во игроков < 6 или > 14!", Toast.LENGTH_SHORT).show()
            }

        }
    }

    fun isCyrillic(s: String): Boolean {
        for (a in s.toCharArray()) {
            if (Character.UnicodeBlock.of(a) != Character.UnicodeBlock.CYRILLIC)
                return false
        }
        return true
    }
    private fun checkInfPlayer():Boolean {
        var lastname = etLastname.text
        var firstname = etFirstname.text
        var patronymic = etPatronymic.text

        if (lastname.isEmpty() || !isCyrillic(lastname.toString())) {
            Toast.makeText(applicationContext, "Ошибка ввода фамилии", Toast.LENGTH_SHORT).show()
            etLastname.setBackgroundColor(Color.RED)
            return false
        }
        if (firstname.isEmpty() || !isCyrillic(firstname.toString())) {
            Toast.makeText(applicationContext, "Ошибка ввода имени", Toast.LENGTH_SHORT).show()
            etFirstname.setBackgroundColor(Color.RED)
            return false
        }
        if (patronymic.isNotEmpty() && !isCyrillic(patronymic.toString())) {
            Toast.makeText(applicationContext, "Ошибка ввода отчества", Toast.LENGTH_SHORT).show()
            etPatronymic.setBackgroundColor(Color.RED)
            return false
        }
        if (etPlayerNum.text.toString()=="") {
            Toast.makeText(applicationContext,"Введите игровой номер игрока",
                Toast.LENGTH_SHORT).show()
            return false
        }
        else{
            var countLibero=0
            for (player in listPlayers) if (player.position=="Л") countLibero++
            for (player in listPlayers){
                if (curPlayer!=null){
                    if (player.numPlayer==etPlayerNum.text.toString().toInt()
                        && player.numPlayer!=curPlayer.numPlayer){//

                        Toast.makeText(applicationContext,"Игровые номера индивидуальны!",
                            Toast.LENGTH_SHORT).show()
                        return false
                    }
                    if (position.selectedItem.toString()=="Капитан" && player.position=="К"
                        && player.position!=curPlayer.position){

                        Toast.makeText(applicationContext,"Нельзя назначить больше 1 капитана!",
                            Toast.LENGTH_SHORT).show()
                        return false
                    }
                    if (countLibero==2 && position.selectedItem.toString()=="Либеро"
                        && player.position=="Л" && player.position!=curPlayer.position){

                        Toast.makeText(applicationContext,"Нельзя назначить больше 2 либеро!",
                            Toast.LENGTH_SHORT).show()
                        return false
                    }
                }
                else{
                    if (player.numPlayer==etPlayerNum.text.toString().toInt() &&
                        player.numPlayer!=curPlayer.numPlayer){
                        Toast.makeText(applicationContext,"Игровые номера индивидуальны!",
                            Toast.LENGTH_SHORT).show()
                        return false
                    }
                    if (position.selectedItem.toString()=="Капитан" && player.position=="К"){
                        Toast.makeText(applicationContext,"Нельзя назначить больше 1 капитана!",
                            Toast.LENGTH_SHORT).show()
                        return false
                    }
                    if (countLibero==2 && position.selectedItem.toString()=="Либеро" &&
                        player.position=="Л"){

                        Toast.makeText(applicationContext,"Нельзя назначить больше 2 либеро!",
                            Toast.LENGTH_SHORT).show()
                        return false
                    }
                }

            }
        }
        return true
    }
    private fun createRowPlayer(player: Player): TableRow {
        var row= TableRow(this)

        var tvNum= TextView(this)
        tvNum.text = player.numPlayer.toString()
        //tvNum.layoutParams = marginView()
        var tvFIO= TextView(this)
        tvFIO.text = player.fio
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT)
        params.setMargins(5,5,5,5)
        //tvFIO.layoutParams = params
        var tvPos= TextView(this)
        tvPos.text = player.position.toString()
        //tvPos.layoutParams = marginView()

        var btnEdit = AppCompatButton(this)
        btnEdit.text = "Изм"
        btnEdit.setOnClickListener {
            llAddPlayer.visibility = View.VISIBLE
            btnUpdatePlayer.visibility = View.VISIBLE
            btnAddPlayer.visibility = View.GONE

            curPlayer = player
            etPlayerNum.setText(player.numPlayer.toString())
            etLastname.setText(player.lastname)
            etFirstname.setText(player.firstname)
            etPatronymic.setText(player.patronymic)
            //задать позицию
            position.getChildAt(adapter.getPosition(player.position.toString()))
        }
        //btnEdit.layoutParams = marginView()

        var btnDelete = AppCompatButton(this)
        btnDelete.text = "X"
        btnDelete.setOnClickListener {
            tablePlayers.removeView(row)
        }
        //btnDelete. = marginView()
        row.addView(tvNum, 0)
        row.addView(tvFIO, 1)
        row.addView(tvPos, 2)
        row.addView(btnEdit, 3)
        row.addView(btnDelete, 4)
        row.layoutParams = marginRow()
        row[0].layoutParams = marginView()
        row[1].layoutParams = marginView()
        row[2].layoutParams = marginView()
        row[3].layoutParams = marginButton()
        row[4].layoutParams = marginButton()

        return row

    }
    private fun createRow0(): View {

        var row= TableRow(this)
        var tv= TextView(this)
        tv.layoutParams = marginView()
        tv.text = "№"
        var tv1= TextView(this)
        tv1.layoutParams = marginView()
        tv1.text = "ФИО"
        var tv2= TextView(this)
        tv2.layoutParams = marginView()
        tv2.text = "Поз."
        var tv3= TextView(this)
        tv3.layoutParams = marginView()
        var tv4= TextView(this)
        tv4.layoutParams = marginView()

        row.addView(tv, 0)
        row.addView(tv1, 1)
        row.addView(tv2, 2)
        row.addView(tv3, 3)
        row.addView(tv4, 4)
        row.layoutParams = marginRow()
        return row
    }

    private fun marginView(): TableRow.LayoutParams {
        val params = TableRow.LayoutParams(
            TableRow.LayoutParams.WRAP_CONTENT,
            TableRow.LayoutParams.WRAP_CONTENT, 1F
        )
        return params;
    }
    private fun marginButton(): TableRow.LayoutParams {
        val params = TableRow.LayoutParams(70,
            70, 1F
        )
        return params;
    }
    private fun marginRow(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
            TableLayout.LayoutParams.WRAP_CONTENT,
            TableLayout.LayoutParams.WRAP_CONTENT
        );
    }

}