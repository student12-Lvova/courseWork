package com.example.lb61.dto;

import com.example.lb61.models.teamsandplayers.Team;
import com.example.lb61.models.user.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class MatchDto {
    public int id;
    public String nameMatch;
    public String description;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    public LocalDate dateMatch;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    public LocalDate now = LocalDate.now();

    public Team team1;
    public Team team2;
    public int team1id;
    public int team2id;
    public User user;
}
