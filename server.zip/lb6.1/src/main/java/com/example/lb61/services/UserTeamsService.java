package com.example.lb61.services;

import com.example.lb61.models.livematches.Translation;
import com.example.lb61.models.teamsandplayers.Matches;
import com.example.lb61.models.teamsandplayers.Player;
import com.example.lb61.models.teamsandplayers.Team;
import com.example.lb61.models.user.User;
import com.example.lb61.repositopies.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UserTeamsService  {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private MatchRepository matchRepository;
    @Autowired
    private TeamRepository teamRepository;
    @Autowired
    private PlayerRepository playerRepository;
    @Autowired
    private TransactionRepository transactionRepository;

    public List<Matches> getListMatchesByIdUser(long id) {
        return matchRepository.findByUser(userRepository.findById((int)id).get());
    }
    public List<Team> getListTeamsByIdUser(long id) {
        return teamRepository.findByUser(userRepository.findById((int)id).get());
    }
    public List<Translation> getAllTranslation() {
        List<Translation> translations = new ArrayList<>();
        transactionRepository.findAll().forEach(translation ->
                translations.add(translation));
        return translations;
    }
    public List<Matches> getAllMatches() {
        List<Matches> matches = new ArrayList<>();
        matchRepository.findAll().forEach(match ->
                matches.add(match));
        return matches;
    }
    public Translation getTranslationById(int id) {
        if (!transactionRepository.findById(id).isEmpty())
        return transactionRepository.findById(id).get();
        return null;
    }
    public Team getTeamById(int id) {
        return teamRepository.findById(id).get();
    }
    public int saveTranslation(Translation translation) {
            try{
                return transactionRepository.save(translation).getId();
            }catch (Exception e){
                return -1;
            }
    }
    public int updateTranslation(Translation translation) {
        if (!transactionRepository.findById(translation.getId()).isEmpty()){
            try{
                return transactionRepository.save(translation).getId();
            }catch (Exception e){
                return -1;
            }
        }
        return -1;
    }

    public void deleteTranslationById(int id){
        transactionRepository.deleteById(id);
    }
    public void deletePlayerById(int id){
        playerRepository.deleteById(id);
    }
    public String deleteTeamById(int id){
        List<Team> teams = new ArrayList<>();
        teams.add(teamRepository.findById(id).get());
        if(matchRepository.findByTeam(teamRepository.findById(id).get()).isEmpty()){
            playerRepository.deleteByTeam(teamRepository.findById(id).get());
            teamRepository.delete(teamRepository.findById(id).get());
        }else{
            return "Удаление не возможно";
        }
        return "";
    }
    public Player addPlayer(Player player){
        return playerRepository.save(player);
    }

    public List<Player> getListPlayersByIdUser(long id) {
        List<Player> listPlayer = new ArrayList<>();
        teamRepository.findByUser(userRepository.findById((int)id).get()).forEach(team ->{
            playerRepository.findByTeam(team).forEach(player -> {
                listPlayer.add(player);
            });
        }
        );
        return listPlayer;

    }
    public List<Player> getListPlayersByTeam(Team team) {
        return playerRepository.findByTeam(team);

    }

    public List<Translation> getListTranslationsByIdUser(User user) {
        return transactionRepository.findByUser(user).get();
    }

    public Team saveTeam(Team team) {
        return teamRepository.save(team);
    }

    public Matches saveMatch(Matches match) {
        return matchRepository.save(match);
    }

    public void deleteMatchById(int id) {
        matchRepository.deleteById(id);
    }


    public List<Team> getTeamsByMatch(Matches match) {
        return teamRepository.findByMatch(match);
    }

    public Matches getMatchById(int id) {
        return matchRepository.findById(id).get();
    }

    public void deleteMatch(Matches matches) {
        matchRepository.delete(matches);
    }

    public void deleteTranslationByUser(User user) {
        transactionRepository.deleteByUser(user);
    }

    public void deleteTeamByUser(User user) {
        List<Team> teams = teamRepository.findByUser(user);
        teams.forEach(team -> {
            playerRepository.deleteByTeam(teamRepository.findById(team.getId()).get());
        });
        matchRepository.findByUser(user).forEach(matches -> {
            deleteMatch(matches);
        });
        teams.forEach(team -> {
            teamRepository.delete(team);
        });


    }

    public Boolean checkTeamForDelete(Team team) {
        return matchRepository.findByTeam(team).isEmpty();
    }
}
