package com.example.lb61.controllers;

import com.example.lb61.dto.MatchDto;
import com.example.lb61.dto.ProfileDto;
import com.example.lb61.models.teamsandplayers.Matches;
import com.example.lb61.models.teamsandplayers.Team;
import com.example.lb61.models.user.Role;
import com.example.lb61.models.user.User;
import com.example.lb61.services.UserService;
import com.example.lb61.services.UserTeamsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.core.userdetails.memory.UserAttribute;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    UserService userService;
    @Autowired
    UserTeamsService service;

    private Model setModelsForTeams(Model model, User user, Team newTeam, MatchDto newMatch){
        List<Team> teams = new ArrayList<>();
        service.getListTeamsByIdUser(user.getId()).forEach(team -> {
            if (service.getListPlayersByTeam(team).size()>=6)
                teams.add(team);
        });
        model.addAttribute("teamsDto", teams);
        model.addAttribute("teams", service.getListTeamsByIdUser(user.getId()));
        model.addAttribute("newTeam", newTeam);

        List<Matches> matches = service.getListMatchesByIdUser(user.getId());
        model.addAttribute("newMatch", newMatch);

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US);
        List<Matches> indexs = new ArrayList<>();
        List<MatchDto> calendar = new ArrayList<>();
        if (!matches.isEmpty())
            matches.forEach(match ->{
                LocalDate dateTime = LocalDate.parse(match.getDateMatch(), dtf);
                if (match.isFlagCalendar()){
                    if (!match.getTeams().isEmpty()){
                        MatchDto md = new MatchDto(match.getId(), match.getNameMatch(), match.getDescription(),
                                dateTime, LocalDate.now(),
                                match.getTeams().get(0), match.getTeams().get(1), match.getTeams().get(0).getId(),
                                match.getTeams().get(1).getId(), match.getUser());
                        calendar.add(md);
                        indexs.add(match);
                    }
                }
            } );
        indexs.forEach(index ->
                matches.remove(index)
        );
        model.addAttribute("calendar", calendar);
        model.addAttribute("matches", matches);

        ProfileDto pd = new ProfileDto(user.getId(), user.getLogin(), "", user.getEmail(), "");
        model.addAttribute("user", pd);
        model.addAttribute("role", user.getRole().name());

        return model;
    }

    @GetMapping("/users")
    public String users(Model model, Principal principal){
        if (userService.getUserByLogin(principal.getName()).getRole()== Role.ADMIN){
            model.addAttribute("users", userService.getAllUsers());
            model.addAttribute("role", userService.getUserByLogin(principal.getName()).getRole().name());
            return "/admin/users";
        }else{
            return "home";
        }

    }
    ///admin/users/delete/
    @GetMapping("/users/delete/{id}")
    public String delete(@PathVariable long id, Model model, Principal principal){
        if (userService.getUserByLogin(principal.getName()).getRole()== Role.ADMIN){
            userService.deleteUserById(id);
            model.addAttribute("users", userService.getAllUsers());
            model.addAttribute("role", userService.getUserByLogin(principal.getName()).getRole().name());
            return "/admin/users";
        }else{
            return "home";
        }

    }
    @GetMapping("/translations/delete/{id}")
    public String translationDelete(@PathVariable int id, Model model, Principal principal, HttpServletRequest request){
            service.deleteTranslationById(id);
            model = setModelsForTeams(model, userService.getUserByLogin(principal.getName()), new Team(), new MatchDto());
            model.addAttribute("translations", service.getListTranslationsByIdUser(userService.getUserByLogin(principal.getName())));
            return "redirect:/translations";
    }
}
