package com.example.lb61.repositopies;

import com.example.lb61.models.teamsandplayers.Matches;
import com.example.lb61.models.teamsandplayers.Team;
import com.example.lb61.models.user.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TeamRepository extends CrudRepository<Team, Integer> {
    List<Team> findByUser(User user);

    List<Team> findByMatch(Matches match);
}
