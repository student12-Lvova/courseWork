package com.example.lb61.models.teamsandplayers;

import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.*;
import lombok.Data;
import lombok.ToString;

@Data
public class Representative {
    private String fio;
    private String email;
}
