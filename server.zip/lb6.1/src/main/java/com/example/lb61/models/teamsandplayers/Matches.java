package com.example.lb61.models.teamsandplayers;

import javax.persistence.*;

import com.example.lb61.models.user.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.ToString;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
public class Matches {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nameMatch;
    private String description;
    private String dateMatch;
    private boolean flagCalendar;
    @ManyToOne(fetch = FetchType.LAZY)
    private User user;
    @ToString.Exclude
    @ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinTable(name = "team_match",
            joinColumns = @JoinColumn(name = "match_id", referencedColumnName = "id"),
            inverseJoinColumns = @JoinColumn(name = "team_id",
                    referencedColumnName = "id"))
    private List<Team> team;
    public void setMatch(String name, String description, LocalDate date, User user, Team team1, Team team2){
        this.nameMatch = name;
        this.description = description;
        this.dateMatch = date.toString();
        team = new ArrayList<Team>();
        team.add(team1);
        team.add(team2);
        this.user = user;
        flagCalendar = false;
    }
    public void setCalendarMatch(String name, String description, LocalDate date, User user, Team team1, Team team2){
        this.nameMatch = name;
        this.description = description;
        this.dateMatch = date.toString();
        team = new ArrayList<Team>();
        team.add(team1);
        team.add(team2);
        this.user = user;
        flagCalendar = true;
    }

    public List<Team> getTeams() {
        return team;
    }

    public void setTeams(ArrayList<Team> teams) {
        this.team = teams;
    }
}
