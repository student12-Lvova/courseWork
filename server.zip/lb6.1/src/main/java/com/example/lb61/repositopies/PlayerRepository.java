package com.example.lb61.repositopies;

import com.example.lb61.models.teamsandplayers.Player;
import com.example.lb61.models.teamsandplayers.Team;
import com.example.lb61.models.user.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface PlayerRepository extends CrudRepository<Player, Integer> {
    List<Player> findByTeam(Team team);
    @Transactional
    void deleteByTeam(Team team);

}
