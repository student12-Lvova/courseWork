package com.example.lb61.models.user;

public enum Role {
    USER, ADMIN
}
