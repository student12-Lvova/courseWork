package com.example.lb61.timeDependent;

public interface CalendarMatch {
    public void checkCalendarMatch();
}
