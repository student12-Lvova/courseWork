package com.example.lb61.controllers;

import com.example.lb61.dto.DeleteTeamDto;
import com.example.lb61.dto.MatchDto;
import com.example.lb61.dto.ProfileDto;
import com.example.lb61.errors.ErrorTeam;
import com.example.lb61.models.PositionsPlayers;
import com.example.lb61.models.teamsandplayers.Matches;
import com.example.lb61.models.teamsandplayers.Player;
import com.example.lb61.models.teamsandplayers.Team;
import com.example.lb61.models.user.User;
import com.example.lb61.services.UserService;
import com.example.lb61.services.UserTeamsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Controller
@RequiredArgsConstructor
@RequestMapping("/user")
@PreAuthorize("hasAuthority('USER')")
public class UserController {
    @Autowired
    UserService userService;
    @Autowired
    UserTeamsService teamsService;
    //ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ

    private boolean checkUserForTeam(User user, int idTeam){
        return teamsService.getTeamById(idTeam).getUser()==user;
    }
    private boolean checkUserForMatch(User user, int idMatch){
        return teamsService.getMatchById(idMatch).getUser()==user;
    }
    private boolean checkUserForTransl(User user, int idTransl){
        return teamsService.getTranslationById(idTransl).getUser()==user;
    }
    private Model setModelsForTeams(Model model, User user, Team newTeam, MatchDto newMatch){
        List<Team> teams = new ArrayList<>();
        List<DeleteTeamDto> teamsDelete = new ArrayList<>();
        List<Team> allteams =  teamsService.getListTeamsByIdUser(user.getId());
        allteams.forEach(team -> {
            if (teamsService.getListPlayersByTeam(team).size()>=6) {
                teams.add(team);
            }
            teamsDelete.add(new DeleteTeamDto(team, teamsService.checkTeamForDelete(team)));
        });
        model.addAttribute("teamsDto", teams);
        model.addAttribute("teams", teamsDelete);
        model.addAttribute("newTeam", newTeam);

        List<Matches> matches = teamsService.getListMatchesByIdUser(user.getId());
        model.addAttribute("newMatch", newMatch);

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US);
        List<Matches> indexs = new ArrayList<>();
        List<MatchDto> calendar = new ArrayList<>();
        if (!matches.isEmpty())
            matches.forEach(match ->{
                LocalDate dateTime = LocalDate.parse(match.getDateMatch(), dtf);
                if (match.isFlagCalendar()){
                    if (!match.getTeams().isEmpty()){
                        MatchDto md = new MatchDto(match.getId(), match.getNameMatch(), match.getDescription(),
                                dateTime, LocalDate.now(),
                                match.getTeams().get(0), match.getTeams().get(1), match.getTeams().get(0).getId(),
                                match.getTeams().get(1).getId(), match.getUser());
                        calendar.add(md);
                        indexs.add(match);
                    }
                }
            } );
        indexs.forEach(index ->
                matches.remove(index)
        );
        model.addAttribute("calendar", calendar);
        model.addAttribute("matches", matches);

        ProfileDto pd = new ProfileDto(user.getId(), user.getLogin(), "", user.getEmail(), "");
        model.addAttribute("user", pd);
        model.addAttribute("role", user.getRole().name());

        return model;
    }
    private boolean chekNameTeam(String nameTeam) {
        if (nameTeam.equals("")) return false;
        else return true;
    }
    private boolean chekNumberPlayer(Team team, int number) {
        final boolean[] flag = {false};
        teamsService.getListPlayersByTeam(team).forEach(player -> {
            flag[0] = player.getNumber()==number;
        });
        return !flag[0];
    }
    private boolean checkPosition(Team team, String position) {
        if (position.equals("И")) return true;
        final int[] countLibero = {0};
        teamsService.getListPlayersByTeam(team).forEach(player -> {
            if (player.getPosition().equals("Л"))
                countLibero[0]++;
        });
        if (countLibero[0] >=2) return false;
        else return true;
    }
    private boolean chekNamePlayer(String namePlayer) {
        if (namePlayer.equals("")) return false;
        else return true;
    }
    private boolean chekDateToMatch(LocalDate dateMatch) {
        if (dateMatch!=null && dateMatch.isAfter(LocalDate.now())){
            return true;
        }
        return false;
    }
    private ArrayList<Player> getrlayers(List<Player> listPlayersByTeam, Player newPlayer) {
        boolean flag = false;
        ArrayList<Player> players = new ArrayList<>();
        if (newPlayer!=null)
            if (newPlayer.isCaptain()){
                listPlayersByTeam.forEach(player -> {
                    player.setCaptain(false);
                    players.add(player);
                });
            }
        if (players.size()!=0)
            return players;
        else return new ArrayList<>(listPlayersByTeam);
    }

    //ТРАНСЛЯЦИИ========================================================================================================

    //---------- из profile ВЫБОР ТРАНСЛЯЦИИ ---------------------------------------------
    @GetMapping("/translations/{id}")
    public String translation(@PathVariable int id, Model model, Principal principal, HttpServletRequest request){
        User user = userService.getUserByLogin(principal.getName());
        if (checkUserForTransl(user, id)){
            model.addAttribute("translation", teamsService.getTranslationById(id));
            model.addAttribute("role", user.getRole());
            return "/user/translations";
        }
        return "redirect:/";
    }

    //--------- из профиля УДАЛЕНИЕ ТРАНСЛЯЦИИ -------------------------------------------------
    @GetMapping("/translations/delete/{id}")
    public String translationDelete(@PathVariable int id, Model model, Principal principal, HttpServletRequest request){
        if (checkUserForTransl(userService.getUserByLogin(principal.getName()), id)) {
            teamsService.deleteTranslationById(id);
            model = setModelsForTeams(model, userService.getUserByLogin(principal.getName()), new Team(), new MatchDto());
            model.addAttribute("translations", teamsService.getListTranslationsByIdUser(userService.getUserByLogin(principal.getName())));
            return "/profile";
        }else return "redirect:/";
    }

    //ОБЩИЕ С ПРОФИЛЯ===================================================================================================
    //--------- из профиля КОМАНДЫ И МАТЧИ ---------------------
    @GetMapping("/teams")
    public String teams(Model model, Principal principal){
        User user = userService.getUserByLogin(principal.getName());
        model = setModelsForTeams(model, user, new Team(), new MatchDto());

        return "/user/teams";
    }

    //КОМАНДЫ===========================================================================================================
    //--------- ВЫБРАНА КОМАНДА --------------------------------------------------
    @GetMapping("/teams/infteam/{id}")
    public String team(@PathVariable int id,Model model, Principal principal, HttpServletRequest request){
        User user = userService.getUserByLogin(principal.getName());
        if (checkUserForTeam(user, id)) {
            Team team = teamsService.getTeamById(id);
            model.addAttribute("team", team);
            model.addAttribute("newPlayer", new Player());

            model.addAttribute("players", teamsService.getListPlayersByTeam(team));
            Player player = new Player();
            player.setTeam(team);
            final int[] countLibero = {0};
            teamsService.getListPlayersByTeam(team).forEach(pl -> {
                if (pl.getPosition().equals('Л'))
                    countLibero[0]++;
            });
            List<PositionsPlayers> positionsPlayers = new ArrayList<>();
            positionsPlayers.add(new PositionsPlayers("И","Игрок"));
            if (countLibero[0]<2)
                positionsPlayers.add(new PositionsPlayers("Л","Либеро"));
            model.addAttribute("positionList", positionsPlayers);

            return "/user/teams/infteam";
        }else return "home";
    }
    @PostMapping("/teams/infteam/{id}")
    public String teamSave(@PathVariable int id, Model model, Principal principal,
                           @ModelAttribute("team") Team team, HttpServletRequest request){
        User user = userService.getUserByLogin(principal.getName());
        if (checkUserForTeam(user, id)) {
            List<PositionsPlayers> positionsPlayers = new ArrayList<>();
            final int[] countLibero = {0};
            boolean flagCaptain = false;
            team.setUser(userService.getUserByLogin(principal.getName()));
            if (chekNameTeam(team.getNameTeam())){
                if (chekNameTeam(team.getFio())){
                    team = teamsService.saveTeam(team);
                    model.addAttribute("team", team);
                    model.addAttribute("players", teamsService.getListPlayersByTeam(team));
                    teamsService.getListPlayersByTeam(team).forEach(player -> {
                        if (player.getPosition().equals("Л"))
                            countLibero[0]++;
                    });
                }else{
                    model.addAttribute(ErrorTeam.ErrorTeamFIO.name(), "Обязательное поле!");
                    model.addAttribute("team", team);
                    model.addAttribute("players", teamsService.getListPlayersByTeam(team));
                    teamsService.getListPlayersByTeam(team).forEach(player -> {
                        if (player.getPosition().equals("Л"))
                            countLibero[0]++;
                    });
                }
            }else{
                model.addAttribute(ErrorTeam.ErrorTeamName.name(), "Обязательное поле!");
                model.addAttribute("team", team);
                ArrayList<Player> players = getrlayers(teamsService.getListPlayersByTeam(team), null);
                model.addAttribute("players", players);
                teamsService.getListPlayersByTeam(team).forEach(player -> {
                    if (player.getPosition().equals("Л"))
                        countLibero[0]++;
                });
            }
            positionsPlayers.add(new PositionsPlayers("И","Игрок"));
            if (countLibero[0]<2)
                positionsPlayers.add(new PositionsPlayers("Л","Либеро"));
            model.addAttribute("positionList", positionsPlayers);

            model.addAttribute("newPlayer", new Player());

            String referer = request.getHeader("Referer");
            return "/user/teams/infteam";
        }else return "redirect:/";
    }

    //-------- ДОБАВЛЕНИЕ КОМАНДЫ -------------------------------------------------------------
    @PostMapping("/teams/addTeam")
    public String addTeam(Model model, Principal principal,
                            @ModelAttribute("newTeam") Team team, HttpServletRequest request){
        User user = userService.getUserByLogin(principal.getName());

        boolean flagName = chekNameTeam(team.getNameTeam());
        boolean flagFio = chekNameTeam(team.getFio());
        if (!flagName) {
            model = setModelsForTeams(model, user, team, new MatchDto());
            model.addAttribute(ErrorTeam.ErrorTeamName.name(), "Обязательное поле!");
        }else{
            if (!flagFio){
                model = setModelsForTeams(model, user, team, new MatchDto());
                model.addAttribute(ErrorTeam.ErrorTeamFIO.name(), "Обязательное поле!");
            }else{
                team.setUser(user);
                teamsService.saveTeam(team);
                model = setModelsForTeams(model, user, new Team(), new MatchDto());
            }
        }

        return "/user/teams";
    }

    //-------- УДАЛЕНИЕ КОМАНДЫ -------------------------------------------------------------
    @GetMapping("/teams/deleteTeam/{id}")
    public String deleteTeam(@PathVariable int id, Model model, Principal principal, HttpServletRequest request){

        User user = userService.getUserByLogin(principal.getName());
        if (checkUserForTeam(user, id)) {
            String str = teamsService.deleteTeamById(id);
            model = setModelsForTeams(model, user, new Team(), new MatchDto());
            if (!str.equals("")) model.addAttribute("errorDeleteTeam", str);
            return "/user/teams";
        }else return "redirect:/";

    }

    //ИГРОКИ============================================================================================================
    //---------- по выбранной команде УДАЛЕНИЕ ИГРОКА -------------------------------------
    @GetMapping("/teams/infteam/{id}/deletePlayer/{idPlayer}")
    public String deletePlayer(@PathVariable(name = "id") int idTeam,
                               @PathVariable(name = "idPlayer") int idPlayer, Model model,
                               Principal principal, HttpServletRequest request){
        User user = userService.getUserByLogin(principal.getName());
        if (checkUserForTeam(user, idTeam)) {
            teamsService.deletePlayerById(idPlayer);
            Team team = teamsService.getTeamById(idTeam);
            model.addAttribute("team", team);
            model.addAttribute("players", teamsService.getListPlayersByTeam(team));
            List<PositionsPlayers> positionsPlayers = new ArrayList<>();
            positionsPlayers.add(new PositionsPlayers("И","Игрок"));
            positionsPlayers.add(new PositionsPlayers("Л","Либеро"));
            model.addAttribute("positionList", positionsPlayers);
            model.addAttribute("newPlayer", new Player());
            model.addAttribute("role", user.getRole());
            return "/user/teams/infteam";
        }else return "redirect:/";

    }

    //---------- по выбранной команде ДОБАВЛЕНИЕ ИГРОКА ---------------------
    @PostMapping("/teams/infteam/{id}/addPlayer")
    public String addPlayer(@PathVariable int id, Model model, Principal principal, HttpServletRequest request,
                            @ModelAttribute("newPlayer") Player player){
        User user = userService.getUserByLogin(principal.getName());
        if (checkUserForTeam(user, id)) {
            List<PositionsPlayers> positionsPlayers = new ArrayList<>();
            Team team = teamsService.getTeamById(id);
            if (player.getPosition()==null) player.setPosition("И");
            positionsPlayers.add(new PositionsPlayers("И","Игрок"));
            if (chekNumberPlayer(team, player.getNumber())) {
                if (chekNamePlayer(player.getNamePlayer())) {
                    if (checkPosition(team, player.getPosition())) {
                        player.setTeam(team);
                        positionsPlayers.add(new PositionsPlayers("Л","Либеро"));
                        model.addAttribute("positionList", positionsPlayers);
                        Player p = new Player();
                        p.setTeam(player.getTeam());
                        p.setNamePlayer(player.getNamePlayer());
                        p.setNumber(player.getNumber());
                        p.setPosition(player.getPosition());
                        p.setCaptain(player.isCaptain());
                        teamsService.addPlayer(p);
                    } else model.addAttribute(ErrorTeam.ErrorPosition.name(), "Нельзя назначить больше двух либеро!");
                } else model.addAttribute(ErrorTeam.ErrorNamePlayer.name(), "Обязательное поле!");
            }else model.addAttribute(ErrorTeam.ErrorNumberPlayer.name(), "Номер игрока занят!");

            model.addAttribute("team", team);
            ArrayList<Player> players = getrlayers(teamsService.getListPlayersByTeam(team), player);
            model.addAttribute("players", players);
            model.addAttribute("newPlayer", new Player());
            model.addAttribute("role", user.getRole());

            return "/user/teams/infteam";
        }else return "redirect:/";
    }

    //МАТЧИ=============================================================================================================
    //------------ добавление МАТЧА ----------------------------------------------------------------
    @PostMapping("/matches/addMatch")
    public String addMatch(Model model, Principal principal,
                          @ModelAttribute("newMatch") MatchDto md, HttpServletRequest request){
        User user = userService.getUserByLogin(principal.getName());

        MatchDto newMatch = new MatchDto();
        if (chekNameTeam(md.nameMatch)){
            if(chekDateToMatch(md.dateMatch)){
                    if (md.team1id!= md.team2id) {
                        Matches match = new Matches();
                        match.setFlagCalendar(true);
                        match.setNameMatch(md.nameMatch);
                        match.setDescription(md.description);
                        match.setDateMatch(md.dateMatch.toString());
                        match.setUser(user);
                        ArrayList<Team> teams = new ArrayList<>();


                        Team team1 = teamsService.getTeamById(md.team1id);
                        Team team2 = teamsService.getTeamById(md.team2id);
                        List<Team> teams_ = new ArrayList<>(2);
                        teams_.add(team1);
                        teams_.add(team2);
                        match.setTeams((ArrayList<Team>) teams_);
                        Matches matches = teamsService.saveMatch(match);
//                        List<Matches> matches1 =new ArrayList<>();
//                        matches1.add(matches);
//                        team1.setMatch(matches1);
//                        team2.setMatch(matches1);
//                        teamsService.saveTeam(team1);
//                        teamsService.saveTeam(team2);

                }else {
                        model.addAttribute("ErrorTeams", "Команды не могут быть одинаковые!");
                        newMatch = md;
                    }

            }else {
                model.addAttribute("ErrorDateMatch", "Ошибка ввода даты!");
                newMatch = md;
            }

        }else {
            model.addAttribute("ErrorMatchName", "Обязательное поле!");
            newMatch = md;
        }

        model = setModelsForTeams(model, user, new Team(), newMatch);

        return "/user/teams";
    }
    @GetMapping("/matches/delete/{id}")
    public String deleteMatch(@PathVariable int id, Model model, Principal principal, HttpServletRequest request){
        User user = userService.getUserByLogin(principal.getName());
        if (checkUserForMatch(user, id)) {
            Matches matches = teamsService.getMatchById(id);
            matches.setTeams(new ArrayList<>());
            teamsService.deleteMatch(matches);
            model = setModelsForTeams(model, user, new Team(), new MatchDto());
            return "/user/teams";
        }else return "redirect:/";


    }

}
