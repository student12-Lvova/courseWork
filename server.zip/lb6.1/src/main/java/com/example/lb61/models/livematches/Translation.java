package com.example.lb61.models.livematches;

import com.example.lb61.models.user.User;
import lombok.Data;
import org.springframework.lang.Nullable;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
public class Translation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Nullable
    private int id;
    private String team1name;
    private String team2name;
    private String curScoreTeam1;
    private String curScoreTeam2;
    private String storyScores;
    private String dateUpdate;
    @ManyToOne
    private User user;
}
