package com.example.lb61.timeDependent;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CalendarScheduler {

    @Autowired
    CalendarMatch calendarMatch;

    @Scheduled(initialDelay = 1000L, fixedDelay = 60000L * 720)
    public void calendarMatch(){
        calendarMatch.checkCalendarMatch();
    }
}
