package com.example.lb61.dto;

import com.example.lb61.models.teamsandplayers.Team;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TeamsDto {
    public String name;
    public int id;

    TeamsDto(Team team){
        id = team.getId();
        name = team.getNameTeam();
    }

}
