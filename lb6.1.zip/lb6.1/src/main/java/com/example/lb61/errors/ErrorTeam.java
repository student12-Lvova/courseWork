package com.example.lb61.errors;

public enum ErrorTeam {
    ErrorTeamName, ErrorTeamFIO, ErrorNamePlayer, ErrorNumberPlayer, ErrorPosition
}
