package com.example.lb61.errors;

public enum ErrorsForProfile {
    ErrorLogin, Error_Email, Error_Old_Password, Error_New_Password

}
