package com.example.lb61.timeDependent;

import com.example.lb61.timeDependent.DeleteTranslation;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class TranslationsScheduler {

    @Autowired
    DeleteTranslation deleteTranslation;

    @Scheduled(initialDelay = 1000L, fixedDelay = 300000L)
    public void checkTranslations(){
        deleteTranslation.checkTranslations();
    }
}
