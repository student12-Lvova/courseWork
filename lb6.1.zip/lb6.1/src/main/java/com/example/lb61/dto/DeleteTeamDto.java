package com.example.lb61.dto;

import com.example.lb61.models.teamsandplayers.Team;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeleteTeamDto {
    Team team;
    boolean flagDelete;

}
