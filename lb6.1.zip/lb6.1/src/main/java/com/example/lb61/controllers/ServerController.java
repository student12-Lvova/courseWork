package com.example.lb61.controllers;

import com.example.lb61.models.livematches.Translation;
import com.example.lb61.models.teamsandplayers.Matches;
import com.example.lb61.models.teamsandplayers.Player;
import com.example.lb61.models.teamsandplayers.Team;
import com.example.lb61.models.user.Role;
import com.example.lb61.models.user.User;
import com.example.lb61.repositopies.MatchRepository;
import com.example.lb61.repositopies.PlayerRepository;
import com.example.lb61.repositopies.TeamRepository;
import com.example.lb61.repositopies.UserRepository;
import com.example.lb61.services.UserService;
import com.example.lb61.services.UserTeamsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;


@RestController
public class ServerController {
    @Autowired
    UserService userService;
    @Autowired
    UserTeamsService teamsService;
    @Autowired
    BCryptPasswordEncoder passwordEncoder;

    //авторизация и подключение
    @PostMapping("/api/login")
    public User auth(@RequestBody User user){

        User user1 = userService.getUserByLogin(user.login);
        if (passwordEncoder.matches(user.password, user1.getPassword()))
            return user1;
        else return null;
    }
    @PostMapping("/api/registration")
    public User registration(@RequestBody User user){
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole(Role.USER);
        return userService.saveUser(user);
    }
    @GetMapping("/api/connect")
    public Long connect(){
        return userService.connect();
    }

    //получение данных
    @PostMapping("/api/dataUser")
    public User getUserById(@RequestBody long id){
        return userService.getUserById(id);
    }
    @PostMapping("/api/dataUser/matches")
    public List<Matches> getAllMatchesForUser(@RequestBody long id){
        return teamsService.getListMatchesByIdUser(id);
    }
    @PostMapping("/api/dataUser/teams")
    public List<Team> getAllTeamsForUser(@RequestBody long id){
        return teamsService.getListTeamsByIdUser(id);
    }
    @PostMapping("/api/dataUser/players")
    public List<Player> getAllPlayersForUser(@RequestBody long id){
        return teamsService.getListPlayersByIdUser(id);
    }
    @PostMapping("/api/translation/update")
    public Long updateTransaction(@RequestBody Translation translation){
        return (long) teamsService.updateTranslation(translation);
    }
    @PostMapping("/api/translation/save")
    public Long saveTransaction(@RequestBody Translation translation){
        return (long) teamsService.saveTranslation(translation);
    }
    @PostMapping("/api/dataUser/insertMatch")
    public Long insertMatch(@RequestBody Matches matches){
        return (long) teamsService.saveMatch(matches).getId();
    }
}
