package com.example.lb61.timeDependent;

import com.example.lb61.services.UserTeamsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.datetime.DateFormatter;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

@Service
public class CalendarMatchImpl implements CalendarMatch {
    @Autowired
    UserTeamsService matchService;
    @Override
    public void checkCalendarMatch() {
        matchService.getAllMatches().forEach(match ->{
            // Converting given date string to LocalDateTime
            LocalDate dateTime = LocalDate.parse(match.getDateMatch());
            if (dateTime.isBefore(LocalDate.now())&& match.isFlagCalendar()){
                match.setTeams(new ArrayList<>());
                matchService.saveMatch(match);
                matchService.deleteMatchById(match.getId());
            }
        });
    }
}
