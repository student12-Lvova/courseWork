package com.example.lb61.repositopies;

import com.example.lb61.models.teamsandplayers.Matches;
import com.example.lb61.models.teamsandplayers.Team;
import com.example.lb61.models.user.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MatchRepository extends CrudRepository<Matches, Integer> {
    List<Matches> findByUser(User user);

    List<Matches> findByTeam(Team team);

    void deleteByUser(User user);


//
//    @Query("SELECT * FROM Matches where id = (Select matches_id from matches_teams where teams_id = ?1)")
//    List<Matches> findByTeam(int id);
}
