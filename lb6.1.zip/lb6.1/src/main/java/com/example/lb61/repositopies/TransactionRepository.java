package com.example.lb61.repositopies;

import com.example.lb61.models.livematches.Translation;
import com.example.lb61.models.user.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TransactionRepository extends CrudRepository<Translation, Integer> {

    Optional<List<Translation>> findByUser(User user);

    void deleteByUser(User user);
}
