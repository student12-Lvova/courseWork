package com.example.lb61.models.teamsandplayers;

import javax.persistence.*;
import lombok.Data;

@Entity
@Data
public class Player {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String namePlayer;
    private String position;
    private int number;
    private boolean captain;
    @ManyToOne
    private Team team;

    public void setPlayerData(String name, String position, int number, boolean captain, Team team){
        this.namePlayer = name;
        this.position = position;
        this.number = number;
        this.captain = captain;
        this.team = team;
    }
}
