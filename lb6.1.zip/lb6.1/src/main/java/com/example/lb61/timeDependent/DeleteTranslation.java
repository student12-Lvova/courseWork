package com.example.lb61.timeDependent;

import com.example.lb61.models.livematches.Translation;
import com.example.lb61.repositopies.TransactionRepository;
import com.example.lb61.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Optional;

public interface DeleteTranslation {

    public void checkTranslations();
}
