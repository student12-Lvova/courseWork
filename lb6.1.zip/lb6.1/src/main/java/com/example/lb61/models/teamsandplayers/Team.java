package com.example.lb61.models.teamsandplayers;

import com.example.lb61.models.user.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
public class Team {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nameTeam;
    private String address;
    private String fio;
    private String email;


    @ManyToMany(mappedBy = "team", fetch = FetchType.LAZY)
    @JsonIgnore
    private List<Matches> match;

    @ManyToOne
    @JsonIgnore
    private User user;
    public void setTeam(String nameTeam, String address, Representative representative, User user){
        this.nameTeam = nameTeam;
        this.address = address;
        this.fio = representative.getFio();
        this.email = representative.getEmail();
        this.user = user;
    }

}
