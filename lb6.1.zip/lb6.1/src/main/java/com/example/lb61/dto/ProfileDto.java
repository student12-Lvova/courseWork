package com.example.lb61.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ProfileDto {
    public int id;
    public String login;
    public String old_password;
    public String email;
    public String new_password;



}
