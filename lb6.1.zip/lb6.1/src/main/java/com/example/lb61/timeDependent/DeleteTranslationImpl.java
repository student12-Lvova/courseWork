package com.example.lb61.timeDependent;

import com.example.lb61.services.UserService;
import com.example.lb61.services.UserTeamsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

@Service
public class DeleteTranslationImpl implements DeleteTranslation {
    @Autowired
    UserTeamsService translationService;
    @Override
    public void checkTranslations() {

        translationService.getAllTranslation().forEach(translation -> {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS", Locale.US);
            // Converting given date string to LocalDateTime
            LocalDateTime dateTime = LocalDateTime.parse(translation.getDateUpdate(), dtf);
            if (ChronoUnit.MINUTES.between(dateTime, LocalDateTime.now())>20){
                translationService.deleteTranslationById(translation.getId());
            }
        });

    }
}
