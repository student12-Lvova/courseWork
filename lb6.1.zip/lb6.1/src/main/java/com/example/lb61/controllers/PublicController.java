package com.example.lb61.controllers;

import com.example.lb61.dto.ProfileDto;
import com.example.lb61.errors.ErrorsForProfile;
import com.example.lb61.models.livematches.Translation;
import com.example.lb61.models.teamsandplayers.Team;
import com.example.lb61.models.user.Role;
import com.example.lb61.models.user.User;
import com.example.lb61.services.UserService;
import com.example.lb61.services.UserTeamsService;
import lombok.RequiredArgsConstructor;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
@RequiredArgsConstructor
@RequestMapping("/")
public class PublicController {
    @Autowired
    BCryptPasswordEncoder passwordEncoder;
    @Autowired
    UserService userService;
    @Autowired
    UserTeamsService teamsService;
    @GetMapping("/home")
    public String home(Model model, Principal principal){
        if (principal!=null){
            User user = userService.getUserByLogin(principal.getName());
            model.addAttribute("user", user);
            model.addAttribute("role", user.getRole().name());
        }
        else model.addAttribute("user", new User());

        return "home";
    }
    @GetMapping("/")
    public String main(Model model, Principal principal){
        if (principal!=null){
            User user = userService.getUserByLogin(principal.getName());
            model.addAttribute("user", user);
            model.addAttribute("role", user.getRole().name());
        }
        else model.addAttribute("user", new User());

        return "home";
    }

    @GetMapping("/profile")
    public String profile(Model model, Principal principal){
        if (principal!=null) {
            User user = userService.getUserByLogin(principal.getName());
            ProfileDto profileDto = new ProfileDto(user.getId(), user.getLogin(), "", user.getEmail(), "");
            model.addAttribute("user", profileDto);
            model.addAttribute("role", user.getRole().name());
                model.addAttribute("translations", teamsService.getListTranslationsByIdUser(user));
                model.addAttribute("teams", teamsService.getListTeamsByIdUser(user.getId()));
                model.addAttribute("matches", teamsService.getListMatchesByIdUser(user.getId()));

                model.addAttribute("newTeam", new Team());
            return "/profile";
        }
        else{
            return "/home";
        }

    }
    @PostMapping("/profile")
    public String profile(@ModelAttribute("user") ProfileDto newUser,
                                   Model model, Principal principal){

        User oldUser = userService.getUserByLogin(principal.getName());
        User user = oldUser;
        boolean flag = false;
        model.addAttribute("user", newUser);
        model.addAttribute("role", oldUser.getRole().name());
        model.addAttribute("translations", teamsService.getListTranslationsByIdUser(oldUser));


        //логин
        if (!newUser.login.equals(oldUser.login)){
            //ноный пароль не равен старому
            if (!newUser.login.equals("")&&!userService.checkLogin(newUser.login, oldUser.id)){
                model.addAttribute(ErrorsForProfile.ErrorLogin.name(), "Логин занят другим пользователем!");
                return "/profile";
            }
            if (!newUser.login.equals("")) {
                user.setLogin(newUser.login);
                flag = true;
            }
            else user.setLogin(oldUser.getLogin());
        }else user.setLogin(oldUser.getLogin());
        //email
        if (!newUser.email.equals("")&&!userService.checkEmail(newUser.email, oldUser.id)){
            model.addAttribute(ErrorsForProfile.Error_Email.name(), "Email занят другим пользователем!");
            return "/profile";
        }else{
            if (!newUser.email.equals(""))
                user.setEmail(newUser.email);
            else user.setEmail(oldUser.getEmail());
        }
        //пароль
        switch (checkChangePassword(oldUser.password, newUser.old_password, newUser.new_password)) {
            case "Неверно введен старый пароль!": {
                model.addAttribute(ErrorsForProfile.Error_Old_Password.name(),
                        "Неверно введен старый пароль!");
                return "/profile";
            }
            case "Новый пароль не может соответствовать старому!": {
                model.addAttribute(ErrorsForProfile.Error_New_Password.name(),
                        "Новый пароль не может соответствовать старому!");
                return "/profile";
            }
            case "Пароль должен быть больше 8 и не меньше 20!": {
                model.addAttribute(ErrorsForProfile.Error_New_Password.name(),
                        "Пароль должен быть больше 8 и не меньше 20!");
                return "/profile";
            }
            case "Не меняем пароль": { break; }
            default: {
                user.setPassword(passwordEncoder.encode(newUser.getNew_password()));
                flag = true;
            }
        }
        userService.saveUser(user);
        if (flag) return "/login";
        else {
            model.addAttribute("user", new ProfileDto());
            return "/profile";
        }
    }

    private String checkChangePassword(String password, String old_password, String new_password) {
        if (!old_password.equals("") && !new_password.equals("")){
            if (!passwordEncoder.matches(old_password, password))
                return "Неверно введен старый пароль!";
            if (old_password.equals(new_password))
                return "Новый пароль не может соответствовать старому!";
            if (new_password.length()<8 || new_password.length()>20)
                return "Пароль должен быть больше 8 и не меньше 20!";
            return "Меняем";
        }
        return "Не меняем пароль";
    }

    @GetMapping("/registration")
    public String registration(Model model, Principal principal){
        model.addAttribute("user", new User());
        return "registration";
    }
    @PostMapping("/registration")
    public String registration(@ModelAttribute("user") User user, Model model){

        if (user.login.equals("")){
            model.addAttribute(ErrorsForProfile.ErrorLogin.name(), "Логин обязательное поле!");
            return "/registration";
        }else{
            if(!userService.checkLogin(user.login, -1)){
                model.addAttribute(ErrorsForProfile.ErrorLogin.name(), "Логин занят другим пользователем!");
                return "/registration";
            }
        }
        if (user.email.equals("")){
            model.addAttribute(ErrorsForProfile.Error_Email.name(), "Email обязательное поле!");
            return "/registration";
        }else {
            if(!userService.checkEmail(user.email, -1)){
                model.addAttribute(ErrorsForProfile.Error_Email.name(), "Email занят другим пользователем!");
                return "/registration";
            }
        }
        if (user.password.equals("")){
            model.addAttribute(ErrorsForProfile.Error_Old_Password.name(), "Пароль обязательное поле!");
            return "/registration";
        }
        if (user.password.length()<8 || user.password.length()>20){
            model.addAttribute(ErrorsForProfile.Error_Old_Password.name(),
                    "Пароль должен быть больше 8,но не больше 20!");
            return "/registration";
        }

        user.setRole(Role.USER);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userService.saveUser(user);
        model.addAttribute("role", user.getRole().name());
        return "login";
    }

    @GetMapping("/translations")
    public String translation(Model model, Principal principal){
        model.addAttribute("translations", teamsService.getAllTranslation());
        if (principal!=null)
            model.addAttribute("role", userService.getUserByLogin(principal.getName()).getRole().name());
        return "translations";
    }

}
