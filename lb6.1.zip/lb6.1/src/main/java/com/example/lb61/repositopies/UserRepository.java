package com.example.lb61.repositopies;

import com.example.lb61.models.user.User;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {

    Optional<User> findByLoginAndPassword(String login, String password);

    Optional<User> findByLogin(String userName);

    @Query("SELECT COUNT(*) FROM User where login = ?1 and id <> ?2")
    int checkLogin(String login, int id);

    @Query("SELECT COUNT(*) FROM User where email = ?1 and id <> ?2")
    int checkEmail(String email, int id);

    Optional<User> findByEmail(String email);

//    @Query("SELECT COUNT(*) FROM Users where email = :email and id <> :id")
//    int checkEmail(@Param("email") String email, @Param("id") int id);
}
