package com.example.lb61.services;

import com.example.lb61.models.user.Role;
import com.example.lb61.models.user.User;
import com.example.lb61.repositopies.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserTeamsService teamsService;
    @Autowired
    private UserRepository userRepository;

    public void setUserRepository(UserRepository
                                             userRepository) {
        this.userRepository = userRepository;
    }
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        userRepository.findAll().forEach(user ->
                {
                    if (user.getRole()!= Role.ADMIN) {
                        users.add(user);
                    }
                });

        return users;
    }
    public User getUserById(Long id) {
        return userRepository.findById(id.intValue()).get();
    }
    public User getUserByLogin(String login) {
        return userRepository.findByLogin(login).get();
    }
    public void deleteUserById(Long id) {
        User user = userRepository.findById(id.intValue()).get();
        teamsService.deleteTeamByUser(user);
        teamsService.deleteTranslationByUser(user);
        userRepository.deleteById(id.intValue());
    }
    public User saveUser(User user){
        return userRepository.save(user);
    }

    public long connect(){return userRepository.count();}
    public boolean checkLogin(String login, int id){
        if (id==-1)
            return userRepository.findByLogin(login).isEmpty();
        else
            return userRepository.checkLogin(login,id)<=0;
    }
    public boolean checkEmail(String email, int id){
        if (id==-1)
            return userRepository.findByEmail(email).isEmpty();
        else
            return userRepository.checkEmail(email,id)<=0;
    }

}
