package com.example.lb61;

import com.example.lb61.models.livematches.Translation;
import com.example.lb61.models.teamsandplayers.Player;
import com.example.lb61.models.teamsandplayers.Representative;
import com.example.lb61.models.teamsandplayers.Team;
import com.example.lb61.models.user.User;
import com.example.lb61.repositopies.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootTest
class ApplicationTests {

	public static BCryptPasswordEncoder passwordEncoder(){
		return  new BCryptPasswordEncoder();
	}
	@Autowired
	UserRepository userRepository;
	@Autowired
	TeamRepository teamRepository;
	@Autowired
	PlayerRepository playerRepository;
	@Autowired
	TransactionRepository transactionRepository;
	@Test
	void contextLoads() {
	}

	@Test
	void addUser() {
		User user = new User();
		user.setAdmin("admin", passwordEncoder().encode("password"), "");
		userRepository.save(user);

	}


	@Test
	void addTeam() {
		Representative rep = new Representative();
		rep.setFio("Ушаков Константин");
		rep.setEmail("");

		Team team = new Team();
		team.setTeam("Динамо (Москва)", "", rep, userRepository.findByLogin("user1").get());
		teamRepository.save(team);
	}
	@Test
	void addPlayers() {
		Player player = new Player();
		player.setPlayerData("МАРИЯ ХАЛЕЦКАЯ", "И", 1, false, teamRepository.findById(2).get());
		playerRepository.save(player);
		player = new Player();
		player.setPlayerData("ЕВГЕНИЯ СТАРЦЕВА", "И", 3, false, teamRepository.findById(2).get());
		playerRepository.save(player);
		player = new Player();
		player.setPlayerData("ТАТЬЯНА ДМИТРИЕВА (РОМАНОВА)", "И", 7, false, teamRepository.findById(2).get());
		playerRepository.save(player);
		player = new Player();
		player.setPlayerData("НАТАЛИЯ ГОНЧАРОВА", "И", 8, false, teamRepository.findById(2).get());
		playerRepository.save(player);
		player = new Player();
		player.setPlayerData("ИРИНА КАПУСТИНА", "И", 11, false, teamRepository.findById(2).get());
		playerRepository.save(player);
		player = new Player();
		player.setPlayerData("МАРГАРИТА КУРИЛО", "И", 17, false, teamRepository.findById(2).get());
		playerRepository.save(player);
		player = new Player();
		player.setPlayerData("АННА ПОДКОПАЕВА", "Л", 19, false, teamRepository.findById(2).get());
		playerRepository.save(player);
	}

	@Test
	void addTranslation() {
		Translation translation = new Translation();
		translation.setUser(userRepository.findByLogin("user3").get());
		translation.setCurScoreTeam1("21");
		translation.setCurScoreTeam1("2");
		translation.setTeam1name("Команда 3");
		translation.setTeam2name("Команда 4");
		translation.setStoryScores("21:25 25:1");
		transactionRepository.save(translation);
	}
}
